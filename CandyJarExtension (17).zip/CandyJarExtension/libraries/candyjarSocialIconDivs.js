function vizualizeSocialsSectiion(candyjarLogin,
                                  about,
                                  accounts,
                                  topTags,
                                  candyjarSectionDivId) {
  if (topTags && topTags.length > 0) {
    $("#candyjarSectionDiv" + candyjarSectionDivId).prepend(createListOfCandyjarDeveloperTags(candyjarSectionDivId));
    topTags.forEach(function(item, index, array) {
      var candyjarDeveloperTag = $('<span/>',{
        class: "candyjarDeveloperTag",
        id: "candyjarDeveloperTag" + candyjarSectionDivId + index,
        text: item,
      });
      $("#listOfCandyjarDeveloperTags" + candyjarSectionDivId).append(candyjarDeveloperTag);
    });
  }

    $("#candyjarSectionDiv" + candyjarSectionDivId).append(createCandyjarSocialsDiv(candyjarSectionDivId));
    $("#candyjarSocialsDiv"+ candyjarSectionDivId).append(createCandyjarSocialsDiv2(candyjarSectionDivId));

    visualizeIcons($("#candyjarSocialsDiv2"+candyjarSectionDivId), candyjarLogin, about, accounts);
}

function createCandyjarSectionDiv(id) {
  var candyjarSectionDiv = $('<div/>',{
    class: "candyjarSectionDiv",
    id: "candyjarSectionDiv" + id,
  });
  return candyjarSectionDiv;
}

function createCandyjarSimilarCandidatesTitleDiv() {
  var candyjarSimilarCandidatesTitleDiv = $('<div/>',{
    class: "candyjarSimilarCandidatesTitleDiv",
    id: "candyjarSimilarCandidatesTitleDiv",
  });
  return candyjarSimilarCandidatesTitleDiv;
}







function createCandyjarSocialsDiv(id) {
  var candyjarSocialsDiv = $('<div/>',{
    class: "candyjarSocialsDiv",
    id: "candyjarSocialsDiv" + id,
  });
  return candyjarSocialsDiv;
}

function createCandyjarSocialsDiv2(id) {
  var candyjarSocialsDiv2 = $('<div/>',{
    class: "candyjarSocialsDiv2",
    id: "candyjarSocialsDiv2" + id,
  });
  return candyjarSocialsDiv2;
}

function createListOfCandyjarDeveloperTags(id) {
  var listOfCandyjarDeveloperTags = $('<div/>',{
    class: "listOfCandyjarDeveloperTags",
    id: "listOfCandyjarDeveloperTags" + id,
  });
  return listOfCandyjarDeveloperTags;
}


function visualizeIcons(iconsDivElement, candyjarLogin, about, accounts) {
  iconsDivElement.append(createCandyjarElement('https://candyjar.io/p/' + candyjarLogin));
  if (accounts && accounts.linkedinHTML) {
    iconsDivElement.append(createLinkedinElement(accounts.linkedinHTML));
  }
  if (about) {
    if ((about.email && about.email.length) || (about.emails && about.emails.length)) {
      iconsDivElement.append(createEmailElement('https://candyjar.io/p/' + candyjarLogin));
    }
  }
  if (about && about.phone) {
    iconsDivElement.append(createTelElement('https://candyjar.io/p/' + candyjarLogin));
  }
  if (accounts && accounts.telegramHTML) {
    iconsDivElement.append(createTelegramElement('https://candyjar.io/p/' + candyjarLogin));
  }
  if (about && about.skype) {
    iconsDivElement.append(createSkypeElement('https://candyjar.io/p/' + candyjarLogin));
  }
  if (accounts && accounts.githubHTML) {
    iconsDivElement.append(createGithubElement(accounts.githubHTML));
  }
  if (accounts && accounts.facebookHTML) {
    iconsDivElement.append(createFacebookElement(accounts.facebookHTML));
  }
  if (accounts && accounts.moiKrugHTML) {
    iconsDivElement.append(createMoikrugElement(accounts.moiKrugHTML));
  }
  if (accounts && accounts.hhHTML) {
    iconsDivElement.append(createHhElement(accounts.hhHTML));
  }
  if (accounts && accounts.stackoverflowHTML) {
    iconsDivElement.append(createStackoverflowElement(accounts.stackoverflowHTML));
  }
  if (accounts && accounts.vkHTML) {
    iconsDivElement.append(createVkElement(accounts.vkHTML));
  }
  if (accounts && accounts.twitterHTML) {
    iconsDivElement.append(createTwitterElement(accounts.twitterHTML));
  }
  if (accounts && accounts.gitlabHTML) {
    iconsDivElement.append(createGitlabElement(accounts.gitlabHTML));
  }
  if (accounts && accounts.bitbucketHTML) {
    iconsDivElement.append(createBitbucketElement(accounts.bitbucketHTML));
  }
  if (accounts && accounts.webSite) {
    iconsDivElement.append(createWebsiteElement(accounts.webSite));
  }
  if (accounts && accounts.habrHTML) {
    iconsDivElement.append(createHabrElement(accounts.habrHTML));
  }
  if (accounts && accounts.xingHTML) {
    iconsDivElement.append(createXingElement(accounts.xingHTML));
  }
  if (accounts && accounts.hackerrankHTML) {
    iconsDivElement.append(createHackerrankElement(accounts.hackerrankHTML));
  }
  if (accounts && accounts.behanceHTML) {
    iconsDivElement.append(createBehanceElement(accounts.behanceHTML));
  }

  if (accounts && accounts.dribbbleHTML) {
    iconsDivElement.append(createDribbbleElement(accounts.dribbbleHTML));
  }


  return iconsDivElement;
}


function createGithubElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarGithubSvg');
  svg.setAttribute('class', 'candyjarGithubSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M19.3759 5.7786C18.4934 4.22863 17.2964 3.00152 15.7845 2.09699C14.2723 1.19241 12.6215 0.740234 10.8309 0.740234C9.04046 0.740234 7.38911 1.19255 5.87728 2.09699C4.36522 3.00147 3.16822 4.22863 2.28572 5.7786C1.40336 7.32852 0.962158 9.02105 0.962158 10.8561C0.962158 13.0605 1.58956 15.0427 2.84466 16.8033C4.09964 18.564 5.72088 19.7823 7.70825 20.4585C7.93959 20.5025 8.11084 20.4715 8.22218 20.3664C8.33358 20.2611 8.38921 20.1292 8.38921 19.9714C8.38921 19.945 8.387 19.708 8.38272 19.2601C8.37831 18.8122 8.37624 18.4214 8.37624 18.088L8.08068 18.1404C7.89224 18.1758 7.65451 18.1908 7.3675 18.1865C7.08063 18.1824 6.78282 18.1516 6.47447 18.0943C6.166 18.0375 5.87908 17.9058 5.61349 17.6994C5.34804 17.493 5.1596 17.2229 5.0482 16.8895L4.91971 16.5863C4.83406 16.3846 4.69922 16.1604 4.51501 15.9147C4.33079 15.6687 4.14451 15.502 3.95607 15.4142L3.8661 15.3482C3.80615 15.3043 3.75052 15.2514 3.69908 15.19C3.64768 15.1286 3.6092 15.0671 3.5835 15.0056C3.55775 14.944 3.57909 14.8935 3.64772 14.8538C3.71636 14.8142 3.8404 14.795 4.02038 14.795L4.27728 14.8343C4.44862 14.8695 4.66056 14.9747 4.91336 15.1504C5.16603 15.326 5.37374 15.5543 5.53653 15.8351C5.73366 16.1953 5.97116 16.4697 6.24971 16.6585C6.52803 16.8473 6.80865 16.9416 7.0913 16.9416C7.37394 16.9416 7.61806 16.9196 7.82374 16.8759C8.0292 16.832 8.22196 16.766 8.40194 16.6783C8.47904 16.0897 8.68895 15.6375 9.0315 15.3214C8.54326 15.2688 8.10431 15.1896 7.71442 15.0843C7.32475 14.9788 6.92207 14.8076 6.50665 14.5703C6.09102 14.3333 5.74622 14.039 5.47217 13.6879C5.19808 13.3367 4.97313 12.8755 4.79765 12.3048C4.62208 11.734 4.53427 11.0754 4.53427 10.329C4.53427 9.26631 4.87272 8.36196 5.54949 7.61548C5.23246 6.81651 5.26239 5.92084 5.63937 4.92855C5.88781 4.84943 6.25624 4.90881 6.74447 5.10631C7.2328 5.30391 7.59033 5.47318 7.81744 5.61353C8.04454 5.75383 8.22651 5.87272 8.3636 5.96914C9.16044 5.74091 9.98277 5.62677 10.8308 5.62677C11.6788 5.62677 12.5013 5.74091 13.2982 5.96914L13.7865 5.65316C14.1204 5.44232 14.5147 5.2491 14.9685 5.07347C15.4225 4.89792 15.7697 4.84957 16.0096 4.92869C16.395 5.92102 16.4293 6.81665 16.1122 7.61562C16.7889 8.3621 17.1275 9.26667 17.1275 10.3292C17.1275 11.0756 17.0394 11.7362 16.8641 12.3114C16.6886 12.8868 16.4617 13.3475 16.1834 13.6945C15.9047 14.0415 15.5577 14.3335 15.1423 14.5705C14.7268 14.8076 14.324 14.9788 13.9343 15.0842C13.5445 15.1897 13.1055 15.2689 12.6173 15.3216C13.0626 15.7166 13.2853 16.3402 13.2853 17.1919V19.971C13.2853 20.1289 13.3388 20.2607 13.4461 20.366C13.5531 20.4711 13.7222 20.5021 13.9535 20.458C15.9412 19.782 17.5624 18.5636 18.8174 16.8029C20.0722 15.0423 20.6998 13.0601 20.6998 10.8558C20.6993 9.02091 20.2579 7.32852 19.3759 5.7786Z");
  path1.setAttributeNS(null, "fill", "#4A4A4A");

  svg.appendChild(path1);

  var candyjarGithubDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarGithubDiv",
  });

   candyjarGithubDiv.append(svg);
   candyjarGithubDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'github_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});

   });
   return candyjarGithubDiv;
}

function createHackerrankElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarHackerrankSvg');
  svg.setAttribute('class', 'candyjarHackerrankSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M 10.5 0 C 11.625 0 19.03125 4.273438 19.59375 5.25 C 20.15625 6.226562 20.15625 14.773438 19.59375 15.75 C 19.027344 16.726562 11.625 21 10.5 21 C 9.375 21 1.96875 16.726562 1.40625 15.75 C 0.84375 14.773438 0.84375 6.226562 1.40625 5.25 C 1.96875 4.273438 9.375 0 10.5 0 Z M 12.507812 5.949219 C 12.382812 5.949219 12.28125 6.050781 12.28125 6.175781 L 12.28125 9.566406 L 8.71875 9.566406 L 8.71875 6.042969 L 9.332031 6.042969 C 9.390625 6.042969 9.449219 6.019531 9.488281 5.976562 C 9.53125 5.933594 9.554688 5.878906 9.554688 5.820312 C 9.554688 5.738281 9.511719 5.667969 9.445312 5.625 L 8.070312 4.304688 C 8.019531 4.246094 7.949219 4.210938 7.871094 4.210938 C 7.800781 4.210938 7.734375 4.246094 7.691406 4.304688 L 6.222656 5.625 C 6.15625 5.667969 6.117188 5.738281 6.117188 5.816406 C 6.117188 5.941406 6.214844 6.042969 6.339844 6.042969 L 6.957031 6.042969 L 6.960938 14.824219 C 6.960938 14.949219 7.058594 15.050781 7.183594 15.050781 L 8.488281 15.050781 C 8.613281 15.050781 8.714844 14.949219 8.714844 14.824219 L 8.714844 11.320312 L 12.28125 11.320312 L 12.28125 14.953125 L 11.667969 14.953125 C 11.570312 14.957031 11.484375 15.023438 11.457031 15.121094 C 11.429688 15.214844 11.464844 15.316406 11.550781 15.371094 L 12.929688 16.691406 C 12.980469 16.753906 13.050781 16.785156 13.128906 16.789062 C 13.199219 16.785156 13.265625 16.75 13.308594 16.691406 L 14.777344 15.371094 C 14.863281 15.320312 14.902344 15.214844 14.875 15.117188 C 14.847656 15.023438 14.761719 14.957031 14.660156 14.953125 L 14.042969 14.953125 L 14.039062 6.175781 C 14.039062 6.113281 14.015625 6.058594 13.972656 6.015625 C 13.933594 5.972656 13.875 5.949219 13.816406 5.949219 Z M 12.507812 5.949219");
  path1.setAttributeNS(null, "fill", "#000000");

  svg.appendChild(path1);

  var candyjarHackerrankDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarHackerrankDiv",
  });

   candyjarHackerrankDiv.append(svg);
   candyjarHackerrankDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'hackerrank_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarHackerrankDiv;
}

function createBehanceElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarBehanceSvg');
  svg.setAttribute('class', 'candyjarBehanceSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 8.457031 9.777344 C 8.457031 9.777344 10.441406 9.628906 10.441406 7.300781 C 10.441406 4.976562 8.816406 3.84375 6.761719 3.84375 L 0 3.84375 L 0 16.839844 L 6.761719 16.839844 C 6.761719 16.839844 10.890625 16.96875 10.890625 13.003906 C 10.890625 13.003906 11.070312 9.777344 8.457031 9.777344 Z M 2.980469 6.152344 L 6.761719 6.152344 C 6.761719 6.152344 7.683594 6.152344 7.683594 7.503906 C 7.683594 8.855469 7.140625 9.050781 6.527344 9.050781 L 2.980469 9.050781 Z M 6.589844 14.53125 L 2.980469 14.53125 L 2.980469 11.054688 L 6.761719 11.054688 C 6.761719 11.054688 8.132812 11.039062 8.132812 12.839844 C 8.132812 14.34375 7.132812 14.515625 6.589844 14.53125 Z M 6.589844 14.53125 ");
  path1.setAttributeNS(null, "fill", "#0057ff");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M 13.601562 4.609375 L 18.964844 4.609375 L 18.964844 6.207031 L 13.601562 6.207031 Z M 13.601562 4.609375 ");
  path2.setAttributeNS(null, "fill", "#0057ff");
  svg.appendChild(path2);

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "d", "M 16.398438 7.148438 C 11.398438 7.148438 11.402344 12.140625 11.402344 12.140625 C 11.402344 12.140625 11.0625 17.109375 16.398438 17.109375 C 16.398438 17.109375 20.84375 17.363281 20.84375 13.65625 L 18.558594 13.65625 C 18.558594 13.65625 18.632812 15.050781 16.472656 15.050781 C 16.472656 15.050781 14.1875 15.207031 14.1875 12.789062 L 20.921875 12.789062 C 20.921875 12.789062 21.660156 7.148438 16.398438 7.148438 Z M 18.429688 11.054688 L 14.160156 11.054688 C 14.160156 11.054688 14.441406 9.050781 16.449219 9.050781 C 18.457031 9.050781 18.429688 11.054688 18.429688 11.054688 Z M 18.429688 11.054688 ");
  path3.setAttributeNS(null, "fill", "#0057ff");
  svg.appendChild(path3);


  var candyjarBehanceDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarBehanceDiv",
  });

   candyjarBehanceDiv.append(svg);
   candyjarBehanceDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'behance_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarBehanceDiv;
}

function createDribbbleElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarDribbbleSvg');
  svg.setAttribute('class', 'candyjarDribbbleSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 20.5625 10.5 C 20.5625 16.058594 16.058594 20.5625 10.5 20.5625 C 4.941406 20.5625 0.4375 16.058594 0.4375 10.5 C 0.4375 4.941406 4.941406 0.4375 10.5 0.4375 C 16.058594 0.4375 20.5625 4.941406 20.5625 10.5 Z M 20.5625 10.5 ");
  path1.setAttributeNS(null, "fill", "rgb(92.54902%,25.098039%,47.843137%)");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M 10.5 21 C 4.699219 21 0 16.300781 0 10.5 C 0 4.699219 4.699219 0 10.5 0 C 16.300781 0 21 4.699219 21 10.5 C 20.992188 16.296875 16.296875 20.992188 10.5 21 Z M 10.5 0.875 C 5.183594 0.875 0.875 5.183594 0.875 10.5 C 0.875 15.816406 5.183594 20.125 10.5 20.125 C 15.816406 20.125 20.125 15.816406 20.125 10.5 C 20.121094 5.1875 15.8125 0.878906 10.5 0.875 Z M 10.5 0.875 ");
  path2.setAttributeNS(null, "fill", "rgb(67.843137%,7.843137%,34.117647%)");
  svg.appendChild(path2);

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "d", "M 14.875 19.6875 C 14.644531 19.6875 14.453125 19.507812 14.4375 19.277344 C 13.90625 12.589844 11.019531 6.308594 6.289062 1.550781 C 6.121094 1.378906 6.121094 1.101562 6.292969 0.929688 C 6.464844 0.757812 6.742188 0.757812 6.914062 0.929688 C 11.789062 5.839844 14.765625 12.324219 15.3125 19.222656 C 15.328125 19.464844 15.144531 19.671875 14.902344 19.6875 Z M 14.875 19.6875 ");
  path3.setAttributeNS(null, "fill", "rgb(67.843137%,7.843137%,34.117647%)");
  svg.appendChild(path3);

  path4 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path4.setAttributeNS(null, "d", "M 0.875 9.679688 C 0.632812 9.679688 0.4375 9.484375 0.4375 9.242188 C 0.4375 9 0.632812 8.804688 0.875 8.804688 C 6.773438 8.804688 14.382812 7.84375 17.125 3.273438 C 17.253906 3.070312 17.523438 3.007812 17.726562 3.136719 C 17.925781 3.261719 17.992188 3.523438 17.875 3.726562 C 14.921875 8.648438 7 9.679688 0.875 9.679688 Z M 0.875 9.679688 ");
  path4.setAttributeNS(null, "fill", "rgb(67.843137%,7.843137%,34.117647%)");
  svg.appendChild(path4);

  path5 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path5.setAttributeNS(null, "d", "M 4.101562 18.410156 C 3.859375 18.410156 3.664062 18.214844 3.664062 17.972656 C 3.664062 17.898438 3.683594 17.824219 3.722656 17.757812 C 7.421875 11.28125 15.035156 9.21875 20.257812 10.960938 C 20.484375 11.046875 20.597656 11.296875 20.515625 11.523438 C 20.433594 11.738281 20.203125 11.855469 19.980469 11.789062 C 15.09375 10.160156 7.953125 12.105469 4.476562 18.191406 C 4.398438 18.328125 4.257812 18.410156 4.101562 18.410156 Z M 4.101562 18.410156 ");
  path5.setAttributeNS(null, "fill", "rgb(67.843137%,7.843137%,34.117647%)");
  svg.appendChild(path5);


  var candyjarDribbbleDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarDribbbleDiv",
  });

   candyjarDribbbleDiv.append(svg);
   candyjarDribbbleDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'dribbble_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarDribbbleDiv;
}

function createFacebookElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarFacebookSvg');
  svg.setAttribute('class', 'candyjarFacebookSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M10.264 0.135742C4.93016 0.135742 0.592041 4.47386 0.592041 9.80769C0.592041 15.14 4.93016 19.4776 10.264 19.4776C15.5963 19.4776 19.9339 15.14 19.9339 9.80769C19.9339 4.47386 15.5963 0.135742 10.264 0.135742ZM12.6683 10.1462H11.096C11.096 12.6602 11.096 15.7543 11.096 15.7543H8.7623C8.7623 15.7543 8.7623 12.6908 8.7623 10.1462H7.65492V8.16621H8.7623V6.88378C8.7623 5.96495 9.19861 4.53033 11.1163 4.53033L12.8449 4.53657V6.46202C12.8449 6.46202 11.7936 6.46202 11.591 6.46202C11.3858 6.46202 11.096 6.56331 11.096 7.00169V8.16621H12.8714L12.6683 10.1462Z");
  path1.setAttributeNS(null, "fill", "#0043A5");

  svg.appendChild(path1);

  var candyjarFacebookDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarFacebookDiv",
  });

   candyjarFacebookDiv.append(svg);
   candyjarFacebookDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'facebook_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarFacebookDiv;
}

function createArrowElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '16');
  svg.setAttribute('height', '10');
  svg.setAttribute('id', 'candyjarArrowSvg');
  svg.setAttribute('class', 'candyjarArrowSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M8.17756 5.83827L3.02462 0.685337C2.4663 0.127023 1.56006 0.127023 1.00174 0.685337C0.443429 1.24365 0.443429 2.1499 1.00174 2.70821L7.22411 8.93058C7.7514 9.45787 8.60506 9.45787 9.131 8.93058L15.3534 2.70821C15.9117 2.1499 15.9117 1.24365 15.3534 0.685337C14.7951 0.127023 13.8888 0.127023 13.3305 0.685337L8.17756 5.83827Z");
  path1.setAttributeNS(null, "fill", "#6D36AB");

  svg.appendChild(path1);

  var candyjarArrowDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarArrowDiv",
  });

   candyjarArrowDiv.append(svg);
   return candyjarArrowDiv;
}

function createMoikrugElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarMoikrugSvg');
  svg.setAttribute('class', 'candyjarMoikrugSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10 20C15.5228 20 20 15.5228 20 10C20 4.47715 15.5228 0 10 0C4.47715 0 0 4.47715 0 10C0 15.5228 4.47715 20 10 20Z");
  path1.setAttributeNS(null, "fill", "#4A4A4A");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M14.1231 14.2687H12.0197V9.50071L10.4681 12.287H9.53097L7.97942 9.50071V14.2687H5.87598V6.33789H8.15134L9.99956 9.48221L11.8478 6.33789H14.1231V14.2687Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarMoikrugDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarMoikrugDiv",
  });

   candyjarMoikrugDiv.append(svg);
   candyjarMoikrugDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'moikrug_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarMoikrugDiv;
}

function createCandyjarElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarCandyjarSvg');
  svg.setAttribute('class', 'candyjarCandyjarSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M15.3329 12.8837C14.717 12.5764 13.9685 12.8185 13.6653 13.4236C13.6653 13.4236 13.6369 13.4888 13.6179 13.5167C12.5283 15.6393 9.90377 16.5145 7.73401 15.4997C7.73401 15.4997 7.66769 15.4718 7.62979 15.4532C7.22237 15.2483 6.85284 14.9877 6.54017 14.6898C5.60215 13.796 5.08103 12.5299 5.19473 11.2545C5.25158 10.5935 5.4316 10.0908 5.5074 9.91387C5.55478 9.79285 5.61163 9.68113 5.66848 9.5601C5.68743 9.53217 5.71585 9.46701 5.72532 9.46701C6.86232 7.38163 9.49635 6.55307 11.6566 7.63299C11.6851 7.65161 11.7514 7.67954 11.7514 7.67954C12.3673 7.98676 13.1158 7.74471 13.419 7.13958C13.7316 6.53445 13.4853 5.79898 12.8694 5.49176C12.86 5.48245 12.8031 5.45452 12.7747 5.44521C9.41108 3.77877 5.32738 5.04489 3.54609 8.28467C3.51766 8.33122 3.46081 8.44294 3.45134 8.46156C1.71743 11.8224 3.09129 15.9279 6.52122 17.6316C6.54017 17.6409 6.67282 17.7061 6.70124 17.7154C10.0838 19.2794 14.1485 17.9202 15.8446 14.6153C15.854 14.5967 15.8825 14.5315 15.8919 14.5222C16.1951 13.9264 15.9488 13.1909 15.3329 12.8837Z");
  path1.setAttributeNS(null, "fill", "#FF4F9B");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M16.4604 8.94622C17.2373 7.42874 17.4458 5.61335 16.8962 3.85381V3.8445C16.8962 3.83519 16.8867 3.80726 16.8867 3.80726C16.8583 3.70486 16.8109 3.60245 16.7446 3.50935C16.3751 2.94146 15.5982 2.77388 15.0202 3.13696C14.518 3.45349 14.319 4.06793 14.5275 4.59859C14.9633 6.02297 14.6033 7.49391 13.7505 8.59245C12.8125 9.79341 11.2586 10.473 9.62893 10.2589C9.59103 10.2496 9.52471 10.2403 9.52471 10.2403C8.84251 10.1472 8.21716 10.622 8.12241 11.283C8.02766 11.9533 8.50141 12.5677 9.18361 12.6608C9.19308 12.6608 9.25941 12.6701 9.28783 12.6701C12.2724 13.0704 15.0676 11.5436 16.3846 9.05794C16.394 9.06725 16.4604 8.94622 16.4604 8.94622Z");
  path2.setAttributeNS(null, "fill", "#6D36AB");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarCandyjarDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarCandyjarDiv",
  });


   candyjarCandyjarDiv.append(svg);
   candyjarCandyjarDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'candyjar_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarCandyjarDiv;
}

function createEyeElement() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarEyeSvg');
  svg.setAttribute('class', 'candyjarEyeSvg');
  svg.setAttribute('fill', 'none');

  // path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  // path1.setAttributeNS(null, "fill-rule", "evenodd");
  // path1.setAttributeNS(null, "fill-rule", "evenodd");
  // path1.setAttributeNS(null, "d", "M10.084 20.8413C15.6068 20.8413 20.084 16.3642 20.084 10.8413C20.084 5.31846 15.6068 0.841309 10.084 0.841309C4.56114 0.841309 0.0839844 5.31846 0.0839844 10.8413C0.0839844 16.3642 4.56114 20.8413 10.084 20.8413Z");
  // path1.setAttributeNS(null, "fill", "white");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M10.0836 5.20386C5.51158 5.20386 3.34071 9.12295 2.81405 10.2416C2.72605 10.4283 2.72605 10.6448 2.81405 10.8315C3.34071 11.9508 5.51158 15.8705 10.0836 15.8705C14.6396 15.8705 16.8119 11.9791 17.3479 10.8445C17.4399 10.6491 17.4399 10.4252 17.3479 10.2299C16.8119 9.09523 14.6396 5.20386 10.0836 5.20386ZM10.0836 7.20386C11.9242 7.20386 13.4169 8.69652 13.4169 10.5372C13.4169 12.3779 11.9242 13.8705 10.0836 13.8705C8.24291 13.8705 6.75024 12.3779 6.75024 10.5372C6.75024 8.69652 8.24291 7.20386 10.0836 7.20386ZM10.0836 8.53719C9.55315 8.53719 9.04444 8.7479 8.66936 9.12298C8.29429 9.49805 8.08358 10.0068 8.08358 10.5372C8.08358 11.0676 8.29429 11.5763 8.66936 11.9514C9.04444 12.3265 9.55315 12.5372 10.0836 12.5372C10.614 12.5372 11.1227 12.3265 11.4978 11.9514C11.8729 11.5763 12.0836 11.0676 12.0836 10.5372C12.0836 10.0068 11.8729 9.49805 11.4978 9.12298C11.1227 8.7479 10.614 8.53719 10.0836 8.53719Z");
  path2.setAttributeNS(null, "fill", "#6D36AB");

  //svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarEyeDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarEyeDiv",
  });

   candyjarEyeDiv.append(svg);
   return candyjarEyeDiv;
}

function createHhElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarHhSvg');
  svg.setAttribute('class', 'candyjarHhSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.2567 20.4779C15.7071 20.4779 20.1256 16.0594 20.1256 10.609C20.1256 5.15865 15.7071 0.740234 10.2567 0.740234C4.80636 0.740234 0.387939 5.15865 0.387939 10.609C0.387939 16.0594 4.80636 20.4779 10.2567 20.4779Z");
  path1.setAttributeNS(null, "fill", "#FF4949");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M5.50244 14.1965V6.41797H6.89587V9.80723C7.35094 9.0453 7.9378 8.66434 8.65649 8.66434C9.11783 8.66434 9.48188 8.81705 9.74864 9.12248C10.0154 9.42791 10.1488 9.84499 10.1488 10.3737V14.1965H8.75535V10.7334C8.75535 10.1192 8.56077 9.81216 8.17162 9.81216C7.7291 9.81216 7.30386 10.1389 6.89587 10.7925V14.1965H5.50244Z");
  path2.setAttributeNS(null, "fill", "white");

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "d", "M10.7803 14.1965V6.41797H12.1737V9.80723C12.6288 9.0453 13.2156 8.66434 13.9343 8.66434C14.3957 8.66434 14.7597 8.81705 15.0265 9.12248C15.2932 9.42791 15.4266 9.84499 15.4266 10.3737V14.1965H14.0332V10.7334C14.0332 10.1192 13.8386 9.81216 13.4494 9.81216C13.0069 9.81216 12.5817 10.1389 12.1737 10.7925V14.1965H10.7803Z");
  path3.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);
  svg.appendChild(path3);

  var candyjarHhDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarHhDiv",
  });

   candyjarHhDiv.append(svg);
   candyjarHhDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'hh_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarHhDiv;
}

function createStackoverflowElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarStackoverflowSvg');
  svg.setAttribute('class', 'candyjarStackoverflowSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M9.88639 19.8734C15.3368 19.8734 19.7552 15.4549 19.7552 10.0046C19.7552 4.55416 15.3368 0.135742 9.88639 0.135742C4.43599 0.135742 0.0175781 4.55416 0.0175781 10.0046C0.0175781 15.4549 4.43599 19.8734 9.88639 19.8734Z");
  path1.setAttributeNS(null, "fill", "#FF7800");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M13.3783 4.50488L13.2183 4.53276L13.2182 4.53277L13.2182 4.53277C12.9782 4.57458 12.7406 4.61596 12.4981 4.65775C12.6069 5.28498 12.7157 5.91113 12.8246 6.537C12.9544 7.28369 13.0841 8.03 13.2136 8.77731C13.3815 8.74828 13.5473 8.71945 13.7126 8.69071L13.7139 8.69047L13.7145 8.69037L13.7148 8.69032L14.0941 8.62444C13.8553 7.24738 13.6171 5.87674 13.3783 4.50488ZM9.95968 5.8803L11.3238 7.8804L12.316 9.33518C12.5643 9.16549 12.8086 8.99886 13.0541 8.83162L12.7315 8.35874L12.7306 8.35744L12.7297 8.35612C12.0511 7.36142 11.3748 6.37003 10.6977 5.37705C10.4507 5.54521 10.2073 5.71123 9.95968 5.8803ZM11.9791 10.7469H12.6881V15.0961H5.78296V10.7469H6.49167V14.3914H11.9785C11.9791 13.1754 11.9791 11.9629 11.9791 10.7469ZM8.56966 7.33228C9.77 8.04038 10.9679 8.74695 12.1713 9.45657C12.0843 9.60437 11.9975 9.75157 11.9103 9.89938L11.9098 9.90013L11.9097 9.90037L11.9095 9.9006L11.7176 10.2261C10.5977 9.56559 9.48157 8.90745 8.36444 8.24872L8.35498 8.24315L8.11533 8.10183L8.56966 7.33228ZM9.16063 9.81073C9.98775 10.033 10.8148 10.2553 11.6438 10.4786L11.6345 10.5132L11.6345 10.5133L11.6344 10.5135C11.5605 10.7891 11.4871 11.063 11.4117 11.3411C10.6738 11.1425 9.93638 10.9444 9.19864 10.7461L9.1957 10.7454L9.19192 10.7443C8.58608 10.5815 7.98 10.4187 7.37318 10.2554L7.60554 9.39265L9.16063 9.81073ZM11.2649 12.7911H7.09028V13.6793H11.2649V12.7911ZM9.64515 11.4841C10.2195 11.537 10.7941 11.59 11.3695 11.6429C11.353 11.8188 11.3369 11.9936 11.3207 12.169C11.3095 12.2897 11.2983 12.4107 11.287 12.5326C10.7661 12.4847 10.2456 12.4368 9.72513 12.3888C8.85828 12.309 7.99143 12.2291 7.12279 12.1492C7.14138 11.9484 7.15997 11.7492 7.17866 11.5489C7.18763 11.4528 7.19662 11.3564 7.20564 11.2595C8.01933 11.3341 8.83196 11.409 9.64515 11.4841Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarStackoverflowDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarStackoverflowDiv",
  });

   candyjarStackoverflowDiv.append(svg);
   candyjarStackoverflowDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'stackover_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarStackoverflowDiv;
}

function createVkElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarVkSvg');
  svg.setAttribute('class', 'candyjarVkSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.5714 19.8734C16.0218 19.8734 20.4403 15.4549 20.4403 10.0046C20.4403 4.55416 16.0218 0.135742 10.5714 0.135742C5.12105 0.135742 0.702637 4.55416 0.702637 10.0046C0.702637 15.4549 5.12105 19.8734 10.5714 19.8734Z");
  path1.setAttributeNS(null, "fill", "#006299");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M16.0912 12.7344C16.0777 12.7053 16.0651 12.6811 16.0534 12.6618C15.8598 12.3131 15.4899 11.8852 14.9438 11.3778L14.9323 11.3662L14.9265 11.3605L14.9207 11.3547H14.9148C14.667 11.1184 14.51 10.9596 14.4443 10.8782C14.3241 10.7233 14.2971 10.5665 14.3629 10.4076C14.4093 10.2876 14.5837 10.034 14.8857 9.6467C15.0445 9.44142 15.1703 9.2769 15.2632 9.15294C15.9333 8.26216 16.2238 7.69293 16.1347 7.44504L16.1001 7.38711C16.0768 7.35224 16.0168 7.32034 15.9201 7.29124C15.8231 7.2622 15.6992 7.2574 15.5482 7.27675L13.8752 7.28831C13.8481 7.27871 13.8094 7.2796 13.7589 7.29124C13.7086 7.30288 13.6834 7.30872 13.6834 7.30872L13.6543 7.32327L13.6312 7.34074C13.6118 7.3523 13.5905 7.37263 13.5672 7.40168C13.5441 7.43064 13.5247 7.46462 13.5093 7.50334C13.3271 7.97195 13.12 8.40764 12.8876 8.81038C12.7443 9.05054 12.6127 9.25867 12.4925 9.43489C12.3725 9.61106 12.2718 9.74085 12.1905 9.82405C12.1091 9.90733 12.0357 9.97405 11.9697 10.0244C11.9039 10.0749 11.8536 10.0962 11.8188 10.0884C11.7839 10.0806 11.751 10.0729 11.7199 10.0651C11.6657 10.0302 11.6221 9.98282 11.5893 9.92279C11.5563 9.86277 11.5341 9.78722 11.5224 9.69621C11.5109 9.60514 11.504 9.5268 11.5021 9.46094C11.5003 9.39515 11.5011 9.30211 11.505 9.18206C11.5091 9.06195 11.5109 8.98069 11.5109 8.93808C11.5109 8.79089 11.5137 8.63115 11.5195 8.45881C11.5254 8.28647 11.5301 8.14992 11.5341 8.04933C11.538 7.94863 11.5399 7.84209 11.5399 7.72978C11.5399 7.61746 11.533 7.52938 11.5195 7.46545C11.5062 7.4016 11.4857 7.33962 11.4587 7.27954C11.4315 7.21952 11.3917 7.17309 11.3396 7.14012C11.2873 7.1072 11.2223 7.08108 11.145 7.06167C10.9397 7.01521 10.6783 6.99008 10.3607 6.98618C9.64037 6.97845 9.17753 7.02496 8.97227 7.12566C8.89095 7.1682 8.81735 7.22633 8.75155 7.29987C8.68182 7.3851 8.6721 7.43161 8.72243 7.43926C8.95484 7.47408 9.11936 7.55736 9.21619 7.68902L9.25109 7.75879C9.27823 7.80913 9.30533 7.89825 9.33246 8.02603C9.35954 8.15381 9.37702 8.29516 9.38471 8.45C9.40404 8.73276 9.40404 8.97481 9.38471 9.17616C9.36532 9.3776 9.347 9.53441 9.32953 9.64672C9.31205 9.75904 9.28592 9.85005 9.25109 9.91974C9.21619 9.98945 9.19298 10.0321 9.18134 10.0475C9.16972 10.063 9.16004 10.0727 9.15234 10.0766C9.10201 10.0958 9.04965 10.1057 8.99547 10.1057C8.9412 10.1057 8.8754 10.0785 8.79796 10.0243C8.72054 9.97004 8.64019 9.89553 8.55691 9.80063C8.47363 9.70571 8.37971 9.57307 8.27511 9.40268C8.17058 9.2323 8.06213 9.03092 7.94982 8.79856L7.8569 8.63005C7.7988 8.52164 7.71945 8.36379 7.61875 8.15664C7.518 7.9494 7.42894 7.74894 7.35152 7.5553C7.32057 7.47398 7.27408 7.41206 7.21212 7.36945L7.18304 7.35198C7.16372 7.33651 7.13269 7.32009 7.09012 7.30259C7.04749 7.28512 7.00302 7.27258 6.9565 7.26487L5.36478 7.27643C5.20213 7.27643 5.09177 7.31328 5.03365 7.38687L5.0104 7.42168C4.99878 7.44107 4.99292 7.47204 4.99292 7.51467C4.99292 7.55728 5.00454 7.60957 5.02779 7.67148C5.26016 8.2176 5.51285 8.74428 5.78586 9.25161C6.05888 9.75894 6.29612 10.1676 6.49745 10.4772C6.69883 10.7871 6.90409 11.0796 7.11323 11.3544C7.32238 11.6294 7.46082 11.8057 7.52856 11.8831C7.59637 11.9606 7.64964 12.0186 7.68836 12.0573L7.83362 12.1967C7.92656 12.2897 8.06305 12.4011 8.24314 12.5308C8.42327 12.6606 8.62269 12.7883 8.8415 12.9143C9.06036 13.0401 9.31496 13.1427 9.60545 13.2221C9.8959 13.3015 10.1786 13.3334 10.4536 13.318H11.1217C11.2572 13.3063 11.3598 13.2637 11.4296 13.1902L11.4527 13.1611C11.4682 13.138 11.4828 13.102 11.4962 13.0537C11.5098 13.0053 11.5166 12.952 11.5166 12.894C11.5126 12.7275 11.5253 12.5774 11.5542 12.4438C11.5832 12.3103 11.6162 12.2096 11.6531 12.1417C11.69 12.074 11.7316 12.0168 11.778 11.9705C11.8244 11.924 11.8575 11.8959 11.8769 11.8862C11.8962 11.8764 11.9116 11.8698 11.9232 11.8659C12.0161 11.8349 12.1255 11.8649 12.2515 11.956C12.3774 12.047 12.4955 12.1594 12.6059 12.2929C12.7163 12.4266 12.8489 12.5766 13.0038 12.7431C13.1588 12.9096 13.2943 13.0335 13.4104 13.1149L13.5266 13.1846C13.6041 13.2311 13.7048 13.2737 13.8288 13.3125C13.9525 13.3512 14.0609 13.3608 14.154 13.3415L15.6411 13.3183C15.7882 13.3183 15.9026 13.2939 15.9838 13.2456C16.0652 13.1972 16.1135 13.1439 16.1291 13.0859C16.1446 13.0278 16.1455 12.9619 16.132 12.8883C16.1183 12.8148 16.1047 12.7634 16.0912 12.7344Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarVkDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarVkDiv",
  });

   candyjarVkDiv.append(svg);
   candyjarVkDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'vk_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarVkDiv;
}

function createTwitterElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarTwitterSvg');
  svg.setAttribute('class', 'candyjarTwitterSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.516 19.8734C15.9664 19.8734 20.3848 15.4549 20.3848 10.0046C20.3848 4.55416 15.9664 0.135742 10.516 0.135742C5.06563 0.135742 0.647217 4.55416 0.647217 10.0046C0.647217 15.4549 5.06563 19.8734 10.516 19.8734Z");
  path1.setAttributeNS(null, "fill", "#008EDE");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M15.9544 6.63124C15.554 6.80862 15.1245 6.92892 14.6732 6.98262C15.134 6.70668 15.4868 6.26899 15.6539 5.74905C15.2217 6.00459 14.7446 6.19015 14.2362 6.29074C13.8291 5.85645 13.25 5.58594 12.6077 5.58594C11.3755 5.58594 10.3764 6.58503 10.3764 7.81656C10.3764 7.99122 10.3961 8.16182 10.4342 8.32495C8.58011 8.23182 6.93604 7.34352 5.83568 5.99372C5.64333 6.32268 5.53391 6.70598 5.53391 7.11515C5.53391 7.88928 5.92811 8.57233 6.52621 8.97196C6.16055 8.95973 5.81665 8.85914 5.51557 8.69194V8.71981C5.51557 9.80045 6.28494 10.7023 7.30509 10.9076C7.11818 10.9579 6.92109 10.9858 6.71719 10.9858C6.57311 10.9858 6.43378 10.9715 6.29717 10.9443C6.58125 11.8313 7.40501 12.4762 8.38099 12.4939C7.61774 13.092 6.65535 13.4475 5.61005 13.4475C5.42995 13.4475 5.25254 13.4366 5.07788 13.4169C6.06542 14.051 7.23782 14.4208 8.4979 14.4208C12.6023 14.4208 14.8459 11.0211 14.8459 8.0728L14.8384 7.78395C15.2767 7.47128 15.656 7.07845 15.9544 6.63124Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarTwitterDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarTwitterDiv",
  });

   candyjarTwitterDiv.append(svg);
   candyjarTwitterDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'twitter_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarTwitterDiv;
}

function createGitlabElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarGitlabSvg');
  svg.setAttribute('class', 'candyjarGitlabSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10 20.6412C15.5228 20.6412 20 16.1641 20 10.6412C20 5.11839 15.5228 0.641235 10 0.641235C4.47715 0.641235 0 5.11839 0 10.6412C0 16.1641 4.47715 20.6412 10 20.6412Z");
  path1.setAttributeNS(null, "fill", "#FFE3BB");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M10.0001 16.8747L7.54395 9.81323H12.4563L10.0001 16.8747Z");
  path2.setAttributeNS(null, "fill", "#E53935");

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "d", "M10 16.8747L15.5264 9.81323H12.4562L10 16.8747Z");
  path3.setAttributeNS(null, "fill", "#FF7043");

  path4 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path4.setAttributeNS(null, "fill-rule", "evenodd");
  path4.setAttributeNS(null, "fill-rule", "evenodd");
  path4.setAttributeNS(null, "d", "M13.9912 5.20789L15.5263 9.81321H12.4561L13.9912 5.20789Z");
  path4.setAttributeNS(null, "fill", "#E53935");

  path5 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path5.setAttributeNS(null, "fill-rule", "evenodd");
  path5.setAttributeNS(null, "fill-rule", "evenodd");
  path5.setAttributeNS(null, "d", "M10 16.8747L15.5264 9.81323L16.4475 12.2694L10 16.8747Z");
  path5.setAttributeNS(null, "fill", "#FFA726");

  path6 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path6.setAttributeNS(null, "fill-rule", "evenodd");
  path6.setAttributeNS(null, "fill-rule", "evenodd");
  path6.setAttributeNS(null, "d", "M10 16.8747L4.47363 9.81323H7.54385L10 16.8747Z");
  path6.setAttributeNS(null, "fill", "#FF7043");

  path7 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path7.setAttributeNS(null, "fill-rule", "evenodd");
  path7.setAttributeNS(null, "fill-rule", "evenodd");
  path7.setAttributeNS(null, "d", "M6.00874 5.20789L4.47363 9.81321H7.54385L6.00874 5.20789Z");
  path7.setAttributeNS(null, "fill", "#E53935");

  path8 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path8.setAttributeNS(null, "fill-rule", "evenodd");
  path8.setAttributeNS(null, "fill-rule", "evenodd");
  path8.setAttributeNS(null, "d", "M10.0002 16.8747L4.4738 9.81323L3.55273 12.2694L10.0002 16.8747Z");
  path8.setAttributeNS(null, "fill", "#FFA726");

  svg.appendChild(path1);
  svg.appendChild(path2);
  svg.appendChild(path3);
  svg.appendChild(path4);
  svg.appendChild(path5);
  svg.appendChild(path6);
  svg.appendChild(path7);
  svg.appendChild(path8);

  var candyjarGitlabDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarGitlabDiv",
  });

   candyjarGitlabDiv.append(svg);
   candyjarGitlabDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'gitlab_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarGitlabDiv;
}

function createBitbucketElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarBitbucketSvg');
  svg.setAttribute('class', 'candyjarBitbucketSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.0011 0.641235C4.48574 0.641235 0 5.12698 0 10.6423C0 16.156 4.48574 20.6412 10.0011 20.6412C15.5148 20.6412 20 16.156 20 10.6423C20 5.12698 15.5148 0.641235 10.0011 0.641235Z");
  path1.setAttributeNS(null, "fill", "#0081DA");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M10.0002 5.76135C7.34613 5.76135 5.2002 6.36698 5.2002 7.13948L5.22832 7.27635L5.9202 11.7614C5.9202 12.5329 7.82613 13.2014 10.0002 13.2014C12.1743 13.2014 14.0802 12.5329 14.0802 11.7614L14.7721 7.27635L14.8002 7.13948C14.8002 6.36698 12.6543 5.76135 10.0002 5.76135ZM10.0002 6.48135C11.8508 6.48135 13.3602 6.8451 13.3602 7.32135C13.3602 7.7976 11.8508 8.16135 10.0002 8.16135C8.14957 8.16135 6.6402 7.7976 6.6402 7.32135C6.6402 6.8451 8.14957 6.48135 10.0002 6.48135ZM10.0002 9.36135C10.8064 9.36135 11.4402 9.9951 11.4402 10.8014C11.4402 11.6076 10.8064 12.2414 10.0002 12.2414C9.19395 12.2414 8.5602 11.6076 8.5602 10.8014C8.5602 9.9951 9.19395 9.36135 10.0002 9.36135ZM10.0002 10.0814C9.6027 10.0814 9.2802 10.4039 9.2802 10.8014C9.2802 11.1989 9.6027 11.5214 10.0002 11.5214C10.3977 11.5214 10.7202 11.1989 10.7202 10.8014C10.7202 10.4039 10.3977 10.0814 10.0002 10.0814ZM6.58301 13.0598L6.89426 15.2695C6.89426 15.8404 8.29488 16.3073 9.93176 16.3204C11.5677 16.3073 12.9674 15.8395 12.9674 15.2695L13.2702 13.1226C12.3899 13.4892 11.1768 13.6814 10.0002 13.6814C8.75707 13.6814 7.47176 13.4676 6.58301 13.0598Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarBitbucketDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarBitbucketDiv",
  });

   candyjarBitbucketDiv.append(svg);
   candyjarBitbucketDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'bitbucket_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarBitbucketDiv;
}

function createWebsiteElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarWebsiteSvg');
  svg.setAttribute('class', 'candyjarWebsiteSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.0011 0.641235C4.48574 0.641235 0 5.12698 0 10.6423C0 16.156 4.48574 20.6412 10.0011 20.6412C15.5148 20.6412 20 16.156 20 10.6423C20 5.12698 15.5148 0.641235 10.0011 0.641235Z");
  path1.setAttributeNS(null, "fill", "#008EDE");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M10 3.54126C9.1045 3.54126 8.14314 4.82456 7.55664 6.85181C7.49364 7.07006 7.66409 7.29126 7.89209 7.29126H12.1079C12.3352 7.29126 12.5049 7.07006 12.4419 6.85181C11.8561 4.82456 10.8955 3.54126 10 3.54126ZM6.29541 4.60327C6.22573 4.59471 6.15129 4.60849 6.08154 4.65161C5.20929 5.18936 4.45616 5.90201 3.86816 6.73901C3.70466 6.97151 3.86077 7.29126 4.14502 7.29126H5.61279C5.77179 7.29126 5.90856 7.17844 5.94531 7.02319C6.11406 6.31369 6.32541 5.6621 6.57666 5.07935C6.67453 4.85378 6.50445 4.62897 6.29541 4.60327ZM13.7046 4.60327C13.4955 4.62901 13.3246 4.85469 13.4219 5.08081C13.6731 5.66281 13.8867 6.31516 14.0547 7.02466C14.0922 7.17916 14.2282 7.29126 14.3872 7.29126H15.855C16.1392 7.29126 16.2953 6.97151 16.1318 6.73901C15.5438 5.90201 14.7907 5.19011 13.9185 4.65161C13.8487 4.60849 13.7743 4.59469 13.7046 4.60327ZM3.10937 8.79126C2.95412 8.79126 2.813 8.89396 2.771 9.04321C2.59475 9.67996 2.5 10.349 2.5 11.0413C2.5 11.7335 2.59475 12.4026 2.771 13.0393C2.81225 13.1886 2.95412 13.2913 3.10937 13.2913H5.25537C5.45937 13.2913 5.61546 13.118 5.59521 12.9148C5.53521 12.3133 5.5 11.6893 5.5 11.0413C5.5 10.3933 5.53521 9.76923 5.59521 9.16773C5.61546 8.96448 5.45937 8.79126 5.25537 8.79126H3.10937ZM7.4585 8.79126C7.283 8.79126 7.13379 8.91902 7.11279 9.09302C7.04079 9.71027 7 10.3618 7 11.0413C7 11.7208 7.04079 12.3723 7.11279 12.9895C7.13379 13.1635 7.283 13.2913 7.4585 13.2913H12.5415C12.717 13.2913 12.867 13.1635 12.8872 12.9895C12.96 12.3723 13 11.7208 13 11.0413C13 10.3618 12.9592 9.71027 12.8872 9.09302C12.8662 8.91902 12.717 8.79126 12.5415 8.79126H7.4585ZM14.7446 8.79126C14.5406 8.79126 14.3845 8.96448 14.4048 9.16773C14.4648 9.76923 14.5 10.3933 14.5 11.0413C14.5 11.6893 14.4648 12.3133 14.4048 12.9148C14.3845 13.118 14.5406 13.2913 14.7446 13.2913H16.8906C17.0459 13.2913 17.187 13.1886 17.229 13.0393C17.4053 12.4026 17.5 11.7335 17.5 11.0413C17.5 10.349 17.4053 9.67996 17.229 9.04321C17.1878 8.89396 17.0459 8.79126 16.8906 8.79126H14.7446ZM4.14502 14.7913C3.86077 14.7913 3.70466 15.111 3.86816 15.3435C4.45616 16.1805 5.20929 16.8924 6.08154 17.4309C6.36054 17.6034 6.70787 17.3032 6.57812 17.0017C6.32687 16.4197 6.11331 15.7674 5.94531 15.0579C5.90781 14.9034 5.77179 14.7913 5.61279 14.7913H4.14502ZM7.89209 14.7913C7.66484 14.7913 7.49511 15.0125 7.55811 15.2307C8.14386 17.258 9.1045 18.5413 10 18.5413C10.8955 18.5413 11.8569 17.258 12.4434 15.2307C12.5064 15.0125 12.3359 14.7913 12.1079 14.7913H7.89209ZM14.3872 14.7927C14.2282 14.792 14.0914 14.9041 14.0547 15.0593C13.8859 15.7688 13.6746 16.4204 13.4233 17.0032C13.2936 17.3047 13.6387 17.6041 13.9185 17.4324C14.7907 16.8946 15.5438 16.182 16.1318 15.345C16.2953 15.1125 16.1392 14.7927 15.855 14.7927H14.3872Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarWebsiteDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarWebsiteDiv",
  });

   candyjarWebsiteDiv.append(svg);
   candyjarWebsiteDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'website_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarWebsiteDiv;
}

function createHabrElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarHabrSvg');
  svg.setAttribute('class', 'candyjarHabrSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10.0011 0.641235C4.48574 0.641235 0 5.12698 0 10.6423C0 16.156 4.48574 20.6412 10.0011 20.6412C15.5148 20.6412 20 16.156 20 10.6423C20 5.12698 15.5148 0.641235 10.0011 0.641235Z");
  path1.setAttributeNS(null, "fill", "#7AA0B1");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","image");
  path2.setAttribute("width", "300");
  path2.setAttribute("height", "300");
  path2.setAttributeNS('http://www.w3.org/1999/xlink', "xlink:href", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAYAAAB5fY51AAAABHNCSVQICAgIfAhkiAAAIABJREFUeJztnVus5WZ1x9ey9zlJpgVVCpWAkpcqSgsPNCUXiUaVeEKqEibpBIGKaC6QPvVCWwHNSWl5gMxAIpWHikqogWRKLwoiaWYSWpGHSn2gSLkVeCA0jfoSClSCikIYMucce/XB296f7e/q7cvn7f9PmjPb9nezj7//WWt9y95EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEzw1APowumHn7why46vEsqvIOHLmekSpiQVZpl6bADEBouwUJ6J0EVi+QFT8lKarl64591v/8rUYwslesH6o7Nf+IXL5JJbROg6YbqeRK4kooSYk4SJmROawWkAEAFCIjnlsv5AlBPziyz0FOf09E9XFx/71O3v+u+pR2kj2pl+cPb8TZzLncT8ViJ5XZKmJHlOIjCiAOgLZiZOEsqzjIj4uyTyVUn4wTO3n3xi6rHpiE6wDs4+9k4mPmBO3sLMECkARqIULxEhkfw5oeTMmdvf8cWpx6USjWDd89C5G0nk46v9/auz42xtsQIApoA5oXSV0vHh4deI+SOn77j5S1OPiSgCwfrwZ8+9Kk3kE8zJ7zDTHqwpAOKBmUmEjkTyv375xy8f/OUfvPdHk45nys4PHnz8l5nlb9NVek12fDzlUAAAFtLVirLj7FkRfu+ZO9/xranGMZlgHTx07iQL/UOSJifyHO4fALGTJAnlWX5BmH7rzB03n59kDFN0evfZc7/HTI8QE8QKgJmQ5zkR0wkmeuSeh8797hRjGN3CWp/oXxDR/th9AwB6gIlI6JCI/vj0HTd/euyuR+NP/+b8zXmeP8LE6Zj9AgD6R0iyJEluvfe2k+fG6nM0wfrwA4++cZWmz1BCJwgLgQDMHyainC4cZ9m199116vkxuhwlhvXRzzx+Il0ln+ckgVgBsCsIESfJiXSVfP6jn3n8xBhdjiJYh5dm96ervWuQDArAbiGSU7rau+bw0uz+Mfob3CU8OHv+JhJ5lIn2hu4LADANQnREOZ86875hn0Ec3sLK848lzBArAHaYhHmPk/xjg/czZON3P3T+1tXe/tV43AaA3UZEKF3tX333Q+dvHbKfQQWLJT/IMzxyA8ASyLNjYsoPhuxjMME6OHv+pjRdXQPrCoBlICKUJOk1B2fP3zRUH8NZWLm8f/p3QQAAxoSZiYXeP1T7gwjWhx78wmuJ6fo8QxoDAEsiz3ISkus/9OCXXjtE+4MI1h5fciszv56QJQrAwhBi5tfv8fEgwfdBBEuErkuSSV4EAQCYmCRJSISuG6TtIRoVousFr40BYJFInpMQXT9E20OZQVdidRCAZbKe+1cO0XbvgnX64SdvIBL4gwAsGklOP/xPN/Tdau/CkmX5VVR8uykAYKkwJ1mWXNV3s70Li9DxFQkzMrAAWDAJMwsdX9F7u303yJS8BnoFwLJhZiLmy/tudwjX7dIIvu4QADApTJTzpX23OoBLCPMKAECUDBDL7t8lZEY+AwCAZAAtwGoeAGA2QLAAALMBggUAmA0QLADAbIBgAQBmAwQLADAbIFgAgNkAwQIAzAYIFgBgNkCwQCfaz1/hiSwwPKupBwDip5KixmOi/YmWVN9Xgue6gA0IFqjg+o9xe2ZlDDVE1TOwcCBYC8VkNcUHq3pWIAIBWygQrIVRGFCxi5QD5rWAwfpaGhCsBbC7b4BtWF+wvHYeCNaOMpQlZW/RdNQsI70KTGV5EcRrR4Fg7Rh9W1PadcHgLswVile81aWlF6EpxQvCtVNAsHaEbYWqJUxjeZGaVcmNlVT96C46SrwL3+07fyBYM4a3EBZWP8Ua4lLETHX1iLoIGG88ZFhdswWCNUO6WlNc+xCrSjlYn/vmbeEdBAzu4myBYM2MULEa05KyNd+7MNTVl7iL5cVMDFdxVkCwZkJnoeohCN+H6BmrNYLu28SqiDZBfP921q4irK1ZAMGKHA5036qIz1bCMl3QvZnRThRqNRU/uKroKUQIzs8CCFakhORRbWsBRZv9zpV8bideQXULi0ugWlECwYqQEPevi9jM5zlChZp4FT+8JaUhfD71uFAtuImRAcGKiHCryt+i6sPV49aH1oYH4vroOZCOWe3M/nGutZsIayseIFiR4Bur6iRUHSwwoaZA9WWNseGjbCFggWkKiqsIa2teQLAiwMcFDHXjOruKTetlNFijZYEv9uPAYHuI0LG/wIHhgGBNiK+ohLmKw1pf47I5l6BM99pKob8YudtFwunUQLAmwkcsfN2/EDeR6z+CMNYIaUoz00Pdv6JLT+vLV2SqPC5YWzEDwZoAfxfQLkJhgkbdVxP1jQW11a6/me7cmPm+6QeV9eVrHfm4iutyTjlClvwkQLBGpAxmXzzOyDa9fNy6KsrEZav6/jYTu95gwkR7aaopr24M6S7qg+/Fpj0Af5hlGqEQ/9iVTzmnaDHtpwkxM1YRRwSCNRKlC/izl+zTb1z7Jlollm9Y89IJH3fSzA8v/JS+/Ny3KCmtrh4EylS7y5sVWiuI64ZyEbrp2jfRz524zNqCu0/PURmKHec5/fMz36SfXDyEaI0IBGsESrESIrpkf4/e/Itv2AjFRHz/Ry/Tl5/7VmFqBc41u6toOGTow9v9IyJKiCQT+qU3vJZe8+qf8ao5FLkI/cs3/pNevnhITATRGgkI1sA0g+siQlmWU7JKjXXGIM+l+dxxC3u4KlBwtcWlvtsVRF8fyPM8rO8ByLK8JVAQreGBYA1I/GkDdfrJZO/UY22TNQGsucgARGtYIFgDMRex0oeuzONWjwiFy1mzjm25YPNRihU+/xSzSYFoDQcEawBmI1asX0GslbHW79AnUU2lmk0YBYzXhWdwXYkgWkMBweoZl1hFM90MASqzsdXjyA3xLCJHTlZk8991RSBa/QPB6hEvsYpGsTboQ1b+A/UtaZ+6rWdwis2Y5zuX8TbL7xyi1SsQrD5xiJVUP+Kg8rCqOeebgd+9vya29NnNf1KNMZ6rR8XvkhPnYzoQrf6AYPWE7XGbmuUV04wrRcowprBsBteJWcLrzkdzlDHGdP1KPJ4tND+PAEKAYPWAcw5FGyj2jV9pj27VV/uQmDYbEz02M2uNS7TwwHQvQLC2xB23inF2bbAH2dvxmaal0OXsyvr1thrJDqWvKnHqkxYP0cLT0tsBwdoWl1hFPNvcOVjc2tPa7pCI1e6hOtTYW14/vaxFiUO0oFnbAcHaAnfcyrA/OhyuoXZnxzNprALWDhljWWoiaTxX0BzOs6nS+rU0A41p14FgdcQ2b0xuYjxTjaiwXspszO7xqw4GlrlmQ7HYFseKAYsBbV0ZhJnVGQhWBwxTfLPXqmaRTLY1oYmifYfezUKk+I4xx7Esy3+2lUGkOnQDgtUFg+jYxKpIwYrrL2vbbfVwDbUHQ+Sk/jSzOTdLdQNjjWEVFmohTJrfqzOeBdEKBYIViP31xh2trqngtVtoebavvtN9DnYLSinRakq0IlYTL6ZIryOtX6usO4Z0hj6BYAXglCpzQKP/wfSFxdKxnZTvGZnKWZNDNeLlenfX5NiEyWJZw8oKA4IVQidXMGKxIl0Mq8Nige8pOiy5muPXEK+4r+IamzAR4ll9AMHyxG4kWcQq0plWrQ8a3D2/LIbAk7OkNDRFqS1ercjW5OjGYhQfVzyL4jYgYwGC5Y3NuvLbH10IphHDcqc26DPfQxHtBavnMGjjWDFdQCaSxCBaXTKtIluQiRUIlgemQLs9mB66fxrchhPXPvcxeqMlVX00rCTGNJ9LUdWZRqYgPKysrYFgDYDJuhJu758c9cG++gfNlmlnhyDWelO/qqiuJLbFK4pLqFwvrT1lsphslhSsLCcQLAedrCvdflXFophx5hiWWY86BOQbpaW+uWYjSuaUhognssGiMllM9gA8NMsGBMtCp5wr3SqbNedhQmwxLPPGVmcSYlFxs0xMMawahWK1RMtiZZldQziGNiBYHbAG2rX7YpxkRETcNlwaJxc0clthy+Mr9WIN8VKtLgke0aC0ZVyXXWYIwCM3qxMQLAP28HKIK9ifddI3bSPKQ6i6xq9MkXPRF6tZVYYs+OjQWU6mADzBluoCBMuESZMMx3QC19wT5WRrxKfsQlVOsU3ZdqKDmVKEahNVdQOVj/VYFrfLRYH+z1pLiDoE4BHL0gPBCsAUaDeGqEwWVyw3YhkTMmWSawPy3S1GNnyu5WU1UhrUssJMxNN/TT0RmZXaoDQm19BsZcH+0gHB0mAPtmtraNrwKjYda5U1C1Wf7qGfG1gcaqwKtoQrMY1mGnQun2FfcC5peJWdB4IVhM1PtO+M8eareVk+rqHG4jLvqR/VpzOsB6CzpnTCFeUzhbrfrCkAH5hMCr+wBQSrgT3vSrffbV1x/UccBAvVdosH7dVA5UgjsK6WbwlXl86HxtvK6hDLovj+0E0JBMsbP+vKPO1jm2W0jmERlV/uys1jPm6hqd2SkHQG3my1Xy+jEa5o8PcBTQJkFCZYWTUgWAqmSWm2rtyNxGZYVZTzX3tiDqGyBLVaQqSKUBOtRbXealhdMV7Hps3ZCqv3ZGWBDRAsldBgu3dkfWPBxDTnWvKiqIKfGLvPRid9Uv7UWGJW4RK/PsekZZVuYWXZ+oCUFUCwHBRz2C/IbI5deVSeimp53iBUrH7sZ+DNnooE9vqqYFu4IpuyBkX3srJChQzWVwUEa01wKkOgdWWvNxFMZvfPV6hCT0fnDa1/2oVLjWFFcA1Njwn5WFnBgSxQAsFy4mld+VWtXJvpqYJYhucJTfGt9oavfGzmeDuzXW3NKFy2eNjYsPK/hx4195lsLNOr/6BlBZFl4cWFOdBrD1RvSjSslwgMAxVuStI6yMbtI40A3KZEyClx9U+pqWmkVqZ1PKJIINf+I91WsctzX5f9CwMWFnW4/XWxqt47GYlaPpbGpqqJVH+ogq6zqMqjotoWsSaONoNU2riVtiaspkAgWESWv2peu/QCFv2zOWtM7p+PUHU9He2jObYYFpPEFnSv0XTlfONWYcF3xN7hEhrnXFh0xl4urK0RUVzA1n7SuIyNevqdtn+2+qor2D5ecxFjpDkuzfUxW69dO1kesLBCcbzfShurivg+Y2mLldGmasSSwk9rU6NmTVU7Ni1Xx+N+Iqe17Q6s2+sUO2FKmVi8hRX+rTe+9fWtxDTpapJTWT1G04dKm8toeQX1rQm+6463jLOYrqA6tKb1p7EGewicx3X24wMLy4Rv/MpVWREB1hyeiubcKv7rEMdSy7lSpAJzsMqeJc5oeyfaFlVYHGvpwMLSYA4ye8waV5HYJt62QXf1IKsWmGqLcb28T/wqYqvKTPv1hs6Rh4blFp7esGgLqw+3pr3NxuPxUZhEtqC7FtdxbXFD/Kq1mFa+O6tph6xtjmgu6kZVa9aQh2nkZT0hjqVl2RZWwM2vLdpp8hhMjClgk1gZolS8qbON1VOLX2kuRyUDrS6a0jcljWeHTGj+qmmD7MCLZQuW8W7T7W8a+7b6aiFufqQYohP6h2yLH1qdYKOMacva3L96UXPQ3SRo01+9Ev1DNPZr1M+CxVJZuGAZcOuVZcK7iGO6tXRArxt+7qHyT6tVDvEyWVu6Pwp9rFCOS/fxzus8x2HRMaxt6Ba/ivsWDIplOYRFU6y+2mfMdtetoTFtcrLiEPwN1Qi3GllQ/QXHtyBYDfqVFJ07GAe5EB0e55QkUrl7NUxiVbPEup6UIkuaeVcdlfa+PBfKY5urTbVxbet3AQ8WK1ghU61TwD0ygWry868+QR88+evRj7OFEF26P7/b1r2SqFO15VpSJub3m4+G0JkelzIwM112yd7Uw9gRPEwqa3lzFVhidZYbdA96JEe3QmivAZYHGz6D/liuYGkw3mQ+d59lEQ3sJv6/W8aN0BMQrCZbiFNIE2Dh+N4k+ENYY5GCNcwv289RXOqNtqvg9zkuixSsMYOYpi9XAfOn9eU4tm0N+BMXziIFa3uCohcdaoFdwPWIzoCN7ywQrD4IuHmwRA36YZmKtVDBGviXvcx7CVjBTdEHCxUsk53TvqnmnR4KYgL3xvYsVLAA6AEo0OhAsAAAswGCBQCYDRAsAMBsgGAB0BXkqIwOBKvG9ncg7mEAhgOC5aCTAEG1gAbcFtsDwRoZrIQvlb7lapnyB8HqhFg3TYeWeYsBPVveDQu9mSBYA8NEi725dp2ataz9Mg07uC3CgWD1ht/th5t0tzD+Pjv8ovVVcMeoQLC64HUP4UZbGkG/cd/ChnJLvbsgWArG7+kMvDsQt1oGzd+teUFFBrgRlrl8s2DBMt1B4YoV5RcSg0kZ/nZY5g23XMHa4vctnRpY5g22DJp3RIdwO1w/L5YrWNuCJSAQgBg3bDtxEzVZrGCF3Arb3jZwGXecof544Z5pga+qbyDULZxZ1NvUbm5vSsWBCNFRltXPNeY4rmz+20tT8xd3j44mQODxa24WCbsz4rmPxgaC1RGtsHVVuwn435cv0Bf+7euUsmJkc/GjdQpc/tfhu6uInPOrNuVbDxHU92ci9K5fezNd/qoT7rFEgfRvYC1XryBYWnTCI0LtP+uBClV9SeH0qiYi9H8XLtIqaUQFHKLlKVt+Y1B+6j+20wGO85xEYp6xLoHCG0G2YbExrIKQ1IYOxfRz0b/9wZH29JJyf6uocqy71bBpqmqQ1I/VEDRiJdSSuInpIN26lKyoBTguli1YAfeJT1H9dNouWjEoUsbb9CtUxsWsmnD5iVcpUjahIjJdQ2VfRJePiNoC1NevGyKmZdEuocmhMzp6DbfQ5RDOKKRFQrJx9sq5wqUYadzA2skFWFyWguZYlkS60toeUBdLOrrTiphFC9YgCBGxMpt12xHcodL8wA3RKo+tXzch6/2uNxS0Y3++Y/ELuseNS8B0VfQlzAH3WVyIwYBgmdAE2fUrg7pgvL5OJFpVIdQQUiKStbgqxlMBq7JiCbwHhf+MQb7N+EwCFgkNQ9NRePvRx3X24wPBcghOuzxZ/bymQRU7equqlLLGfiLF4iJ1h/N0RfNJt7kZlWfRCbG7f7rouqsN+14AwbLHsfQmVW1nseWjYlsNcxgqb0vvCrb2K3WIqPZ2wvoU80iWNe42uYaWSjGgCb53iWeFFl0aixesAn9F8dCwloh5idqUiNkVFLY4gcYYlt3V0w/BJlTqgPzaGxunOOkMLsSvgoFgEdmWBU0HwtusTLbIaK3GNaSpIVxEjtTRoFNUXEv9HKfYhaqgQ7DdVMZSMepLMBLLzsNaE3wjiObvqfavnzFyEwVColkRqGVKqYVrLuQ24eNa/pams82uhlixcXQTojGdWttGNda3B4zAwrJQGEXtoLyP3WV0HSOjnEt1V1DW4mBPZagJnneHPofaVpU5RjYRNQGvH7D/6TLvMe+lyB9HGg8IVknwamG9vDZOpY3cd5jkgyAbcVqPnKghXD6pDD3MI1ecauM2qmOeGKbi+jiHEiJMEZxX5ECw1pisJq3mmMprg++GRmNBsahakquOU8l6r3Zt06VuyxZwj+malWj85pYhpA22+7bnPLA4IFheGKRHK1BmKyu2206IiqEq8SunK8iqjLSviV+iu1GZGpuN2R6FZbpGMQbtacO6vYH2VWw3zoRAsFQMbqH5pnSbXk0LLZp7rwqwN8RJI1zt48qGJU3L3K/rUNssker/aK5gO3blZV0Zxm+JUcVzxtMDwVKw/rX0dAu1Vpa79WkQqiaKTbia1qHzecLAIdS2bMaX6BQgVsIGOpvTmhikNTQx/qUL+Muom3Sx3ZGadIbNT4VK1KRWRnRlPRDS1RetGBnFLLZrGWBdaYdus66wOlgDFlYDkx1UuHZtlzHcyoqHVgyrWhW0uYJSO6CLY3n06ukarreq+FlsV5AoLKpubAF4AsHSEui+6WJfmlhWfHembpCkBNZ9XMHtT6rdgk3UIruIBr3y2kcE6yoQuIQajHFRU3nNQTE1JO1A9SSsrarSE2vG0jcnpXcFt5lKqmfXsqaoPaCqz5hiWKVl2sT4fKBpPwgBFlYoxpVEzZsNWmUiREl11wfe19Seg+TW4eBumy24QoFRWhueItRhZTDO850eCJYJW4qDNdDVLFtvJ6bbsGVVkfinM9QObtu56ZArED89tV954NsXbOcS23nGAgTLgD2KpT+qs7LMAfgYEBLmuv4owlV8smS29zSr2m5hu+1qgSCiqawbN6yrYYFg2bBaWfpj5gB8hKIlokyOxvOEalDdsCLYz6M5yl4ftzDKySxhgXZjRKuqBgxAsCzYrCOrV6h1DZV9Md2RlUoZhEst03AFw1MaGu2YjI+AslFgECajLFmNq5hPdHogWA6sL3EICMAbHIZJqdys2qqch0XVFLA+xqHbY7C4oriKrmuAR20GAYLlQ5+uoSIIMdBe+1N2KlaXsWwP/bb2mgLtEV03IqrUU29dmepYhAzWlRMIlgddok+6OkJElFM8f2KrmJBBkDRWV3m0d9vKZzUwwhiW9vdsCbTHNfr5AcHyxhLLMllgIsSaR3lioO7RqLEpl3i1NvzV3HHyVidqffljuX5EBu3s6ArCuvIDguWJLZZlXQQMfZPpiKjxoHZKgz13bNs3Nrir1H0tVVejxWZBIY2hFyBYAegspuqYJtBe7LfEuWJgHXTXCle1Q39epuZ8yulpx7Bq9SO9hERkSWEgpysIufIHghWK1dSyBecpvgnXiglpHnZuiVftaLtJ/86NlYwBeaForRGzJDnEKtLziRUIViA23bHGs6pJH49q1dwsbm20J5q4HMWOY/A5ql9AnJjCqe7q7UGswoFgdcDuGtpSHaof0VAJcM20MicwNEff8W1YfiW8LK8p4doqaxO7IMV3NnMAgtUVi2tojL9XP2Jg4+Y151X9C6qbKQ3rSvVWth+H32ZciOUdHQ7rCcZVNyBYHXEF001WWDT3aRkPUp4lVA+RutfuG3bv33/35miEuVgtXPlWsY8/YiBYW+CMo0e+Oli3+NrpDLXDtHmKp6+XJpRtOTOXtvVDB0I7bmdyKJJHtwGCtS0u1zBm0SJXOkPtQ1XWNuFC0xrax/Ui5dP39LjFCMbVdkCwtsTpGjqOT04jD6varVpeZblaJT1h8zEwwB7pJSywrxYSYVWwDyBYPVC4NpbVIopUtMp4UDV0SzDdJ6XBlu/hGorraGViadR1ctxjglj1AwSrJ1x6VHhbMT353IhhlRsaV7BWXmGbN5B6pzdIfVc8V48qPxqW1XhAsHrElp9FRCSxPb1LthVBcyxLV7e3kWgajeySKXgoKMSqVyBYPeMWrXjRWlBNAWsV6KEj38ORedSlXhmHhdfJ9A4EawBcohUFZR5WfZ2wVURlGxfQNISgt0ZHloPlyrWKZ6S7AwRrIOYgWpVm0XrRwOL+leWHGIPzqBpzH2AMvQOxGgwI1oDMQbRK6ilYynRziFjPI6h9nOWkh1gNCgRrYJqixcyUpsmEIypIkqTQIE2quWg3NN+Rs42GmVOwzKzHmyTTX780Tdp/jCBWgwPBGoFStJiILh4e0Tf+69u0Mk06LxFwF3KV+OGFnxbJoZpnCU3Yc7P86TapC7+Qheg/vv09+p8Tl/XQT/cEseM8p4uHR8oXd0CsxgCCNRKFaBG9/MpF+rt/fZZMM6F40R9blaB6P4BDLZjKdtoFmYn207Qew6oV9ZOi4Sap3kVkZnrimW8aYu9S+bbmcW1eT+GUGFnnUGkvBdN+aWVBrEYDgjUi5b1/ySq1lis0xtOKcpSrP1HjkW5hFDBtiz2g90dtArCfNq6fol5O4fAVF89ySAodFwjWyPg8plMYCeIUpE05s0VWc/hEFSG78KgCVhc90wT1ETJ7VmjY1JewuuJhUVVlIVaxAsGaAB/RqpUjcgiXbITF8hC2urGxoAJjV8Y5av/i+t6mdog1pZTv06oqikKspgCCNRGVdeSwdioLyVPgfCwztd2qfImH9eVsszek1ah3HyFCtS7vV9b97CAYDgjWxEhp7fQtRpUQ2QP4VXlaZzio1hcpB8bIw7J7jAHNeNtJpm4NxRFcnxoIVgRsrC0/98z3VTWVjeFwF+vl6xO49WK/aqd2wwN34KmLSIXIVFEnpDysqliAYEWEb2Z8iLWlreNhddXqGXayuUR4m13oYvEE1kGsKi4gWJFRTpBg4Soq+dVRra6iYiePb/SpHBqXatQNrQexig8IVqSEPIcYEpjX1SOSTbZCbM8+biNS6/pDW2FgPCBYESPbuH2BwqOuGpZsa4GFD2BLcaq11010YFXFDQQrcraJVxGpC3zhilPLeNLM456efe6RwFU/tSaEahZAsGaCb96Wvp5f6kSnMU1NlxVCtTqEalZAsGaGrCdo6Hu2WlYXUXzxKm+6W1KbJhCnmiMQrJmyWU0kCnXOmvGq6AVs28B7oy0I1XyBYM2cyuIi6iw49oB793Y7jUQaY+qrZbh+OwEEa0fYZoXQ2F61oXvesPahWw/upPetgVDtFhCsHaO9QtiPdSTajRjFoIf4FogWCNYOM5R4xQgsqWUAwVoINfEa5e0LI4AA+uKAYC2QMlBPNIMVQhUI1OKBYC0c6wrhZCKGOBTQA8ECLXQiptL9DaW6lUEmSBPwBYIFgmmvGG4jOBAr4M/0X6ELAACeQLAAALMBggUAmA0QLADAbIBgAQBmAwQLADAbIFgAgNkAwQIAzAYIFgBgNvQuWCIyg6doAQBDwwNoQe+CxaYH0AAAiyIXyftucwiX8BU8HwbA0hGiRF7pu9X+XULKv4+3PwKwbESESOQHfbc7gEu4eimHYgGwaHIRYVq91He7vQtWmiYv0AC+KwBgRojkaZq80Hezg6zo3f3gucOEaW+ItgEA8ZMLHX3izpv3+253qDysF0O/Sh0AsBus5/6LQ7Q9iGAx0VOcICcVgCXCSUJM9NQQbQ/Fw/sIAAADPElEQVQjWExP5znCWAAskTzPiZmeHqLtQQTrSFaPiMh3duK77wAAATCJyHeOZPXIEK0PIlj333nj95j4qSSFWwjAkkjShJj4qfvvvPF7g7Q/RKNERCz555DwDsDCECJh+uxQzQ/qsx089NgzCSfXII8UgN2HmSmX/Nkzd9xy7VB9DOqzCSVnkhRffQjAEkjSFVFOnxiyj8Gj4vc89Ni/MydXw8oCYHdhZhKhr52+4+SvDtnP4FFx4eTPcpGjofsBAEyHCB2x5H8+dD+DC9aZ208+QZQ/kKzgGgKwiySrFQllD9x75y2PD97X0B0QEe1fXH0wOz56lhlpDgDsEswJZcfZs0fJjz80Sn9jdEJE9OEHHn3jKk2foYROIN0BgB2AiSinC0m6uvbjt934/Bhdjmby3HfXqec55feISDZWnwCA4RCRjFN+z1hiRTTyt+bce9vJc0z8ASI6HLNfAECPFH7ZIRN/4N7bTp4bv+uRuefBx35fmD7FxOkU/QMAtuKYiP7w9B03f3rsjid7OvlPPvfozSmnf5+kyQm82QGA+EmShPIsv5BJ9p5Pvu/UqJZVNYYpOiUi+uT7Tp07zrJrs1yeRTY8AHGTrFaU5fLscZZdO5VYEU38zc/33XXq+f2fvPK2PMs+TcRHeEspAHGxnpPH2dHRX+3/5JW33XfXqdEC7NrxTNm5ysHn/vEm4uTje/t7v5IdZ/geCwAmhDmhdJXS0eHR1ynJP3Lm9t98YuoxEUUkWCUHZx9/J1N+wJy8hZlJ8pzwHCIAw8PMxElCIkIi+XNCcubM7bd8cepxqUQnWCUHZ8/fxLncSSxvJUpel6QJxAuAnilFKs9yIsq/S8JflYQfLB6pi49oBavkns8/+jrK0lMidJ0wXU8iVxJRQsxJwsTF4z7RnwYAESAkklMu6w9EOTG/yEJPMdPTlGaPnv7tU9+depQ2ZjnTTz/85A1ZdnyVUH4FCV9OxJcmzIkww/wCoAGLcC6SE8krxPIDpuSlNF29cM+73/6VqccGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoD/+H+Obt43cHbcEAAAAAElFTkSuQmCC");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarHabrDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarHabrDiv",
  });

   candyjarHabrDiv.append(svg);
   candyjarHabrDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'habr_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarHabrDiv;
}

function createXingElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarXingSvg');
  svg.setAttribute('class', 'candyjarXingSvg');
  svg.setAttribute('fill', 'none');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "d", "M10 20.0413C15.5228 20.0413 20 15.5641 20 10.0413C20 4.51841 15.5228 0.0412598 10 0.0412598C4.47715 0.0412598 0 4.51841 0 10.0413C0 15.5641 4.47715 20.0413 10 20.0413Z");
  path1.setAttributeNS(null, "fill", "#006064");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "d", "M6.66946 12.3051H4.84098C4.73094 12.3051 4.64853 12.2552 4.60279 12.1814C4.55434 12.1031 4.55163 12.0017 4.60279 11.9029L6.54584 8.49593C6.54765 8.4914 6.54765 8.49005 6.54584 8.48552L5.30965 6.35908C5.25757 6.25855 5.25033 6.15893 5.29878 6.08059C5.34451 6.00497 5.43734 5.96558 5.54738 5.96558H7.37631C7.65661 5.96558 7.79427 6.1458 7.88483 6.30745C7.88483 6.30745 9.13507 8.47329 9.14231 8.48552C9.0685 8.61548 7.16847 11.9537 7.16847 11.9537C7.07519 12.1217 6.94297 12.3051 6.66946 12.3051Z");
  path2.setAttributeNS(null, "fill", "white");

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "d", "M15.3947 4.10035L11.3465 11.2585C11.3442 11.2635 11.3442 11.2671 11.3465 11.2703L13.9239 15.9814C13.9746 16.0829 13.9769 16.1852 13.928 16.2635C13.8809 16.3387 13.7962 16.3804 13.6853 16.3804H11.8591C11.5797 16.3804 11.4388 16.1947 11.3487 16.0312C11.3487 16.0312 8.75679 11.2775 8.75 11.2653C8.87951 11.0362 12.8181 4.05009 12.8181 4.05009C12.9159 3.87439 13.0355 3.70142 13.3076 3.70142H15.156C15.2656 3.70142 15.3526 3.74262 15.3988 3.8187C15.4468 3.89658 15.4449 3.99847 15.3947 4.10035Z");
  path3.setAttributeNS(null, "fill", "#CDDC39");

  svg.appendChild(path1);
  svg.appendChild(path2);
  svg.appendChild(path3);

  var candyjarXingDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarXingDiv",
  });

   candyjarXingDiv.append(svg);
   candyjarXingDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'xing_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarXingDiv;
}

function createLinkedinElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarLinkedinSvg');
  svg.setAttribute('class', 'candyjarLinkedinSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M10.7766 0.740234C5.33363 0.740234 0.906738 5.16713 0.906738 10.6101C0.906738 16.0515 5.33363 20.4779 10.7766 20.4779C16.218 20.4779 20.6444 16.0515 20.6444 10.6101C20.6444 5.16713 16.218 0.740234 10.7766 0.740234Z");
  path1.setAttributeNS(null, "fill", "#0081DA");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "clip-rule");
  path2.setAttributeNS(null, "d", "M16.3223 15.3723C16.3223 15.7992 15.9674 16.146 15.5275 16.146H6.36585C5.92598 16.146 5.57104 15.7992 5.57104 15.3723V6.10248C5.57104 5.67342 5.92598 5.32715 6.36585 5.32715H15.5275C15.9674 5.32715 16.3223 5.67342 16.3223 6.10248V15.3723Z");
  path2.setAttributeNS(null, "fill", "white");

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "fill-rule", "clip-rule");
  path3.setAttributeNS(null, "d", "M8.02936 7.14258C7.4737 7.14258 7.11011 7.50833 7.11011 7.98824C7.11011 8.45517 7.46287 8.83121 8.00826 8.83121H8.01908C8.58502 8.83121 8.93616 8.45517 8.93616 7.98824C8.92534 7.50833 8.58502 7.14258 8.02936 7.14258Z");
  path3.setAttributeNS(null, "fill", "#0081DA");

  path4 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path4.setAttributeNS(null, "fill-rule", "evenodd");
  path4.setAttributeNS(null, "fill-rule", "clip-rule");
  path4.setAttributeNS(null, "d", "M7.20532 14.3853H8.83065V9.49902H7.20532V14.3853Z");
  path4.setAttributeNS(null, "fill", "#0081DA");

  path5 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path5.setAttributeNS(null, "fill-rule", "evenodd");
  path5.setAttributeNS(null, "fill-rule", "clip-rule");
  path5.setAttributeNS(null, "d", "M12.8166 9.38379C11.9541 9.38379 11.5695 9.85721 11.3541 10.191V9.49957H9.73096C9.75206 9.95622 9.73096 14.3864 9.73096 14.3864H11.3541V11.6557C11.3541 11.5096 11.3622 11.364 11.4066 11.258C11.5251 10.9664 11.7913 10.6645 12.2414 10.6645C12.829 10.6645 13.0638 11.1125 13.0638 11.7698V14.3842H14.687V11.5815C14.687 10.0834 13.8857 9.38379 12.8166 9.38379Z");
  path5.setAttributeNS(null, "fill", "#0081DA");

  svg.appendChild(path1);
  svg.appendChild(path2);
  svg.appendChild(path3);
  svg.appendChild(path4);
  svg.appendChild(path5);

  var candyjarLinkedinDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarLinkedinDiv",
  });

   candyjarLinkedinDiv.append(svg);
   candyjarLinkedinDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'linkedin_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarLinkedinDiv;
}

function createEmailElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarEmailSvg');
  svg.setAttribute('class', 'candyjarEmailSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M10.0915 0.740234C4.64857 0.740234 0.22168 5.16713 0.22168 10.6101C0.22168 16.0515 4.64857 20.4779 10.0915 20.4779C15.5329 20.4779 19.9593 16.0515 19.9593 10.6101C19.9593 5.16713 15.5329 0.740234 10.0915 0.740234Z");
  path1.setAttributeNS(null, "fill", "#1EBCFF");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "clip-rule");
  path2.setAttributeNS(null, "d", "M10.3135 4.68848C11.9318 4.68848 13.2869 5.18614 14.3764 6.18148C15.4683 7.17682 16.0118 8.38233 16.0118 9.7932C16.0118 10.9069 15.6779 11.8588 15.0125 12.6463C14.3471 13.4363 13.5575 13.8301 12.6435 13.8301C12.022 13.8301 11.5516 13.5934 11.2323 13.1174C10.8082 13.6127 10.2989 13.8615 9.70174 13.8615C9.03393 13.8615 8.46361 13.5837 7.98835 13.0232C7.51309 12.4651 7.27668 11.7283 7.27668 10.8175C7.27668 9.885 7.54234 9.12159 8.07853 8.5297C8.61229 7.93782 9.25572 7.64066 10.0064 7.64066C10.4792 7.64066 10.9155 7.80253 11.3128 8.12384L11.4127 7.76387H12.9725L12.5192 11.4384C12.4924 11.6897 12.4778 11.9071 12.4778 12.0931C12.4778 12.3226 12.585 12.4362 12.7995 12.4362C13.1967 12.4362 13.5794 12.1897 13.9474 11.6921C14.3154 11.1968 14.5007 10.5735 14.5007 9.82702C14.5007 8.73505 14.0985 7.8291 13.2942 7.10917C12.4899 6.38925 11.5029 6.02928 10.3354 6.02928C9.06805 6.02928 7.9981 6.46897 7.13044 7.34351C6.26035 8.22047 5.82408 9.31244 5.82408 10.6218C5.82408 11.8274 6.2311 12.8783 7.0427 13.7721C7.85674 14.6684 9.00468 15.1154 10.4865 15.1154C11.4176 15.1154 12.373 14.9076 13.3479 14.4921C13.7256 14.3326 14.1595 14.5066 14.313 14.8834C14.4617 15.2482 14.2838 15.6638 13.9182 15.8184C12.797 16.2943 11.654 16.531 10.489 16.531C8.55623 16.531 7.02077 15.9488 5.8777 14.7844C4.7395 13.6199 4.16919 12.2308 4.16919 10.6146C4.16919 8.92832 4.76875 7.51987 5.96544 6.38683C7.16213 5.25379 8.61229 4.68848 10.3135 4.68848ZM9.79684 12.2934C10.1795 12.2934 10.5085 12.1074 10.7839 11.7402C11.0593 11.3705 11.1983 10.9502 11.2007 10.4743C11.2007 10.0926 11.0886 9.78816 10.8644 9.55865C10.6401 9.32914 10.3842 9.2156 10.0966 9.2156C9.76516 9.2156 9.48732 9.37021 9.26309 9.67461C9.03886 9.97901 8.92675 10.38 8.92675 10.8777C8.92675 11.2812 9.00718 11.617 9.16804 11.8875C9.32646 12.1581 9.53606 12.2934 9.79684 12.2934Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarEmailDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarEmailDiv",
  });

   candyjarEmailDiv.append(svg);
   candyjarEmailDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'email_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarEmailDiv;
}

function createTelElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarTellSvg');
  svg.setAttribute('class', 'candyjarTelSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M9.94205 20.4779C15.3924 20.4779 19.8109 16.0594 19.8109 10.609C19.8109 5.15865 15.3924 0.740234 9.94205 0.740234C4.49166 0.740234 0.0732422 5.15865 0.0732422 10.609C0.0732422 16.0594 4.49166 20.4779 9.94205 20.4779Z");
  path1.setAttributeNS(null, "fill", "#9AD800");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "clip-rule");
  path2.setAttributeNS(null, "d", "M13.8259 13.9739L13.2241 14.5758C13.1167 14.6831 12.8021 14.7501 12.792 14.7501C10.8882 14.7667 9.05517 14.0189 7.70835 12.6719C6.35785 11.3207 5.6092 9.48108 5.6293 7.5709C5.6293 7.57003 5.6982 7.26445 5.80554 7.15812L6.4073 6.55628C6.6275 6.33505 7.0505 6.23508 7.34682 6.33422L7.4734 6.37644C7.76886 6.47548 8.07906 6.80217 8.16069 7.10313L8.46339 8.21413C8.54502 8.51597 8.43492 8.94538 8.21478 9.16558L7.81297 9.56745C8.20747 11.0279 9.35338 12.174 10.8141 12.5695L11.2157 12.1675C11.437 11.9463 11.8662 11.8363 12.1674 11.9178L13.2782 12.2216C13.5793 12.3043 13.9059 12.6125 14.0049 12.9079L14.0471 13.0363C14.1453 13.3318 14.0461 13.7547 13.8259 13.9739Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarTelDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarTelDiv",
  });

   candyjarTelDiv.append(svg);
   candyjarTelDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'phone_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarTelDiv;
}

function createTelegramElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarTelegramlSvg');
  svg.setAttribute('class', 'candyjarTelegramSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M10.2013 19.8734C15.6517 19.8734 20.0701 15.4549 20.0701 10.0046C20.0701 4.55416 15.6517 0.135742 10.2013 0.135742C4.75094 0.135742 0.33252 4.55416 0.33252 10.0046C0.33252 15.4549 4.75094 19.8734 10.2013 19.8734Z");
  path1.setAttributeNS(null, "fill", "#00A5FF");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "clip-rule");
  path2.setAttributeNS(null, "d", "M5.16714 9.59132L13.74 6.25055C14.0663 6.1234 14.4035 6.40899 14.3319 6.75176L12.8682 13.7495C12.7995 14.0779 12.4144 14.2254 12.1439 14.0269L9.93398 12.4047L8.80766 13.5547C8.60998 13.7566 8.2685 13.6749 8.18358 13.4054L7.37058 10.8257L5.19212 10.1824C4.90628 10.098 4.88946 9.69953 5.16714 9.59132ZM8.68295 11.3251L12.665 7.8038C12.7603 7.71952 12.6496 7.57066 12.5415 7.63778L7.83909 10.5542C7.7563 10.6056 7.71863 10.7064 7.74752 10.7995L8.3783 12.832C8.39157 12.8747 8.45377 12.8688 8.45878 12.8244L8.61209 11.4615C8.618 11.4088 8.64326 11.3602 8.68295 11.3251Z");
  path2.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);

  var candyjarTelegramDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarTelegramDiv",
  });

   candyjarTelegramDiv.append(svg);
   candyjarTelegramDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'telegram_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarTelegramDiv;
}

function createSkypeElement(link) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '21');
  svg.setAttribute('height', '21');
  svg.setAttribute('id', 'candyjarSkypeSvg');
  svg.setAttribute('class', 'candyjarSkypeSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M10.1459 20.4779C15.5963 20.4779 20.0147 16.0594 20.0147 10.609C20.0147 5.15865 15.5963 0.740234 10.1459 0.740234C4.69552 0.740234 0.2771 5.15865 0.2771 10.609C0.2771 16.0594 4.69552 20.4779 10.1459 20.4779Z");
  path1.setAttributeNS(null, "fill", "#1EBCFF");

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "fill-rule", "clip-rule");
  path2.setAttributeNS(null, "d", "M15.0222 10.666C15.0219 10.9603 15.1018 11.2516 15.2744 11.4901C15.5726 11.9022 15.7386 12.416 15.71 12.97C15.6499 14.1303 14.7167 15.0802 13.5577 15.16C13.2817 15.1789 13.0153 15.1493 12.766 15.079C12.4837 14.9996 12.1821 15.0189 11.9068 15.1198C11.3979 15.3065 10.8482 15.4085 10.2745 15.4085C7.65239 15.4085 5.52694 13.2829 5.52694 10.6609V10.6557C5.5272 10.3612 5.44714 10.0699 5.2747 9.83135C4.97648 9.41933 4.8105 8.90562 4.83912 8.35179C4.89925 7.19145 5.83236 6.24156 6.99144 6.16176C7.26739 6.14268 7.53384 6.17237 7.78311 6.24256C8.06537 6.32202 8.36704 6.30269 8.64229 6.20173C9.15122 6.01519 9.70086 5.91309 10.2746 5.91309C12.8966 5.91309 15.0222 8.03868 15.0222 10.6608V10.666ZM10.4484 9.80847L10.4484 9.80846C9.42336 9.56468 9.25939 9.4549 9.25924 9.12851C9.25924 8.82045 9.8303 8.61179 10.4086 8.66675C11.1731 8.73931 11.6834 9.3071 11.7002 9.32867C11.9347 9.64263 12.3789 9.7091 12.6952 9.47654C13.013 9.24293 13.0812 8.79603 12.8477 8.47821C12.8104 8.42758 11.9189 7.23859 10.4086 7.23859C8.01691 7.23859 7.83104 8.72966 7.83104 9.1867C7.83104 10.6542 9.20713 10.9815 10.1178 11.1979C11.192 11.4535 11.4588 11.6737 11.4239 11.9737C11.3953 12.2193 11.1743 12.507 10.2072 12.4764C9.40403 12.451 8.83694 11.7997 8.83483 11.7971C8.58901 11.4887 8.13966 11.4381 7.83126 11.684C7.52287 11.9299 7.47225 12.3792 7.71814 12.6875C7.75792 12.7372 8.70596 13.9045 10.2073 13.9045C10.6959 13.9045 11.2628 13.8754 11.7637 13.6597C12.4656 13.3574 12.8522 12.7585 12.8522 11.9737C12.8522 10.3803 11.4057 10.0362 10.4484 9.80847Z");
  path2.setAttributeNS(null, "fill", "white");

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "fill-rule", "clip-rule");
  path3.setAttributeNS(null, "d", "M11.424 11.9731C11.4559 11.6993 11.2361 11.492 10.3811 11.2637V12.4779C11.2014 12.4704 11.3971 12.2033 11.424 11.9731Z");
  path3.setAttributeNS(null, "fill", "white");

  svg.appendChild(path1);
  svg.appendChild(path2);
  svg.appendChild(path3);

  var candyjarSkypeDiv = $('<span/>',{
    class: "candyjarSocialIconDiv",
    id: "candyjarSkypeDiv",
  });

   candyjarSkypeDiv.append(svg);
   candyjarSkypeDiv.click(function() {
     if (checkSignInAndOpenWindow()) {
       var win = window.open(link, '_blank');
       if (win) {win.focus();}
     }
     var requestString = getAddUserLogRequestString( 'socials_click', 'skype_click')
     chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
   });
   return candyjarSkypeDiv;
}
