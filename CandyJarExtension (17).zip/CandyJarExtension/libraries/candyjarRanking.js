/////////////
// RANKING //

function addCandyjarCardRankDiv(parentElement, candyjarLogin, tagsCount, githubMetrics) {
  if (!parentElement) {
    return
  }

  if (!isSignInAndHaveDays()) {
    return
  }

  var developerRank = calculateDeveloperRank(githubMetrics);
  var linkedinActivity = getLinkedinActivity(githubMetrics);
  var githubActivity = getGithubActivity(githubMetrics);

  if (developerRank == 0 || githubActivity == 0) {
    return
  }

  if (githubActivity == 1) {
    githubActivity = 0;
  }


  var candyjarRankDiv = createCandyjarCardRankDiv("candyjarCardRankDiv" + candyjarLogin);
  parentElement.append(candyjarRankDiv);

  var candyjarStarsRankDiv = createCandyjarStarsRankDiv("candyjarStarsRankDiv" + candyjarLogin);
  candyjarRankDiv.append(candyjarStarsRankDiv);

  var candyjarStarsRankDivFirstLine = createCandyjarStarsRankDivFirstLine("candyjarStarsRankDivFirstLine" + candyjarLogin);
  candyjarStarsRankDiv.append(candyjarStarsRankDivFirstLine);

  var value = parseFloat(developerRank)
  if (value > 100) {
    value = 100
  }

  var candyjarStarsRankDivSecondLine = createCandyjarStarsRankDivSecondLine("candyjarStarsRankDivSecondLine" + candyjarLogin);
  candyjarStarsRankDiv.append(candyjarStarsRankDivSecondLine);
  $("#candyjarStarsRankDivSecondLine" + candyjarLogin).css("width", value + "%");

    var rankDetalizationString = getRankDetalizationString(tagsCount, linkedinActivity, githubActivity);
    if (rankDetalizationString.length) {
      var candyjarRankTipDiv = createCandyjarCardRankTipDiv("candyjarRankTipDiv" + candyjarLogin);
      candyjarRankDiv.append(candyjarRankTipDiv);

      var candyjarRankDitalizationDiv = createCandyjarCardRankDitalizationDiv("candyjarRankDitalizationDiv" + candyjarLogin);
      candyjarRankDiv.append(candyjarRankDitalizationDiv);
      $("#candyjarRankDitalizationDiv" + candyjarLogin).append(rankDetalizationString);

      $('.tooltipcandyjarRankTipDiv' + candyjarLogin).tooltipster({
        content: $("#candyjarRankDitalizationDiv" + candyjarLogin),
        animation: "swing",
        arrow: true
      });
      $("#candyjarRankDitalizationDiv" + candyjarLogin).remove();
    }

}

function calculateDeveloperRank(githubMetrics) {
  var result = 0;
  if (githubMetrics && githubMetrics.total_activity) {
    result = githubMetrics.total_activity;
    if (result > 100) {
      result = 100;
    }
  }
  return result;
}

function getLinkedinActivity(githubMetrics) {
  var result = 0;
  if (githubMetrics && githubMetrics.total_linkedin_activity) {
    result = githubMetrics.total_linkedin_activity;
    if (result > 100) {
      result = 100;
    }
  }
  return result;
}

function getGithubActivity(githubMetrics) {
  var result = 0;
  if (githubMetrics && githubMetrics.total_github_activity) {
    result = githubMetrics.total_github_activity;
    if (result > 100) {
      result = 100;
    }
  }
  return result;
}

function createCandyjarCardRankDitalizationDiv(divId) {
  var candyjarCardRankDitalizationDiv = $('<div/>', {
    class: "candyjarCardRankDitalizationDiv",
    id: divId,
  });
  return candyjarCardRankDitalizationDiv;
}

function createCandyjarCardRankDiv(divId) {
  var candyjarCardRankDiv = $('<div/>', {
    class: "candyjarCardRankDiv",
    id: divId,
  });
  return candyjarCardRankDiv;
}

function createCandyjarStarsRankDiv(divId) {
  var candyjarCardRankValueDiv = $('<div/>', {
    class: "candyjarStarsRankDiv",
    id: divId,
  });
  return candyjarCardRankValueDiv;
}

function createCandyjarStarsRankDivFirstLine(divId) {
  var candyjarStarsRankDivFirstLine = $('<div/>', {
    class: "candyjarStarsRankDivFirstLine",
    id: divId,
    text:'\u2B21\u2B21\u2B21\u2B21\u2B21',
  });
  return candyjarStarsRankDivFirstLine;
}

function createCandyjarStarsRankDivSecondLine(divId) {
  var candyjarStarsRankDivSecondLine = $('<div/>', {
    class: "candyjarStarsRankDivSecondLine",
    id: divId,
    text:'\u2B22\u2B22\u2B22\u2B22\u2B22',
  });
  return candyjarStarsRankDivSecondLine;
}

function createCandyjarCardRankTipDiv(divId) {
  var candyjarCardRankTipDiv = $('<div/>', {
    class: "candyjarCardRankTipDiv" + " tooltip" + divId,
    id: divId,
    text: "?",
  });
  return candyjarCardRankTipDiv;
}

function getRankDetalizationString(tagsCount, linkedinActivity, githubActivity) {
  var result = "";
  if (!tagsCount || tagsCount.length == 0) {
    return result;
  }

  result += "github: <strong>" + githubActivity + "%</strong><br>";
  result += "linkedin: <strong>" + linkedinActivity + "%</strong><br>";


  var technologies = [];
  var topics = [];
  var index = 0;
  for (index = 0; index < tagsCount.length; index++ ) {
    if (index > 7) {
      continue;
    }
    var tag = tagsCount[index];
    if (tag.github_activity == 0) {
      continue;
    }
    if (tag.type == "technology" || tag.type == "language") {
      technologies.push(tag);
    } else {
      topics.push(tag);
    }
  }

  for (index = 0; index < technologies.length; index++ ) {
    var technology = technologies[index];
    if (index == 0) {
      result += "<br><strong>technologies:</strong><br>";
    }
    result += technology.name + "   <strong>" + technology.github_activity + "%</strong><br>";
  }
  for (index = 0; index < topics.length; index++ ) {
    var topic = topics[index];
    if (index == 0) {
      result += "<br><strong>topics:</strong><br>";
    }
    result += topic.name + "    <strong>" + topic.github_activity + "%</strong><br>";
  }

  return result;
}

// RANKING //
/////////////
