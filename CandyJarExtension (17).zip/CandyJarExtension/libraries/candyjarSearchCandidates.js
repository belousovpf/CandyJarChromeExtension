function candyGetSimilarCandidatesByLoginTag(loginTag, resultOkFunction, resultFailFunction) {
    $.get( "https://candyjar.io/api/full/searchbytag?tag=" + loginTag, function(candidate) {
      candidate = checkCandidateCountryRegionSpecialization(candidate);
      candyGetSimilarCandidatesByCandidate(candidate, resultOkFunction, resultFailFunction);
    }).fail(function() {
      resultFailFunction(loginTag, "");
    });
}

function candyGetSimilarCandidatesByCandidate(currentCandidate, resultOkFunction, resultFailFunction, loginTag = "") {
  var request = getSearchRequest(currentCandidate);
  $.get(request, function(similarCandidates) {
      var relevantCandidates = getRelevantSimilarCandidatesAndRating(currentCandidate, similarCandidates);
      var size = relevantCandidates.length;
      relevantCandidates = sortRelevantCandidates(relevantCandidates);
      relevantCandidates = getFirstNcandidates(relevantCandidates, 1000);
      resultOkFunction(relevantCandidates, size, currentCandidate, loginTag);
  }).fail(function() {
    resultFailFunction(loginTag, currentCandidate);
  });
}

function getFirstNcandidates(candidates, n) {
  if (candidates.length < n) {
    return candidates;
  }
  var nCandidates = [];
  for (index = 0; index < n; index++) {
    nCandidates.push(candidates[index]);
  }
  return nCandidates;

}

function checkCandidateCountryRegionSpecialization(candidate) {
  var region = candidate.about.region;
  if (region.length == 0 && candidate.about.country.toLowerCase() == "russia") {
    region = "moscow";
  }
  candidate.about.region = region;

  var specialization = "";
  var language = "";
  if (candidate.about.specialization && candidate.about.specialization.length > 0) {
    specialization = candidate.about.specialization.toLowerCase();
    if (specialization == "software-development"
      || specialization == "backend-developer") {
      specialization = "software-development";
      language = candidate.about.language.toLowerCase();
    }
  }
  if (specialization.length == 0) {
    specialization = "software-development";
  }
  candidate.about.specialization = specialization;
  candidate.about.language = language;
  return candidate;
}

function getSearchRequest(currentCandidate) {
  var request = "https://candyjar.io/api/searchbytags?"

  if (currentCandidate.about.country.length == 0) {
    return "";
  }
  request += "tags[]=" + currentCandidate.about.country.toLowerCase();
  if (currentCandidate.about.region.length > 0) {
    request += "&tags[]=" + currentCandidate.about.region.toLowerCase();
  }
  if (currentCandidate.about.specialization.length > 0) {
    request += "&tags[]=" + currentCandidate.about.specialization.toLowerCase();
  }
  if (currentCandidate.about.language.length > 0) {
    request += "&tags[]=" + currentCandidate.about.language.toLowerCase();
  }

  return request;
}

function getRelevantSimilarCandidatesAndRating(currentCandidate, similarCandidates) {
  var relevantCandidates  = [];
  for (indexGetRel = 0; indexGetRel < similarCandidates.length; indexGetRel++) {
    var similarCandidate = similarCandidates[indexGetRel];
    if (!isRelevantCandidate(currentCandidate, similarCandidate)) {
      continue;
    }
    addSimilarCandidateRating(currentCandidate, similarCandidate);
    relevantCandidates.push(similarCandidate);
  }
  return relevantCandidates;
}

function addSimilarCandidateRating(currentCandidate, similarCandidate) {
  similarCandidate.rating = 0;

  if (currentCandidate.about.level.length > 0) {
    currentCandidateLevel = currentCandidate.about.level.toLowerCase();
    if (currentCandidateLevel == similarCandidate.about.level.toLowerCase()) {
      similarCandidate.rating += 3;
    }
  }

  var currentSpecialization = currentCandidate.about.specialization.toLowerCase();
  if (currentSpecialization.length > 0 && currentSpecialization == similarCandidate.about.specialization.toLowerCase()) {
    similarCandidate.rating += 10;
  }
  var currentLanguage = currentCandidate.about.language.toLowerCase();
  if (currentLanguage.length > 0 && currentLanguage == similarCandidate.about.language.toLowerCase()) {
    similarCandidate.rating += 10;
  }

  currentTopTags = currentCandidate.top_tags;
  for (indexRating = 0; indexRating < currentTopTags.length; indexRating++) {
    currentTopTag = currentTopTags[indexRating];
    if (similarCandidate.top_tags.includes(currentTopTag)) {
      similarCandidate.rating += 1;
    }
  }
}

function isRelevantCandidate(currentCandidate, similarCandidate) {

  if (currentCandidate.login == similarCandidate.login) {
    return false;
  }

  var currentCountry = currentCandidate.about.country.toLowerCase();
  if (currentCountry.length > 0 && currentCountry != similarCandidate.about.country.toLowerCase()) {
    return false;
  }
  var currentRegion = currentCandidate.about.region.toLowerCase();
  if (currentRegion.length > 0 && currentRegion != similarCandidate.about.region.toLowerCase()) {
    return false;
  }
  return true;
}

function candyAddPaginator(candidatesDivId, paginatorDivId, candidates, pageSize) {
  $(paginatorDivId).pagination({
    dataSource: candidates,
    pageSize: pageSize,
    pageRange: 2,
    className: 'paginationjs-small',
    showPrevious: false,
    showNext: false,
    callback: function(data, pagination) {
        var html = candyPaginatorTemplate(data);
        $(candidatesDivId).html(html);
    }
  })
}

function candyPaginatorTemplate(data) {
    var html = "";
    $.each(data, function(index, item){
        html += item;
    });
    return html;
}

function sortRelevantCandidates(relevantCandidates) {
  function compare(a, b) {
    if (a.rating > b.rating) return -1;
    if (b.rating > a.rating) return 1;
    return 0;
  }
  relevantCandidates.sort(compare);
  return relevantCandidates;
}
