function getMessages(emailsSet, interactive = true, callbackFunction) {
  if (!isSignInAndHaveDays()) {
    return;
  }
  if (emailsSet.size == 0) {
    emailsSet = new Set();
    emailsSet.add("noreply@candyjar.io");
  }
  for ( mail of emailsSet) {
    xhrWithAuth('GET', 'https://www.googleapis.com/gmail/v1/users/me/messages?q="to:' + mail + '"', interactive, callbackFunction);
    xhrWithAuth('GET', 'https://www.googleapis.com/gmail/v1/users/me/messages?q="from:' + mail + '"', interactive, callbackFunction);
  }
}

function getAllMessages(interactive = true, callbackFunction) {
  if (!isSignInAndHaveDays()) {
    return;
  }
  xhrWithAuth('GET', 'https://www.googleapis.com/gmail/v1/users/me/messages', interactive, callbackFunction);
}

function getListOfEmails(str) {
  var arr = str.split(" ");
  var result = [];
  for (var i = 0; i < arr.length;  i++) {
    var mail = arr[i];
    if (!mail.includes("@")) {
      continue;
    }
    mail = mail.replace(/\"/g,"");
    mail = mail.replace(/'/g,"");
    mail = mail.replace(/</g,"");
    mail = mail.replace(/>/g,"");
    mail = mail.toLowerCase();

    if (!result.includes(mail)) {
      result.push(mail);
    }
  }
  return result;
}


function getSingleMessageJsonFromResponse(response) {
    var message = new Object();

    var responseJson = JSON.parse(response);
    var labelIds = responseJson.labelIds;
    var snippet = responseJson.snippet
    var threadId = responseJson.threadId;
    var emailHref = "https://mail.google.com/mail/u/0/#inbox/"+threadId;

    var from = "";
    var to = "";
    var subject = "";
    var date = "";

    var headers = responseJson.payload.headers;
    for (var i = 0; i < headers.length; i++) {
      var header = headers[i];
      if (header.name == "From") {
        from = header.value;
      }
      if (header.name == "To") {
        to = header.value;
      }
      if (header.name == "Subject") {
        subject = header.value;
      }
      if (header.name == "Date") {
        date = header.value;
      }
    }



    // CORRECT DATE FORMAT //
    var msec = Date.parse(date);
    date = new Date(msec);
    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    date = date.toLocaleDateString("en-US", options)
    // CORRECT DATE FORMAT //

    // CALCULATE MESSAGE TYPE: INBOX / SENT / UNREAD //
    var inOut = "";
    var isUnread = false;
    if (labelIds) {
      for(var i = 0; i < labelIds.length;  i++) {
        if (labelIds[i] == "SENT") {
          inOut = "out";
        }
        if (labelIds[i] == "UNREAD") {
          isUnread = true;
        }
      }
      if (inOut == "" && isUnread) {
        inOut = "in (new)"
      } else if (inOut == "") {
        inOut = "in"
      }
    }
    // CALCULATE MESSAGE TYPE: INBOX / SENT / UNREAD //


    message.emailHref = emailHref;
    message.to = to;
    message.toList = getListOfEmails(to);
    message.from = from;
    message.fromList = getListOfEmails(from);
    message.subject = subject;
    message.date = date;
    message.msec = msec;
    message.inOut = inOut;
    return message;
}



function getSingleMessage(messageId, callbackFunction) {
  var interactive = false;
  xhrWithAuth('GET', 'https://www.googleapis.com/gmail/v1/users/me/messages/' + messageId, interactive, callbackFunction);
}


function xhrWithAuth(method, url, interactive, callback) {
  // interactive = true;
       var access_token;
       var retry = true;
       getToken();
       function getToken() {
           chrome.identity.getAuthToken({
               interactive: interactive
           }, function(token) {
               if (chrome.runtime.lastError) {
                   return;
               }
               access_token = token;
               $('#candyProfileUserActivitiesGmailSignInButton').remove();
               requestStart();
           });
       }
       function requestStart() {
           var xhr = new XMLHttpRequest();
           xhr.open(method, url);
           xhr.setRequestHeader('Authorization', 'Bearer ' + access_token);
           xhr.onload = requestComplete;
           xhr.send();
       }
       function requestComplete() {
           if (this.status == 401 && retry) {
               retry = false;
               chrome.identity.removeCachedAuthToken({
                       token: access_token
                   },
                   getToken);
           } else {
               callback(null, this.status, this.response);
           }
       }
   }

   function getUserInfo(interactive, callbackFunction) {
      xhrWithAuth('GET', 'https://www.googleapis.com/oauth2/v1/userinfo', interactive, callbackFunction);
   }

   function onUserInfoFetched(response) {
     var responseJson = JSON.parse(response);
     if (responseJson.name) {
       gmailUserInfo.name = responseJson.name;
     }
     if (responseJson.given_name) {
       gmailUserInfo.given_name = responseJson.given_name;
     }
     if (responseJson.family_name) {
       gmailUserInfo.family_name = responseJson.family_name;
     }
     if (responseJson.picture) {
       gmailUserInfo.picture = responseJson.picture;
     }
   }

   function getGmailInfo(interactive, callbackFunction) {
       xhrWithAuth('GET', 'https://www.googleapis.com/gmail/v1/users/me/profile', interactive, callbackFunction);
   }

   function onGmailInfoFetched(response) {
     var responseJson = JSON.parse(response);
     if (responseJson.emailAddress) {
       gmailUserInfo.emailAddress = responseJson.emailAddress;
     }
     if (responseJson.messagesTotal) {
       gmailUserInfo.messagesTotal = responseJson.messagesTotal;
     }
   }


   var gmailUserInfo = new Object();












   function revokeToken() {
     chrome.identity.getAuthToken({ 'interactive': false },
      function(current_token) {
        if (!chrome.runtime.lastError) {
          chrome.identity.removeCachedAuthToken({ token: current_token }, function() {});
          // Make a request to revoke token in the server
          var xhr = new XMLHttpRequest();
          xhr.open('GET', 'https://accounts.google.com/o/oauth2/revoke?token=' + current_token);
          xhr.send();
        }
      }
    );
}
