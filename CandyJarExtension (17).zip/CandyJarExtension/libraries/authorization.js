var authorizationInfo = 0;

function getAuthorization(resultOKfunction, resultFailFunction, website_name = '') {
  $.ajax({
       type: 'GET',
       url: 'https://candyjar.io/api/user?website_name=' + website_name,
       success: function(result) {resultOKfunction(result);},
       error: function() {resultFailFunction();}
  });
}

function authorizationOKfunction(result) {
  authorizationInfo = result;
  result.type = "authorization";
  sendPostDataToServer(result);
  if (authorizationInfo.searchRequests) {
    updateSavedRequests(authorizationInfo.searchRequests);
  }
}

function authorizationFailFunction() {
  console.log("authFAIL");
}

function checkSignInAndOpenWindow() {
  if (authorizationInfo.status == "success") {
    return true;
  } else {
    var win = window.open("https://candyjar.io/en/auth", '_blank');
    if (win) {win.focus();}
    return false;
  }
}

function getCurrentUserEmail() {
  if (authorizationInfo.status == "success") {
    return authorizationInfo.email;
  } else {
    return "";
  }
}

function getCurrentUserLogin() {
  if (authorizationInfo.status == "success") {
    return authorizationInfo.name;
  } else {
    return "";
  }
}

function isSignIn() {
  if (authorizationInfo.status == "success") {
    return true;
  } else {
    return false;
  }
}

function isSignInAndHaveDays() {
  if (authorizationInfo.status == "success" && authorizationInfo.days > 0) {
        return true;
  } else {
    return false;
  }
}

function getFriendworkToken() {
  if (authorizationInfo.status == "success" && authorizationInfo.friendworkToken && authorizationInfo.friendworkToken.length) {
    return authorizationInfo.friendworkToken;
  } else {
    return "";
  }
}
