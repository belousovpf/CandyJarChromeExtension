function sendTagTypeWebsiteData(tag, type, website) {
  var result = new Object();
  result.tag = tag;
  result.type = type;
  result.website = website;
  sendPostDataToServer(result);
}

function sendPostDataToServer(data) {
  $.ajax({
      url: 'https://candyjar.io/api/resend',
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json; charset=utf-8',
      dataType: 'json'

  });
}

function addStarToCandidate(developerId, isStarred, callbackFunction, website_name = '') {
  var data = 'loginId=' + encodeURIComponent(developerId) + '&isStared=' + encodeURIComponent(isStarred) + '&website_name=' + encodeURIComponent(website_name);
  var xhr = new XMLHttpRequest();
  xhr.open("POST", 'https://candyjar.io/candidate/addstar');
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.send(data);
  xhr.onreadystatechange = function() {callbackFunction();};
}

function getAddUserLogRequestString(request_name = "", object_name = '') {
  return "https://candyjar.io/api/addUserLog?" + "request_name=" + request_name + '&object_name=' + object_name;
}

function getSearchByTagRequestString(loginTag, needToUpdateLastView = false, website_name = "", request_name = "searchbytag") {
  return "https://candyjar.io/api/searchbytag?tag=" + loginTag+ "&" + "update_last_view=" + needToUpdateLastView + "&website_name=" + website_name + "&request_name=" + request_name;
}

function getSearchByTagFullRequestString(loginTag, needToUpdateLastView = false, website_name = "", request_name = "") {
   return "https://candyjar.io/api/full/searchbytag?tag=" + loginTag + "&" + "update_last_view=" + needToUpdateLastView + "&website_name=" + website_name + "&request_name=" + request_name;
}

function getGenerateLetterRequestString(loginTag) {
  return "https://candyjar.io/api/generateDeveloperLetter?developerLogin=" + loginTag;
}

function getUpdateUserInfoRequestString(userName, userCompany, gender, workType, letterLanguage) {
  return "https://candyjar.io/api/updateUserInfo?name=" + userName + "&company=" + userCompany + "&gender=" + gender + "&workType=" + workType + "&letterLanguage=" + letterLanguage;
}

function getUpdateUserInfoSearchRequestsString(searchRequests) {
  return "https://candyjar.io/api/updateUserInfo?searchRequests=" + searchRequests;
}



function getGenerateDeveloperLetter(developerLogin, resultOKfunction, resultFailFunction) {
  $.ajax({
       type: 'GET',
       url: 'https://candyjar.io/api/generateDeveloperLetter?developerLogin=' + developerLogin,
       success: function(response) {resultOKfunction(response);},
       error: function() {resultFailFunction();}
  });
}


function candyMakeSelectionRequest(datasetId,
                                  limit,
                                  page,
                                  filter,
                                  resultOkFunction,
                                  resultFailFunction,
                                  filterObject,
                                  booleanSearch = []) {

  var encodedFilter = "";
  if (filter.length) {
    filter = JSON.stringify(filter);
    encodedFilter = window.btoa(filter);
  }

  booleanSearch = JSON.stringify(booleanSearch);
  encodedBooleanSearch = window.btoa(booleanSearch);

  var query = [];
  query.push(limit);
  query.push(page);
  query.push(encodedFilter);
  query.push(encodedBooleanSearch);
  $.ajax({
      url: 'https://candyjar.io/api/selection/' + datasetId,
      type: 'POST',
      data: JSON.stringify(query),
      contentType: 'application/json; charset=utf-8',
      dataType: 'json',
      success: function(response) {resultOkFunction(response, filterObject)},
      error: function() {resultFailFunction(datasetId,
                              limit,
                              page,
                              filter,
                              resultOkFunction,
                              resultFailFunction,
                              filterObject)}
  });
}

function getCountrySpecializationIds(resultOKfunction, resultFailFunction) {
  $.ajax({
       type: 'GET',
       url: 'https://beta.candyjar.io/api/selections',
       success: function(selections) {resultOKfunction(selections);},
       error: function() {resultFailFunction();}
  });
}

// not used
var selectionRequestIds = [
  {country : 'Germany', specialization: 'android', requestId: 2202},
  {country : 'Germany', specialization: 'c++', requestId: 2203},
  {country : 'Germany', specialization: 'c#', requestId: 2204},
  {country : 'Germany', specialization: 'go', requestId: 2205},
  {country : 'Germany', specialization: 'ios', requestId: 2206},
  {country : 'Germany', specialization: 'java', requestId: 0},
  {country : 'Germany', specialization: 'javascript', requestId: 0},
  {country : 'Germany', specialization: 'php', requestId: 0},
  {country : 'Germany', specialization: 'python', requestId: 0},
  {country : 'Germany', specialization: 'ruby', requestId: 0},
  {country : 'Germany', specialization: 'scala', requestId: 0},
  {country : 'Germany', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'Germany', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'Germany', specialization: 'devops-engineer', requestId: 0},
  {country : 'Germany', specialization: 'embedded-engineer', requestId: 0},
  {country : 'Germany', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'Germany', specialization: 'it-analyst', requestId: 0},
  {country : 'Germany', specialization: 'network/system administration', requestId: 0},
  {country : 'Germany', specialization: 'product-management', requestId: 0},
  {country : 'Germany', specialization: 'qa-automation', requestId: 0},
  {country : 'Germany', specialization: 'robotics-engineer', requestId: 0},
  {country : 'Germany', specialization: 'sap-engineer', requestId: 0},
  {country : 'Germany', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'Germany', specialization: 'software/system architect', requestId: 0},
  {country : 'Germany', specialization: 'technical-support', requestId: 0},
  {country : 'Germany', specialization: 'ui/ux design', requestId: 0},
  {country : 'Germany', specialization: 'unity-developer', requestId: 0},

  {country : 'Ireland', specialization: 'android', requestId: 0},
  {country : 'Ireland', specialization: 'c++', requestId: 0},
  {country : 'Ireland', specialization: 'c#', requestId: 0},
  {country : 'Ireland', specialization: 'go', requestId: 0},
  {country : 'Ireland', specialization: 'ios', requestId: 0},
  {country : 'Ireland', specialization: 'java', requestId: 0},
  {country : 'Ireland', specialization: 'javascript', requestId: 0},
  {country : 'Ireland', specialization: 'php', requestId: 0},
  {country : 'Ireland', specialization: 'python', requestId: 0},
  {country : 'Ireland', specialization: 'ruby', requestId: 0},
  {country : 'Ireland', specialization: 'scala', requestId: 0},
  {country : 'Ireland', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'Ireland', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'Ireland', specialization: 'devops-engineer', requestId: 0},
  {country : 'Ireland', specialization: 'embedded-engineer', requestId: 0},
  {country : 'Ireland', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'Ireland', specialization: 'it-analyst', requestId: 0},
  {country : 'Ireland', specialization: 'network/system administration', requestId: 0},
  {country : 'Ireland', specialization: 'product-management', requestId: 0},
  {country : 'Ireland', specialization: 'qa-automation', requestId: 0},
  {country : 'Ireland', specialization: 'robotics-engineer', requestId: 0},
  {country : 'Ireland', specialization: 'sap-engineer', requestId: 0},
  {country : 'Ireland', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'Ireland', specialization: 'software/system architect', requestId: 0},
  {country : 'Ireland', specialization: 'technical-support', requestId: 0},
  {country : 'Ireland', specialization: 'ui/ux design', requestId: 0},
  {country : 'Ireland', specialization: 'unity-developer', requestId: 0},

  {country : 'Poland', specialization: 'android', requestId: 0},
  {country : 'Poland', specialization: 'c++', requestId: 0},
  {country : 'Poland', specialization: 'c#', requestId: 0},
  {country : 'Poland', specialization: 'go', requestId: 0},
  {country : 'Poland', specialization: 'ios', requestId: 0},
  {country : 'Poland', specialization: 'java', requestId: 0},
  {country : 'Poland', specialization: 'javascript', requestId: 0},
  {country : 'Poland', specialization: 'php', requestId: 0},
  {country : 'Poland', specialization: 'python', requestId: 0},
  {country : 'Poland', specialization: 'ruby', requestId: 0},
  {country : 'Poland', specialization: 'scala', requestId: 0},
  {country : 'Poland', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'Poland', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'Poland', specialization: 'devops-engineer', requestId: 0},
  {country : 'Poland', specialization: 'embedded-engineer', requestId: 0},
  {country : 'Poland', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'Poland', specialization: 'it-analyst', requestId: 0},
  {country : 'Poland', specialization: 'network/system administration', requestId: 0},
  {country : 'Poland', specialization: 'product-management', requestId: 0},
  {country : 'Poland', specialization: 'qa-automation', requestId: 0},
  {country : 'Poland', specialization: 'robotics-engineer', requestId: 0},
  {country : 'Poland', specialization: 'sap-engineer', requestId: 0},
  {country : 'Poland', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'Poland', specialization: 'software/system architect', requestId: 0},
  {country : 'Poland', specialization: 'technical-support', requestId: 0},
  {country : 'Poland', specialization: 'ui/ux design', requestId: 0},
  {country : 'Poland', specialization: 'unity-developer', requestId: 0},

  {country : 'Russia', specialization: 'android', requestId: 2198},
  {country : 'Russia', specialization: 'c++', requestId: 2199},
  {country : 'Russia', specialization: 'c#', requestId: 0},
  {country : 'Russia', specialization: 'go', requestId: 0},
  {country : 'Russia', specialization: 'ios', requestId: 0},
  {country : 'Russia', specialization: 'java', requestId: 0},
  {country : 'Russia', specialization: 'javascript', requestId: 0},
  {country : 'Russia', specialization: 'php', requestId: 0},
  {country : 'Russia', specialization: 'python', requestId: 0},
  {country : 'Russia', specialization: 'ruby', requestId: 0},
  {country : 'Russia', specialization: 'scala', requestId: 0},
  {country : 'Russia', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'Russia', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'Russia', specialization: 'devops-engineer', requestId: 0},
  {country : 'Russia', specialization: 'embedded-engineer', requestId: 0},
  {country : 'Russia', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'Russia', specialization: 'it-analyst', requestId: 0},
  {country : 'Russia', specialization: 'network/system administration', requestId: 0},
  {country : 'Russia', specialization: 'product-management', requestId: 0},
  {country : 'Russia', specialization: 'qa-automation', requestId: 0},
  {country : 'Russia', specialization: 'robotics-engineer', requestId: 0},
  {country : 'Russia', specialization: 'sap-engineer', requestId: 0},
  {country : 'Russia', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'Russia', specialization: 'software/system architect', requestId: 0},
  {country : 'Russia', specialization: 'technical-support', requestId: 0},
  {country : 'Russia', specialization: 'ui/ux design', requestId: 0},
  {country : 'Russia', specialization: 'unity-developer', requestId: 0},

  {country : 'UK', specialization: 'android', requestId: 0},
  {country : 'UK', specialization: 'c++', requestId: 0},
  {country : 'UK', specialization: 'c#', requestId: 0},
  {country : 'UK', specialization: 'go', requestId: 0},
  {country : 'UK', specialization: 'ios', requestId: 0},
  {country : 'UK', specialization: 'java', requestId: 0},
  {country : 'UK', specialization: 'javascript', requestId: 0},
  {country : 'UK', specialization: 'php', requestId: 0},
  {country : 'UK', specialization: 'python', requestId: 0},
  {country : 'UK', specialization: 'ruby', requestId: 0},
  {country : 'UK', specialization: 'scala', requestId: 0},
  {country : 'UK', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'UK', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'UK', specialization: 'devops-engineer', requestId: 0},
  {country : 'UK', specialization: 'embedded-engineer', requestId: 0},
  {country : 'UK', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'UK', specialization: 'it-analyst', requestId: 0},
  {country : 'UK', specialization: 'network/system administration', requestId: 0},
  {country : 'UK', specialization: 'product-management', requestId: 0},
  {country : 'UK', specialization: 'qa-automation', requestId: 0},
  {country : 'UK', specialization: 'robotics-engineer', requestId: 0},
  {country : 'UK', specialization: 'sap-engineer', requestId: 0},
  {country : 'UK', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'UK', specialization: 'software/system architect', requestId: 0},
  {country : 'UK', specialization: 'technical-support', requestId: 0},
  {country : 'UK', specialization: 'ui/ux design', requestId: 0},
  {country : 'UK', specialization: 'unity-developer', requestId: 0},

  {country : 'Ukraine', specialization: 'android', requestId: 0},
  {country : 'Ukraine', specialization: 'c++', requestId: 0},
  {country : 'Ukraine', specialization: 'c#', requestId: 0},
  {country : 'Ukraine', specialization: 'go', requestId: 0},
  {country : 'Ukraine', specialization: 'ios', requestId: 0},
  {country : 'Ukraine', specialization: 'java', requestId: 0},
  {country : 'Ukraine', specialization: 'javascript', requestId: 0},
  {country : 'Ukraine', specialization: 'php', requestId: 0},
  {country : 'Ukraine', specialization: 'python', requestId: 0},
  {country : 'Ukraine', specialization: 'ruby', requestId: 0},
  {country : 'Ukraine', specialization: 'scala', requestId: 0},
  {country : 'Ukraine', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'Ukraine', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'Ukraine', specialization: 'devops-engineer', requestId: 0},
  {country : 'Ukraine', specialization: 'embedded-engineer', requestId: 0},
  {country : 'Ukraine', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'Ukraine', specialization: 'it-analyst', requestId: 0},
  {country : 'Ukraine', specialization: 'network/system administration', requestId: 0},
  {country : 'Ukraine', specialization: 'product-management', requestId: 0},
  {country : 'Ukraine', specialization: 'qa-automation', requestId: 0},
  {country : 'Ukraine', specialization: 'robotics-engineer', requestId: 0},
  {country : 'Ukraine', specialization: 'sap-engineer', requestId: 0},
  {country : 'Ukraine', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'Ukraine', specialization: 'software/system architect', requestId: 0},
  {country : 'Ukraine', specialization: 'technical-support', requestId: 0},
  {country : 'Ukraine', specialization: 'ui/ux design', requestId: 0},
  {country : 'Ukraine', specialization: 'unity-developer', requestId: 0},

  {country : 'USA', specialization: 'android', requestId: 0},
  {country : 'USA', specialization: 'c++', requestId: 0},
  {country : 'USA', specialization: 'c#', requestId: 0},
  {country : 'USA', specialization: 'go', requestId: 0},
  {country : 'USA', specialization: 'ios', requestId: 0},
  {country : 'USA', specialization: 'java', requestId: 0},
  {country : 'USA', specialization: 'javascript', requestId: 0},
  {country : 'USA', specialization: 'php', requestId: 0},
  {country : 'USA', specialization: 'python', requestId: 0},
  {country : 'USA', specialization: 'ruby', requestId: 0},
  {country : 'USA', specialization: 'scala', requestId: 0},
  {country : 'USA', specialization: 'data-engineers / plsql', requestId: 0},
  {country : 'USA', specialization: 'datascience/ml/ai', requestId: 0},
  {country : 'USA', specialization: 'devops-engineer', requestId: 0},
  {country : 'USA', specialization: 'embedded-engineer', requestId: 0},
  {country : 'USA', specialization: 'gamedev / game-design', requestId: 0},
  {country : 'USA', specialization: 'it-analyst', requestId: 0},
  {country : 'USA', specialization: 'network/system administration', requestId: 0},
  {country : 'USA', specialization: 'product-management', requestId: 0},
  {country : 'USA', specialization: 'qa-automation', requestId: 0},
  {country : 'USA', specialization: 'robotics-engineer', requestId: 0},
  {country : 'USA', specialization: 'sap-engineer', requestId: 0},
  {country : 'USA', specialization: 'sharepoint-developer', requestId: 0},
  {country : 'USA', specialization: 'software/system architect', requestId: 0},
  {country : 'USA', specialization: 'technical-support', requestId: 0},
  {country : 'USA', specialization: 'ui/ux design', requestId: 0},
  {country : 'USA', specialization: 'unity-developer', requestId: 0},
];

function getDataSetIdByCountrySpecialization(country, specialization) {
  for (index1 = 0; index1< countrySpecializationsIds.length; index1++) {
    var item = countrySpecializationsIds[index1];
    if (item.country == country && item.position == specialization) {
      return item.id;
    }
  }
  return 0;
}
