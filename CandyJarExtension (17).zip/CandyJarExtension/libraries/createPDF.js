

var leftXPointer = 15;
var leftYPointer = 0;
var leftColumnWidth = 50;
var rightXPointer = 75;
var rightYPointer = 0;
var rightColumnWidth = 120;

var doc = "";



//начало оформления
function createPDF(data) {

  doc = new jsPDF("p","mm","a4");

  doc.setLineWidth(1);
  doc.setFont('Helvetica');

  addBackgroundRectangleFirstPage(doc);



  var name = createPdfGetName(data);
  var position = createPdfGetPosition(data);
  addNameBlock(doc, name, position)




  // LINKS BLOCK //
  var links = createPdfGetLinks(data);
  addLinksBlock(doc, links)
  //////////////////////////////


  if (leftYPointer > rightYPointer) {
    rightYPointer = leftYPointer;
  } else {
    leftYPointer = rightYPointer;
  }

  leftYPointer += 10;
  rightYPointer += 10;


  if (leftYPointer < 50) {
    leftYPointer = 50;
    rightYPointer = 50;
  }




  // INFO BLOCK //
  var location = createPdfGetLocation(data);
  var phone = " "
  if (data.about.phone && data.about.phone.length > 0 && isSignInAndHaveDays()) {
    phone = data.about.phone;
  }
  var mails = createPdfGetMails(data);
  addAddressBlock(doc, location, phone, mails)
  //////////////////


  // TAGS BLOCK //
  if (data.top_tags && data.top_tags.length > 0) {
    addTagsBlock(doc, data.top_tags)
  }


  // SKILLS BLOCK //
  if (data.languages && data.languages.length > 0) {
    addSkillsBlock(doc, data.languages)
  }
  //////////////////




  // ABOUT ME BLOCK //

  if (data.about.bio && data.about.bio.length > 0) {
    addAboutMeBlock(doc, data.about.bio);
  }

  if (data.work_experience && data.work_experience.length > 0) {
    addWorkExperienceBlock(doc, data.work_experience);
  }

  if (data.about.name && data.about.name.length > 0) {
      doc.save(data.about.name + ".pdf");
  } else {
    doc.save("CV.pdf");
  }

}

function createPdfGetMails(data) {
  const mails = new Set();
  if (data.about.email && data.about.email.length > 0 && isSignInAndHaveDays()) {
    mails.add(data.about.email);
  }
  if (data.about.emails && data.about.emails.length > 0 && isSignInAndHaveDays()) {
      for (index = 0; index < data.about.emails.length; index++) {
        mails.add(data.about.emails[index]);
      }
  }
  if (data.user_emails && data.user_emails.length > 0) {
      for (index = 0; index < data.user_emails.length; index++) {
        var userEmail = data.user_emails[index];
        if (userEmail.user_email == authorizationInfo.email) {
          if (isValidEmail(userEmail.developer_email)) {
            mails.add(userEmail.developer_email);
          }
        }
      }
  }
  return mails;
}

function createPdfGetLinks(data) {
  var links = [];
  if (data.login && data.login.length > 0) {
    links.push("www.candyjar.io/p/" + data.login);
  }
  if (data.accounts.linkedinHTML && data.accounts.linkedinHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.linkedinHTML);
  }
  if (data.accounts.facebookHTML && data.accounts.facebookHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.facebookHTML);
  }
  if (data.accounts.hhHTML && data.accounts.hhHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.hhHTML);
  }
  if (data.accounts.moiKrugHTML && data.accounts.moiKrugHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.moiKrugHTML);
  }
  if (data.accounts.stackoverflowHTML && data.accounts.stackoverflowHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.stackoverflowHTML);
  }
  if (data.accounts.telegramHTML && data.accounts.telegramHTML.length > 0 && isSignInAndHaveDays()) {
    links.push("telegram: " + data.accounts.telegramHTML);
  }
  if (data.accounts.webSite && data.accounts.webSite.length > 0 && isSignInAndHaveDays()) {
    links.push("webSite: " + data.accounts.webSite);
  }
  if (data.accounts.vkHTML && data.accounts.vkHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.vkHTML);
  }
  if (data.accounts.githubHTML && data.accounts.githubHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.githubHTML);
  }
  if (data.accounts.habrHTML && data.accounts.habrHTML.length > 0 && isSignInAndHaveDays()) {
    links.push(data.accounts.habrHTML);
  }
  return links;
}

function createPdfGetLocation(data) {
  var location = " "
  if (data.about.location && data.about.location.length > 0 && isSignInAndHaveDays()) {
    location = data.about.location;
  }
  return location;
}


function createPdfGetPosition(data) {
  var position = " "
  if (data.about.specialization && data.about.specialization.length > 0) {
    position = data.about.specialization;
  }
  if (data.about.current_position && data.about.current_position.length > 0) {
    position = data.about.current_position;
  }
  return position;
}

function createPdfGetName(data) {
  var name = " "
  if (data.about.name && data.about.name.length > 0) {
    name = data.about.name;
  }
  return name;
}

function addBackgroundRectangleFirstPage(doc) {
  doc.setDrawColor(0);
  doc.setFillColor(237,237,237);
  doc.rect(0, 0, 70, 297, 'F');
}

function makeTextGray (doc, x, y, text) {
  doc.setTextColor(153,153,153);
  doc.text(x,y, text)
  doc.setTextColor(0,0,0);
}

function addNameBlock(doc, name, position) {
  doc.setFontSize(14);
  doc.setFontType('bold');

  name = getTransliteration(name);
  if (name.length > 35) {
    name = name.substring(0, 34)
  }
  var names = doc.splitTextToSize(name, (leftColumnWidth-0-0));
  leftYPointer = 18;
  doc.text(leftXPointer, leftYPointer, names);
  doc.setFontType('normal');
  leftYPointer += 4 * names.length + 2 * (names.length)

  doc.setFontSize(12);
  position = getTransliteration(position);
  if (position.length > 35) {
    position = position.substring(0, 34)
  }
  var positions = doc.splitTextToSize(position, (leftColumnWidth-0-0));
  doc.text(leftXPointer, leftYPointer, positions);
  leftYPointer += 4 * positions.length + 2 * (positions.length)
}

function changeWrongSymbols(text) {
  text = text.replace(/●/g, "-");


  return text
}

function getTransliteration(pText) {
  var text = pText;
  text = text.replace(/й/g, "i")
  text = text.replace(/ц/g, "ts")
  text = text.replace(/у/g, "u")
  text = text.replace(/к/g, "k")
  text = text.replace(/е/g, "e")
  text = text.replace(/н/g, "n")
  text = text.replace(/г/g, "g")
  text = text.replace(/ш/g, "sh")
  text = text.replace(/щ/g, "shch")
  text = text.replace(/з/g, "z")
  text = text.replace(/х/g, "h")
  text = text.replace(/ъ/g, "")
  text = text.replace(/ф/g, "f")
  text = text.replace(/ы/g, "y")
  text = text.replace(/в/g, "v")
  text = text.replace(/а/g, "a")
  text = text.replace(/п/g, "p")
  text = text.replace(/р/g, "r")
  text = text.replace(/о/g, "o")
  text = text.replace(/л/g, "l")
  text = text.replace(/д/g, "d")
  text = text.replace(/ж/g, "zh")
  text = text.replace(/э/g, "e")
  text = text.replace(/ё/g, "e")
  text = text.replace(/я/g, "ya")
  text = text.replace(/ч/g, "ch")
  text = text.replace(/с/g, "s")
  text = text.replace(/м/g, "m")
  text = text.replace(/и/g, "i")
  text = text.replace(/т/g, "t")
  text = text.replace(/ь/g, "")
  text = text.replace(/б/g, "b")
  text = text.replace(/ю/g, "yu")

  text = text.replace(/Й/g, "I")
  text = text.replace(/Ц/g, "Ts")
  text = text.replace(/У/g, "U")
  text = text.replace(/К/g, "K")
  text = text.replace(/Е/g, "E")
  text = text.replace(/Н/g, "N")
  text = text.replace(/Г/g, "G")
  text = text.replace(/Ш/g, "Sh")
  text = text.replace(/Щ/g, "Shch")
  text = text.replace(/З/g, "Z")
  text = text.replace(/Х/g, "H")
  text = text.replace(/Ъ/g, "")
  text = text.replace(/Ф/g, "F")
  text = text.replace(/Ы/g, "Y")
  text = text.replace(/В/g, "V")
  text = text.replace(/А/g, "A")
  text = text.replace(/П/g, "P")
  text = text.replace(/Р/g, "R")
  text = text.replace(/О/g, "O")
  text = text.replace(/Л/g, "L")
  text = text.replace(/Д/g, "D")
  text = text.replace(/Ж/g, "Zh")
  text = text.replace(/Э/g, "E")
  text = text.replace(/Ё/g, "E")
  text = text.replace(/Я/g, "Ya")
  text = text.replace(/Ч/g, "Ch")
  text = text.replace(/С/g, "S")
  text = text.replace(/М/g, "M")
  text = text.replace(/И/g, "I")
  text = text.replace(/Т/g, "T")
  text = text.replace(/Ь/g, "")
  text = text.replace(/Б/g, "B")
  text = text.replace(/Ю/g, "Yu")

  text = text
          .replace(/\u0401/g, 'YO')
          .replace(/\u0419/g, 'I')
          .replace(/\u0426/g, 'TS')
          .replace(/\u0423/g, 'U')
          .replace(/\u041A/g, 'K')
          .replace(/\u0415/g, 'E')
          .replace(/\u041D/g, 'N')
          .replace(/\u0413/g, 'G')
          .replace(/\u0428/g, 'SH')
          .replace(/\u0429/g, 'SCH')
          .replace(/\u0417/g, 'Z')
          .replace(/\u0425/g, 'H')
          .replace(/\u042A/g, '')
          .replace(/\u0451/g, 'yo')
          .replace(/\u0439/g, 'i')
          .replace(/\u0446/g, 'ts')
          .replace(/\u0443/g, 'u')
          .replace(/\u043A/g, 'k')
          .replace(/\u0435/g, 'e')
          .replace(/\u043D/g, 'n')
          .replace(/\u0433/g, 'g')
          .replace(/\u0448/g, 'sh')
          .replace(/\u0449/g, 'sch')
          .replace(/\u0437/g, 'z')
          .replace(/\u0445/g, 'h')
          .replace(/\u044A/g, "'")
          .replace(/\u0424/g, 'F')
          .replace(/\u042B/g, 'I')
          .replace(/\u0412/g, 'V')
          .replace(/\u0410/g, 'a')
          .replace(/\u041F/g, 'P')
          .replace(/\u0420/g, 'R')
          .replace(/\u041E/g, 'O')
          .replace(/\u041B/g, 'L')
          .replace(/\u0414/g, 'D')
          .replace(/\u0416/g, 'ZH')
          .replace(/\u042D/g, 'E')
          .replace(/\u0444/g, 'f')
          .replace(/\u044B/g, 'i')
          .replace(/\u0432/g, 'v')
          .replace(/\u0430/g, 'a')
          .replace(/\u043F/g, 'p')
          .replace(/\u0440/g, 'r')
          .replace(/\u043E/g, 'o')
          .replace(/\u043B/g, 'l')
          .replace(/\u0434/g, 'd')
          .replace(/\u0436/g, 'zh')
          .replace(/\u044D/g, 'e')
          .replace(/\u042F/g, 'Ya')
          .replace(/\u0427/g, 'CH')
          .replace(/\u0421/g, 'S')
          .replace(/\u041C/g, 'M')
          .replace(/\u0418/g, 'I')
          .replace(/\u0422/g, 'T')
          .replace(/\u042C/g, "'")
          .replace(/\u0411/g, 'B')
          .replace(/\u042E/g, 'YU')
          .replace(/\u044F/g, 'ya')
          .replace(/\u0447/g, 'ch')
          .replace(/\u0441/g, 's')
          .replace(/\u043C/g, 'm')
          .replace(/\u0438/g, 'i')
          .replace(/\u0442/g, 't')
          .replace(/\u044C/g, "'")
          .replace(/\u0431/g, 'b')
          .replace(/\u044E/g, 'yu');

  return text
}

function addLinksBlock(doc, pLinks) {

  doc.setFontSize(9);
  doc.setTextColor(153,153,153);

  rightYPointer = 18;

  for (index = 0; index < pLinks.length; index++) {

    var link = pLinks[index];
    link = getTransliteration(link);

    if (link.length > 60) {
      link = link.substring(0, 59)
    }

    var links = doc.splitTextToSize(link, (rightColumnWidth-0-0));

    doc.text(rightXPointer,rightYPointer,links);

    rightYPointer += 2 * links.length + 2 * (links.length)


  }
  doc.setTextColor(0,0,0);

}

function addAddressBlock(doc, address, phone, pMails) {
  doc.setFontSize(9);
  doc.setFontType('bold');
  doc.text(leftXPointer, leftYPointer, 'INFO');
  leftYPointer += 2; // 52
  doc.setFontType('normal');
  doc.line(leftXPointer, leftYPointer, 65, leftYPointer);
  doc.setFontSize(9);

  leftYPointer += 6; // 58
  doc.text(leftXPointer,leftYPointer,'ADDRESS');


  address = getTransliteration(address);
  if (address.length > 50) {
    address = address.substring(0, 49)
  }
  leftYPointer += 4; // 62
  var addresses = doc.splitTextToSize(address, (leftColumnWidth-0-0));
  doc.text(leftXPointer, leftYPointer, addresses);

  leftYPointer += 2 * addresses.length + 2 * (addresses.length) // 68
  leftYPointer += 2 // 72
  doc.text(leftXPointer, leftYPointer,'PHONE');
  leftYPointer += 4 // 72
  phone = getTransliteration(phone);
  doc.text(leftXPointer, leftYPointer, phone);

  leftYPointer += 6 // 78
  doc.text(leftXPointer, leftYPointer, 'EMAIL');

  leftYPointer += 4 // 82
  for ( mail of pMails) {
    if (!isValidEmail(mail)) {
      continue;
    }
    mail = getTransliteration(mail);
    if (mail.length > 50) {
      mail = mail.substring(0, 49)
    }
    var mails = doc.splitTextToSize(mail, (leftColumnWidth-0-0));
    doc.text(leftXPointer, leftYPointer, mails);
    leftYPointer += 2 * mails.length + 2 * (mails.length) // 68
  }

}

function isValidEmail(mail) {

  if (mail.length == 0) {
    return false;
  }
  if (mail.includes("users.noreply.github.com")) {
    return false;
  }
  if (mail.includes(".local")) {
    return false;
  }
  if (!mail.includes("@")) {
    return false;
  }
  if (!mail.includes(".")) {
    return false;
  }

  return true;
}

function addTagsBlock(doc, pTags) {
  doc.setFontSize(9);
  doc.setFontType('bold');

  leftYPointer += 10; // 95

  doc.text(leftXPointer, leftYPointer, 'TAGS');
  doc.setFontType('normal');

  leftYPointer += 2; // 97
  doc.line(leftXPointer, leftYPointer, 65, leftYPointer);
  doc.setFontSize(9);

  tagsString = ""
  for (index = 0; index < pTags.length; index++) {
    tagsString += pTags[index] + ", ";
  }

  leftYPointer += 6; // 97
  var tags = doc.splitTextToSize(tagsString, (leftColumnWidth-0-0));
  doc.text(leftXPointer, leftYPointer, tags);
  leftYPointer += 2 * tags.length + 1 * (tags.length) // 68
}

function addSkillsBlock(doc, languages) {
  doc.setFontSize(9);
  doc.setFontType('bold');

  leftYPointer += 10; // 125

  doc.text(leftXPointer, leftYPointer, 'SKILLS');
  doc.setFontType('normal');

  leftYPointer += 2; // 127
  doc.line(leftXPointer, leftYPointer, 65, leftYPointer);
  doc.setFontSize(9);

  for (index = 0; index < languages.length; index++) {

    if (leftYPointer > 260) {
      continue;
    }

    var language = languages[index];

    var languageName = " ";
    if (language.language_name && language.language_name.length > 0) {
      languageName = language.language_name;
      languageName = getTransliteration(languageName);
    }
    languageName = getTransliteration(languageName);

    leftYPointer += 5; // 133
    doc.text(leftXPointer, leftYPointer, languageName);

    var yearsExperienceInt = 0;
    if (language.years_experience_int && language.years_experience_int > 0) {
      yearsExperienceInt = language.years_experience_int;
      leftYPointer += 4; // 137
    }
    var cicleXposition = 16;
    for (intYear = 0; intYear < yearsExperienceInt; intYear++) {
      doc.circle(cicleXposition, leftYPointer, 1, 'FD');
      cicleXposition += 5;
    }


    if (language.technologies && language.technologies.length > 0) {
      var technologyString = "";
      for (techIndex = 0; techIndex < language.technologies.length; techIndex++) {
        if (index > 30) {
          continue;
        }
        technologyName = getTransliteration(language.technologies[techIndex].group_name);
        technologyString += technologyName + ", ";
      }
      var technologiesString = doc.splitTextToSize(technologyString, (leftColumnWidth-0-0));
      leftYPointer += 8; // 145
      doc.text(leftXPointer, leftYPointer, technologiesString);
      leftYPointer += 2 * technologiesString.length + 1 * (technologiesString.length) // 68
    } else {
      leftYPointer += 4;
    }


    //leftYPointer += 4;
  }
}

function addAboutMeBlock(doc, bio) {
  doc.setFontSize(9);
  doc.setFontType('bold');
  doc.text(rightXPointer, rightYPointer, 'ABOUT ME'); // 50
  doc.setFontType('normal');
  rightYPointer += 2; // 52
  doc.line(rightXPointer, rightYPointer, 195, rightYPointer);
  doc.setFontSize(9);

  bio = getTransliteration(bio);

  rightYPointer += 6; // 58
  var bios = doc.splitTextToSize(bio, (rightColumnWidth-0-0));
  doc.text(rightXPointer, rightYPointer, bios);
  rightYPointer += 2 * bios.length + 2 * (bios.length) // 68
}

function addWorkExperienceBlock(doc, works) {
  doc.setFontSize(9);
  doc.setFontType('bold');

  rightYPointer += 10; // 95
  doc.text(rightXPointer, rightYPointer, 'WORK EXPERIENCE');
  doc.setFontType('normal');

  rightYPointer += 2; //97
  doc.line(rightXPointer, rightYPointer, 195, rightYPointer);
  doc.setFontSize(9);

    for (index = 0; index < works.length; index++) {
      var work = works[index];



      var workCompany = work.company;
      workCompany = changeWrongSymbols(workCompany);

      var periodCompany = work.period + ", " + workCompany;
      periodCompany = getTransliteration(periodCompany);
      if (periodCompany.length > 80) {
        periodCompany = periodCompany.substring(0, 79);
      }
      rightYPointer += 6; // 103
      doc.text(rightXPointer,rightYPointer, periodCompany);

      var position = work.position;
      position = getTransliteration(position);
      if (position.length > 150) {
        position = position.substring(0, 149)
      }
      rightYPointer += 5; // 108
      makeTextGray(doc,rightXPointer, rightYPointer, position);

      var description = work.description;
      if(description.length > 0) {
        description = getTransliteration(description);
        description = changeWrongSymbols(description);
        rightYPointer += 5; // 113
        var descriptions = doc.splitTextToSize(description, (rightColumnWidth-0-0));
        doc.text(rightXPointer, rightYPointer, descriptions);
        rightYPointer += 2 * descriptions.length + 2 * (descriptions.length) // 68
      } else {
        rightYPointer += 5; // 113
      }

      if (rightYPointer > 260) {
        doc.addPage();
        addBackgroundRectangleFirstPage(doc);
        rightYPointer = 20;
      }

    }


}




///////////////
