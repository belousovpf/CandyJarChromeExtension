execute();

function execute() {


  getAuthorization(authorizationOKfunction, authorizationFailFunction);
  if ($('.profile-person-footer').length) {
    startCandyjarProfilePage();
  }
  // if ($('.cards-block').length) {
  //   startCandyjarSearchPage();
  // }

}

function startCandyjarSearchPage() {
  var searchElements = $('.cards-block').children();
  for (index = 0; index < searchElements.length; index++) {
    var searchElement = $('.cards-block').children().eq(index);
    var candyjarLogin = getLinkFromCandyjarCard(searchElement);
    if (candyjarLogin.includes("%")) {
      continue;
    }
    candyjarLogin = candyjarLogin.replace("/en/lk/profile/view/1/", "");

    if ($('candyjarCardRankDiv' + candyjarLogin).length == 0) {
      addInformationForCandyjarCards(candyjarLogin, searchElement);
    }


  }


}

function addInformationForCandyjarCards(login, searchElement) {
  // var candyjarSectionDiv = createCandyjarSectionDiv(linkedinLogin);
  // searchElement.append(candyjarSectionDiv);

  var requestString = getSearchByTagRequestString(login, false);
  $.get( requestString, function(response) {
    if (response.data.search.length > 0) {
      var candyjarUser = getCandyjarUser(response, login);
      var candyjarLogin = candyjarUser.login;
      var topTags = candyjarUser.top_tags;
      var accounts = candyjarUser.accounts;
      var about = candyjarUser.about;
      var githubMetrics = candyjarUser.github_metrics;
      var languages = candyjarUser.languages;
      var tagsCount = candyjarUser.tags_count;
      var lastViewsData = candyjarUser.profileLastView;

      addCandyjarCardRankDiv(searchElement.children().eq(0), login, tagsCount, githubMetrics);


      var currentUserEmail = getCurrentUserEmail().toLowerCase();
      for (var i = 0; i < lastViewsData.length; i++) {
        var viewElement = lastViewsData[i];
        var viewUserEmail = viewElement.email.toLowerCase();;
        var viewUserDate = viewElement.last_view;
        if (currentUserEmail == viewUserEmail) {
          if (viewUserDate.length) {
            searchElement.children().eq(0).append(createCandySearchPageLastViewDiv(viewUserDate[0]));
          }
        }
      }
    }
  });
}

function createCandySearchPageLastViewDiv(date) {
  var candySearchPageLastViewDiv = $('<div>',{
    class: "candySearchPageLastViewDiv",
  });

  var candySearchPageLastViewDiv1 = $('<div>',{
    class: "candySearchPageLastViewDiv1",
    text: "last view:",
  });
  candySearchPageLastViewDiv.append(candySearchPageLastViewDiv1);

  var candySearchPageLastViewDiv2 = $('<div>',{
    class: "candySearchPageLastViewDiv2",
    text: date,
  });
  candySearchPageLastViewDiv.append(candySearchPageLastViewDiv2);

  return candySearchPageLastViewDiv;
}

function getCandyjarUser(response, userLoginTag) {
  if (response.data.search.length == 1) {
    var candyjarUser = response.data.search[0];
    candyjarUser.profileLastView = response.data.profileLastView;
    return candyjarUser;
  } else {
    var index = 0;
    for (index = 0; index < response.data.search.length; index++ ) {
      var candyjarUser = response.data.search[index];
      candyjarUser.profileLastView = response.data.profileLastView;
      if (candyjarUser.login.toLowerCase() == userLoginTag.toLowerCase()) {
        return candyjarUser;
      }
    }
  }
}







function getLinkFromCandyjarCard(element) {
  var result = "";
  element.find('a').each(function() {
    var className = $(this).attr('class');
    if (className.includes('button_bordered')) {
       var href = $(this).attr('href');
       if (href.includes("/en/lk/profile/view/1/") && result.length == 0) {
         result = href;
       }
    }
  });
  return result;
}

function startCandyjarProfilePage() {
  var url = getCandyjarLoginFromUrl();
  if (url.includes("?")) {
    return;
  }
  var requestString = getSearchByTagRequestString(url, true, "candyjar_profile");
  $.get(requestString, function( response ) {
    if (response.data.search.length > 0) {
      candidate = response.data.search[0];
      visualizeCandyjarElements(response, url);
      createCandyStarredBlock($('.profile-person-card'), candidate);
      sendTagTypeWebsiteData(url, "update", "candyjar");


      // if (!$('#candyjarProfileCandidateCard').length) {
      //   var candyjarProfileCandidateCard = $('<div>',{
      //     class: "candyjarProfileCandidateCard",
      //     id: "candyjarProfileCandidateCard"
      //   });
      //   $(".getcoder-profile-right").prepend(candyjarProfileCandidateCard);
      //   createCandidateCard(candyjarProfileCandidateCard, candidate, [], [])
      // }
      //
      // $(".getcoder-profile-left").remove();
      // $(".getcoder-profile-right").css('width','750px');
    }
  });
}

function visualizeCandyjarElements(response, url) {

  var candyjarLogin = response.data.search[0].login;
  var topTags = response.data.search[0].top_tags;
  var accounts = response.data.search[0].accounts;
  var about = response.data.search[0].about;
  var languages = response.data.search[0].languages;
  var githubMetrics = response.data.search[0].github_metrics;
  var tagsCount = response.data.search[0].tags_count;

  $('.profile-person-footer').append(createCandyPdfButton(getCandyjarLoginFromUrl()));
  addCandyjarCardRankDiv($('.profile-person-footer'), candyjarLogin, tagsCount, githubMetrics);


}

function createCandyPdfButton(login) {
  var candyPdfButton = $('<button/>', {
    class: "candyPdfButton",
    id: "candyPdfButton",
    text: 'PDF',
    click: function () {
      if (checkSignInAndOpenWindow()) {
        var requestString = getSearchByTagFullRequestString(login, false);
        $.get(requestString, function(candidate) {
          createPDF(candidate);
        });
        sendTagTypeWebsiteData(login, "pdf-button-pressed", "candyjar");
      }
    }
  });
  return candyPdfButton;
}

function getCandyjarLoginFromUrl() {
  var url = document.location.href;
  url = url.replace("https://www.candyjar.io/en/p/","");
  url = url.replace("http://www.candyjar.io/en/p/","");
  url = url.replace("https://candyjar.io/en/p/","");
  url = url.replace("http://candyjar.io/en/p/","");

  url = url.replace("https://www.candyjar.io/ru/p/","");
  url = url.replace("http://www.candyjar.io/ru/p/","");
  url = url.replace("https://candyjar.io/ru/p/","");
  url = url.replace("http://candyjar.io/ru/p/","");

  url = url.replace("https://www.candyjar.io/p/","");
  url = url.replace("http://www.candyjar.io/p/","");
  url = url.replace("https://candyjar.io/p/","");
  url = url.replace("http://candyjar.io/p/","");
  url = url.replace("/","");
  if (!url.includes("ldn")) {
    url += "github";
  }
  url = url.toLowerCase();
  return url;
}
