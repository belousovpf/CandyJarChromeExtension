document.getElementsByTagName("head")[0].insertAdjacentHTML("beforeend", "<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\" />");

function createCandyStarredBlock(parentDiv, candidate) {
  var candyStarredBlock = $('<div>',{
    class: "candyStarredBlock",
    id: "candyStarredBlock" + candidate.login
  });
  parentDiv.prepend(candyStarredBlock);

  var candyStarredBlockSpan = $('<span>',{
    class: "candyStarredBlockSpan fa fa-star",
    id: "candyStarredBlockSpan" + candidate.login,
    click: function () {
      if ($(".candyStarDeveloperLoadAnimationDiv").length) {
        return;
      }
      candyStarredBlock.append(createCandyStarToDeveloperLoaderAnimationDiv());
      if($(this).css("color") == "rgb(221, 221, 221)") {
        addStarToCandidate(candidate.github_id, true, candyStarredBlockCallbackFunction);
        $(this).css("color", "orange");
        candidate.is_starred = 1;
      } else {
        addStarToCandidate(candidate.github_id, false, candyStarredBlockCallbackFunction);
        $(this).css("color", "rgb(221, 221, 221)");
        candidate.is_starred = 0;
      }

    }
  });
  candyStarredBlock.append(candyStarredBlockSpan);
  if (candidate.is_starred && candidate.is_starred == 1) {
    $('#candyStarredBlockSpan' + candidate.login).css("color", "orange");
  }

}

function createCandyStarToDeveloperLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "candyStarDeveloperLoadAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function candyStarredBlockCallbackFunction() {
    $(".candyStarDeveloperLoadAnimationDiv").remove();
}
