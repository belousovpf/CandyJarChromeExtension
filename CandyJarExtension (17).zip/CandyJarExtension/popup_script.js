document.addEventListener("DOMContentLoaded",function(dcle) {


  if (authorizationInfo == 0) {
    getAuthorization(popupAuthorizationOKfunction, authorizationFailFunction, 'popup') ;
  }
});




function popupAuthorizationOKfunction(result) {
  authorizationInfo = result;
  if (authorizationInfo.status == "success") {
    vizualizeAuthorizedForm(authorizationInfo);
  } else {
      $('.app-main').append(vizualizeSignInForm());
  }
}



/////////////////////
// AUTHORIZED FORM //
function vizualizeAuthorizedForm(authorizationInfo) {

  // header elements //
  $('.app-header').append(createLoginDiv(authorizationInfo.name));
  $('.app-header').append(createCandyBurgerCheckBox());
  $('.app-header').append(createCandyBurgerButton());
  $('.app-header').append(createCandyBurgerMenuList(authorizationInfo.days));
  // header elements //

  // main elements //
  $('.app-main').append(createCandyMainNoDataDiv());
  $('.app-main').append(createCandyGoSearchEngineDiv());
  // main elements //


    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {from: "popup_script"}, function(response1) {
        developerTag = response1.developerTag;
        website_name = response1.website_name;
        if(chrome.runtime.lastError) {return;}
        var requestString = getSearchByTagFullRequestString(developerTag, false, website_name, 'popup_click');
        $('.candyMainNoDataDiv').empty();
        $('.candyMainNoDataDiv').append(createLoaderAnimationDiv());
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {vizualizeProfileForm(response);},
             error: function() {$('.candyMainNoDataDiv').empty();}
        });
      });
    });

}

function createLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "lds-ring"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function createLoginDiv(login) {
  var loginDiv = $('<div>',{
    class: "loginDiv",
    text: login,
  });
  return loginDiv;
}

function createCandyBurgerCheckBox() {
  var candyBurgerCheckBox = $('<input>',{
    id: "candyBurgerCheckBox",
    class: "candyBurgerCheckBox",
    type: "checkbox",
  }).on('change', function(){
    if(this.checked) {
      $(".tooltip").css("position","");
      //$(".tooltipInfo").css("position","");
      //$(".candyProfileUserActivitiesUlDiv").css("position","");
      //$(".candyProfileUserActivitiesLiDiv").css("position","");

      $(".candyProfileUserActivitiesDiv").css("display","none");


    } else {
      $(".candyProfileUserActivitiesDiv").css("display","block");
      $(".tooltip").css("position","relative");

      //$(".tooltip").css("position","relative");
      //$(".tooltipInfo").css("position","relative");
      //$(".candyProfileUserActivitiesUlDiv").css("position","relative");
      //$(".candyProfileUserActivitiesLiDiv").css("position","relative");
    }
  });

  return candyBurgerCheckBox;
}

function createCandyBurgerButton() {
  var candyBurgerButton = $('<label>',{
    class: "candyBurgerButton",
    for: "candyBurgerCheckBox",
  });

  var candyBurgerButtonSpan = $('<span>',{});
  candyBurgerButton.append(candyBurgerButtonSpan);
  return candyBurgerButton;
}

function createCandyBurgerMenuList(remainDaysInt) {
  var candyBurgerMenuList = $('<ul>',{
    class: "candyBurgerMenuList",
  });

  candyBurgerMenuList.append(createCandyBurgerFirstMenuItem());
  candyBurgerMenuList.append(createCandyBurgerSecondMenuItem());
  candyBurgerMenuList.append(createCandyBurgerThirdMenuItem(remainDaysInt));

  return candyBurgerMenuList;
}

function createCandyBurgerFirstMenuItem() {
  var candyBurgerFirstMenuItem = $('<div>',{
    class: "candyBurgerFirstMenuItem",
  });
  return candyBurgerFirstMenuItem;
}

function createCandyBurgerSecondMenuItem() {
  var candyBurgerSecondMenuItem = $('<div>',{
    class: "candyBurgerSecondMenuItem",
  });

  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Guide", "https://product.candyjar.io/guide"));
  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Blog", "https://medium.com/@candyjar"));
  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Search Engine", "https://candyjar.io/"));
  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Support", "https://product.candyjar.io/en/tbd-message"));
  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Help Center", "https://product.candyjar.io/help-center"));
  candyBurgerSecondMenuItem.append(createCandyBurgerSecondMenuSubItem("Log Out", "https://candyjar.io/logout"));

  return candyBurgerSecondMenuItem;
}

function createCandyBurgerSecondMenuSubItem(name, link) {
  var candyBurgerSecondMenuSubItem = $('<div>',{
    class: "candyBurgerSecondMenuSubItem",
  });

  var candyBurgerSecondMenuSubItemHref = $('<a>',{
    target: "_blank",
    href: link,
    text: name,
  });

  candyBurgerSecondMenuSubItem.append(candyBurgerSecondMenuSubItemHref);
  return candyBurgerSecondMenuSubItem;
}

function createCandyBurgerThirdMenuItem(dayInt) {
  var candyBurgerThirdMenuItem = $('<div>',{
    class: "candyBurgerThirdMenuItem",
  });

  var candyBurgerBalance = $('<span>',{
    class: "candyBurgerBalance",
    text: dayInt + " day(s)",
  });
  candyBurgerThirdMenuItem.append(candyBurgerBalance);

  var candyBurgerRemains = $('<span>',{
    text: "Remains",
  });
  candyBurgerThirdMenuItem.append(candyBurgerRemains);
  candyBurgerThirdMenuItem.append(createCandyBurgerUpgradeDiv());

  return candyBurgerThirdMenuItem;
}

function createCandyBurgerUpgradeDiv(dayInt) {
  var candyBurgerUpgradeDiv = $('<div>',{
    class: "candyBurgerUpgradeDiv",
  });

  var candyBurgerUpgradeHref = $('<a>',{
    class: "candyBurgerUpgradeHref",
    href: "https://product.candyjar.io/search-engine-pricing",
    target: "_blank",
    text: "Upgrade",
  });
  candyBurgerUpgradeDiv.append(candyBurgerUpgradeHref);

  return candyBurgerUpgradeDiv;
}

function createCandyGoSearchEngineDiv() {
  var candyGoSearchEngineDiv = $('<button>',{
    class: "candyGoSearchEngineDiv",
    text: "Go to Sourcing",
    click: function () {
      chrome.tabs.create({url: chrome.extension.getURL('cabinet/cabinet.html')});
        // var win = window.open("https://candyjar.io/", '_blank');
        // if (win) {win.focus();}
    }
  });
  return candyGoSearchEngineDiv;
}

function createCandyMainNoDataDiv() {
  var candyMainNoDataDiv = $('<div>',{
    class: "candyMainNoDataDiv",
  });

  var candyMainNoDataText = $('<div>',{
    class: "candyMainNoDataText",
  });
  candyMainNoDataDiv.append(candyMainNoDataText);

  var candyMainNoDataTextP1 = $('<p>',{
    text: "Everything is good!",
  });
  candyMainNoDataText.append(candyMainNoDataTextP1);

  var candyMainNoDataTextP2 = $('<p>',{
    text: "Now browse any Linkedin / Github / Candyjar / Xing profile. If nothing happens, try refreshing or opening a new window.",
  });
  candyMainNoDataText.append(candyMainNoDataTextP2);

  var candyMainNoDataTextP3 = $('<p>',{
    text: "OR",
  });
  candyMainNoDataText.append(candyMainNoDataTextP3);


  return candyMainNoDataDiv;
}
// AUTHORIZED FORM //
/////////////////////

//////////////////
// PROFILE FORM //
function vizualizeProfileForm(response) {
  if (response === undefined) {
    return;
  }
  $('.candyMainNoDataDiv').remove();


  console.log("response");
  console.log(response);
  //$('.app-main').append(createCandyProfileAboutDiv(response.about.avatar_url, response.about.name, response.about.location, response.about.current_position, response.about.company, isHireable));
  createCandyProfileAboutDiv($('.app-main'), response);

  var emailsSet = getEmailsSet(response);
  //$('.app-main').append(createCandyProfileContactsDiv(emailsSet, response.login, response.about, response.accounts, response.login));
  createPopupContactsBlock($('.app-main'), response);
  createPopupCommentBlock($('.app-main'), response);
  //createPopupFirstLetterBlock($('.app-main'), response);
  $('.app-main').append(createCandyProfileUserActivitiesDiv(emailsSet, response));
  //$('.app-main').append(createCandyProfileGithubPerfomanceDiv(response.github_metrics.total_github_activity, response.tags_count, response.languages));
  //$('.app-main').append(createCandyProfileTagsDiv(response.top_tags));



  if (isSignInAndHaveDays()) {
    getMessages(emailsSet, false, getMessagesResult);
  }

}

function getPositionCompanyString(position, company) {
  var result = "";
  if (position === undefined || position.length == 0) {
    return result;
  }
  result = position;
  if (company === undefined || company.length == 0) {
    return result;
  }
  result += " at " + company;

  return result;
}





function isValidEmail(mail) {

  if (mail.length == 0) {
    return false;
  }
  if (mail.includes("users.noreply.github.com")) {
    return false;
  }
  if (mail.includes(".local")) {
    return false;
  }
  if (!mail.includes("@")) {
    return false;
  }
  if (!mail.includes(".")) {
    return false;
  }

  return true;
}

function getEmailsSet(response) {
  const mails = new Set();
  data = response;
  if (data.about.email && data.about.email.length > 0) {
    if (isValidEmail(data.about.email)) {
      mails.add(data.about.email);
    }
  }
  if (data.about.emails && data.about.emails.length > 0) {
      for (index = 0; index < data.about.emails.length; index++) {
        if (isValidEmail(data.about.emails[index])) {
          mails.add(data.about.emails[index]);
        }
      }
  }
  if (data.user_emails && data.user_emails.length > 0) {
      for (index = 0; index < data.user_emails.length; index++) {
        var userEmail = data.user_emails[index];
        if (userEmail.user_email == authorizationInfo.email) {
          if (isValidEmail(userEmail.developer_email)) {
            mails.add(userEmail.developer_email);
          }
        }
      }
  }
  return mails;
}

function createCandyProfileWorkExperienceDiv(workExperienceSet, title, candyProfileSecondBlockId, buttonId, type) {
  var candyProfileWorkExperienceDiv = $('<div>',{
    class: "candyProfileWorkExperienceDiv",
  });

  var candyProfileWorkExperienceText = $('<h6>',{
    class: "candyProfileWorkExperienceText",
    text: title,
  });
  candyProfileWorkExperienceDiv.append(candyProfileWorkExperienceText);

  var candyProfileWorkExperienceFirstBlock = $('<div>',{
    class: "candyProfileWorkExperienceFirstBlock",
  });
  candyProfileWorkExperienceDiv.append(candyProfileWorkExperienceFirstBlock);

  var candyProfileWorkExperienceSecondBlock = $('<div>',{
    class: "candyProfileWorkExperienceSecondBlock",
    id: candyProfileSecondBlockId,
  });

  var index = 0;
  for (index = 0; index < workExperienceSet.length; index++) {
    var workExperienceItem = workExperienceSet[index];
    candyProfileWorkExperienceItem = createCandyProfileWorkExperienceItem(index+1, workExperienceItem.period, workExperienceItem.company, workExperienceItem.position);
    if (index < 3) {
      candyProfileWorkExperienceFirstBlock.append(candyProfileWorkExperienceItem);
    } else {
      candyProfileWorkExperienceSecondBlock.append(candyProfileWorkExperienceItem);
    }
  }
  if (index >= 3) {
    candyProfileWorkExperienceDiv.append(candyProfileWorkExperienceSecondBlock);
    var candyProfileWorkExperienceViewMoreButton = $('<button>',{
      class: "candyProfileWorkExperienceViewMoreButton",
      id: buttonId,
      text: "View More",
    });
    if (type=="WorkExperience") {
        candyProfileWorkExperienceViewMoreButton.click(candyProfileWorkExperienceViewMoreButtonClick);
    } else {
        candyProfileWorkExperienceViewMoreButton.click(candyProfileEducationViewMoreButtonClick);
    }
    candyProfileWorkExperienceDiv.append(candyProfileWorkExperienceViewMoreButton);
  }

  return candyProfileWorkExperienceDiv;
}


function candyProfileWorkExperienceViewMoreButtonClick() {
  var moreText = document.getElementById("candyProfileWorkExperienceSecondBlockId");
  var btnText = document.getElementById("candyProfileWorkExperienceViewMoreButton");

  if (btnText.innerHTML == "View Less") {
    btnText.innerHTML = "View More";
    moreText.style.display = "none";
  } else {
    btnText.innerHTML = "View Less";
    moreText.style.display = "inline";
  }
}

function candyProfileEducationViewMoreButtonClick() {
  var moreText = document.getElementById("candyProfileEducationSecondBlockId");
  var btnText = document.getElementById("candyProfileEducationViewMoreButton");

  if (btnText.innerHTML == "View Less") {
    btnText.innerHTML = "View More";
    moreText.style.display = "none";
  } else {
    btnText.innerHTML = "View Less";
    moreText.style.display = "inline";
  }
}

function createCandyProfileWorkExperienceItem(index, period, company, position) {
  var candyProfileWorkExperienceItem = $('<div>',{
    class: "candyProfileWorkExperienceItem",
  });

  var candyProfileWorkExperienceItemPosition = $('<div>',{
    class: "candyProfileWorkExperienceItemPosition",
    text: position,
  });
  candyProfileWorkExperienceItem.append(candyProfileWorkExperienceItemPosition);

  var candyProfileWorkExperienceItemPeriod = $('<div>',{
    class: "candyProfileWorkExperienceItemPeriod",
    text: period,
  });
  candyProfileWorkExperienceItem.append(candyProfileWorkExperienceItemPeriod);

  var candyProfileWorkExperienceItemCompany = $('<div>',{
    class: "candyProfileWorkExperienceItemCompany",
    text: company,
  });
  candyProfileWorkExperienceItem.append(candyProfileWorkExperienceItemCompany);


  return candyProfileWorkExperienceItem;
}



function getCommitsByYear(languages) {

  var datasets = [];

  var backgroundColors = [
    'rgba(30, 137, 40, 0.2)',
    'rgba(138, 84, 78, 0.2)',
    'rgba(75, 192, 192, 0.2)',
    'rgba(75, 100, 100, 0.2)',
    'rgba(180, 229, 115, 0.2)'
  ];

  var borderColors = [
    'rgba(30, 137, 40, 1)',
    'rgba(138, 84, 78, 1)',
    'rgba(75, 192, 192, 1)',
    'rgba(75, 100, 100, 1)',
    'rgba(180, 229, 115, 1)'
  ];


  var maxNumberOfLanguages = 5;
  for (index = 0; index < languages.length; index++) {
  //languages.forEach(function(item, index, array) {
    if (index >= maxNumberOfLanguages) {
      continue;
    }
    var item = languages[index];
    var languageName = item.language_name;
    var getCommitsByYear = item.commits_by_year;

    var y2020 = 0;
    var y2019 = 0;
    var y2018 = 0;
    var y2017 = 0;
    var y2016 = 0;
    // var y2015 = 0;
    // var y2014 = 0;
    var atLeastOneYearSet = false;

    getCommitsByYear.forEach(function(item, i, array) {
      if (item.year == 2020) {y2020 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2019) {y2019 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2018) {y2018 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2017) {y2017 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2016) {y2016 = item.commits_number; atLeastOneYearSet = true;};
      // if (item.year == 2015) {y2015 = item.commits_number; atLeastOneYearSet = true;};
      // if (item.year == 2014) {y2014 = item.commits_number; atLeastOneYearSet = true;};
    });

    if (atLeastOneYearSet) {
      var dataset = {
        label: languageName,
        data: [y2016, y2017, y2018, y2019, y2020],
        backgroundColor: backgroundColors[index],
        borderColor: borderColors[index],
        pointBackgroundColor: borderColors[index],
        borderWidth: 1
      }

      datasets.push(dataset);
    }
  };

  return datasets;
}









function createCandyProfileTagsDiv(topTags) {

  if (topTags === undefined || topTags.length == 0) {
    return;
  }

  var candyProfileTagsDiv = $('<div>',{
    class: "candyProfileTagsDiv",
  });

  var candyProfileTagsText = $('<h6>',{
    class: "candyProfileTagsText",
    text: "Tags",
  });
  candyProfileTagsDiv.append(candyProfileTagsText);

  var candyProfileTagsUl = $('<ul>',{
    class: "candyProfileTagsUl",
  });
  candyProfileTagsDiv.append(candyProfileTagsUl);

  for (index = 0; index < topTags.length; index++ ) {
    var topTag = topTags[index];
    var candyProfileTagsLi = $('<ul>',{
      class: "candyProfileTagsLi",
      text: topTag,
    });
    candyProfileTagsUl.append(candyProfileTagsLi);
  }



  return candyProfileTagsDiv;
}












// $(document).ready(
//   function() {
//     $("#candyBurgerCheckBox").addEventListener( 'change', function() {
//     if(this.checked) {
//         console.log("1");
//     } else {
//         console.log("2");
//     }
//   });
//   }
// );
// PROFILE FORM //
//////////////////
