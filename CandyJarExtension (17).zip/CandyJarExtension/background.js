
if (authorizationInfo == 0) {
  getAuthorization(authorizationOKfunction, authorizationFailFunction, 'background') ;

}


function listenerFunction(request, sender, sendResponse) {

  if (request.from == "linkedin_profile" && request.type == "get_messages_request") {
    emails = request.emails;
    emailsSet = new Set();
    for (var i = 0; i < emails.length; i++) {
          emailsSet.add(emails[i]);
    }
    sendResponse("ok");
    getMessages(emailsSet, false, getMessagesResult);
  };

  if (request.from == "linkedin_content" && request.type == "authorization_request") {
    if (authorizationInfo == 0) {
      getAuthorization(authorizationOKfunction, authorizationFailFunction, request.from) ;
    }
    sendResponse(authorizationInfo);
  };

  if (request.type == "execute_get_request" || request.type == "execute_get_request_pdf" || request.type == "execute_get_request_socials") {
    executeGetRequest(request.requestString, request.type);
    sendResponse("ok");
  };

  if (request.type == "get_similar_candidates") {
    getSimilarCandidates(request.candidate, request.from)
    sendResponse("ok");
  };



  if (request.type == "add_star_to_candidate") {
    addStarToCandidate(request.github_id, request.is_star, addStarToCandidateCallback, 'linkedin_profile');
    sendResponse("ok");
  };
  if (request.type == "sendUserComment") {
    sendUserComment(request.data)
  };

  if (request.type == "generateLetterRequest") {
    sendGenerateLetterRequest(request.candidate, request.request);
    sendResponse("ok");
  };
  if (request.type == "updateUserInfoRequest") {
    sendUpdateUserInfoRequest(request.candidate, request.request, request.parentDivId, request.letterText);
    sendResponse("ok");
  };
  if (request.type == "moveDeveloperToMyAtsVacancyRequest") {
    sendMoveDeveloperToMyAtsVacancyRequest(request.type, request.candidate, request.request, request.parentDivId, request.tooltipLoaderDivId);
    sendResponse("ok");
  };
  if (request.type == "createAndMoveDeveloperMyAtsVacancyRequest") {
    createAndMoveDeveloperMyAtsVacancyRequest(request.type, request.candidate, request.request, request.parentDivId, request.newVacancyTooltipDivFooterBlockLoaderDivId);
    sendResponse("ok");
  };
  if (request.type == "deleteDeveloperFromMyAtsVacancyRequest") {
    deleteDeveloperFromMyAtsVacancyRequest(request.type, request.candidate, request.request, request.vacancyStep, request.parentDivId, request.cardCandidateVacancyTooltipLoaderDivId);
    sendResponse("ok");
  };
  if (request.type == "moveDeveloperToMyAtsVacancyStepRequest") {
    moveDeveloperToMyAtsVacancyStepRequest(request.type, request.candidate, request.request, request.vacancyStep, request.loaderDivId, request.tooltipParentDivId);
    sendResponse("ok");
  };
  if (request.type == "addStarToCandidateRequest") {
    addStarToCandidate(request.type, request.developerId, request.isStarred, request.website_name);
    sendResponse("ok");
  };
  if (request.type == "goToCabinet") {
    chrome.tabs.create({url: chrome.extension.getURL('cabinet/cabinet.html')});
    sendResponse("ok");
  };


};
chrome.runtime.onMessage.addListener(listenerFunction);


function getMessagesResult(error, status, response) {
  var responseJson = JSON.parse(response);
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {from: "background", type:"get_messages_request", response: responseJson}, function(response) {});
  });
}

function executeGetRequest(requestString, request_type) {
    if (authorizationInfo == 0) {
      setTimeout(function() {executeGetRequest(requestString, request_type);}, 1000);
      return;
    };

    $.ajax({
         type: 'GET',
         url: requestString,
         success: function(response) {
           // console.log("sucess");
           // console.log(response);
           chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
             chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: request_type, response: response}, function(response) {});
           });
         },
         error: function(response) {
           // console.log("error");
           // console.log(response);
           chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
             chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: request_type, response: ""}, function(response) {});
           });
         }
    });
}

function addStarToCandidateCallback() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "add_star_to_candidate", response: ""}, function(response) {});
  });
}

function getSimilarCandidates(candidate, website_name = '') {
  var request = "https://candyjar.io/api/getSimilarCandidates?"  + "website_name=" + website_name;
  request += "&country=" + candidate.about.country;
  request += "&region=" + candidate.about.region;
  request += "&specialization=" + candidate.about.specialization;
  request += "&level=" + candidate.about.level;
  request += "&language=" + candidate.about.language;

  for (index = 0; index < candidate.top_tags.length; index++) {
    request += "&tags[]=" + candidate.top_tags[index];
  }

  $.get(request, function(similarCandidates) {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "get_similar_candidates", response: similarCandidates}, function(response) {});
    });
  }).fail(function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "get_similar_candidates", response: []}, function(response) {});
    });
  });
}

function sendUserComment(data) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", 'https://candyjar.io/description/add');
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.send(data);
}

function sendGenerateLetterRequest(candidate, requestString) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "generateLetterRequest", response: response, candidate: candidate}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "generateLetterRequest", response: '', candidate: candidate}, function(response) {});
         });
       }
  });
}

function sendUpdateUserInfoRequest(candidate, requestString, parentDivId, letterText) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "updateUserInfoRequest", response: response, candidate: candidate, parentDivId: parentDivId, letterText: letterText}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: "updateUserInfoRequest", response: '', candidate: candidate, parentDivId: parentDivId, letterText: letterText}, function(response) {});
         });
       }
  });
}


function sendMoveDeveloperToMyAtsVacancyRequest(requestType, candidate, requestString, parentDivId, tooltipLoaderDivId) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: response, candidate: candidate, parentDivId: parentDivId, tooltipLoaderDivId: tooltipLoaderDivId}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: '', candidate: candidate, parentDivId: parentDivId, tooltipLoaderDivId: tooltipLoaderDivId}, function(response) {});
         });
       }
  });
}

function createAndMoveDeveloperMyAtsVacancyRequest(requestType, candidate, requestString, parentDivId, newVacancyTooltipDivFooterBlockLoaderDivId) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: response, candidate: candidate, parentDivId: parentDivId, newVacancyTooltipDivFooterBlockLoaderDivId: newVacancyTooltipDivFooterBlockLoaderDivId}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: '', candidate: candidate, parentDivId: parentDivId, newVacancyTooltipDivFooterBlockLoaderDivId: newVacancyTooltipDivFooterBlockLoaderDivId}, function(response) {});
         });
       }
  });
}

function deleteDeveloperFromMyAtsVacancyRequest(requestType, candidate, requestString, vacancyStep, parentDivId, cardCandidateVacancyTooltipLoaderDivId) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: response, candidate: candidate, vacancyStep:vacancyStep, parentDivId: parentDivId, cardCandidateVacancyTooltipLoaderDivId: cardCandidateVacancyTooltipLoaderDivId}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: '', candidate: candidate, vacancyStep:vacancyStep, parentDivId: parentDivId, cardCandidateVacancyTooltipLoaderDivId: cardCandidateVacancyTooltipLoaderDivId}, function(response) {});
         });
       }
  });
}

function moveDeveloperToMyAtsVacancyStepRequest(requestType, candidate, requestString, vacancyStep, loaderDivId, tooltipParentDivId) {
  $.ajax({
       type: 'GET',
       url: requestString,
       success: function(response) {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: response, candidate: candidate, vacancyStep:vacancyStep, loaderDivId: loaderDivId, tooltipParentDivId: tooltipParentDivId}, function(response) {});
         });
       },
       error: function() {
         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
           chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType, response: '', candidate: candidate, vacancyStep:vacancyStep, loaderDivId: loaderDivId, tooltipParentDivId: tooltipParentDivId}, function(response) {});
         });
       }
  });
}

function addStarToCandidate(requestType, developerId, isStarred, website_name = '') {
  var data = 'loginId=' + encodeURIComponent(developerId) + '&isStared=' + encodeURIComponent(isStarred) + '&website_name=' + encodeURIComponent(website_name);
  var xhr = new XMLHttpRequest();
  xhr.open("POST", 'https://candyjar.io/candidate/addstar');
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.send(data);
  xhr.onreadystatechange = function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {from: "background", type: requestType}, function(response) {});
    });
  };
}
