# CandyJarExtension
chrome extension of candyjar.io
