function createCandidatesWebsitesReport(parentDiv, totalCandidatesWebsites) {

  if (!totalCandidatesWebsites.length) {
    return;
  }

  var adminPanelCandidatesWebsitesReportDiv = $('<div/>',{
    id: "adminPanelCandidatesWebsitesReportDiv",
    class: "adminPanelCandidatesWebsitesReportDiv",
  });
  parentDiv.append(adminPanelCandidatesWebsitesReportDiv);



  var adminPanelCandidatesWebsitesReportWebsitesDiv = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportWebsitesDiv",
  });
  adminPanelCandidatesWebsitesReportDiv.append(adminPanelCandidatesWebsitesReportWebsitesDiv);

  var adminPanelCandidatesWebsitesReportWebsitesText = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportWebsitesText",
    text: "Candidates websites"
  });
  adminPanelCandidatesWebsitesReportWebsitesDiv.append(adminPanelCandidatesWebsitesReportWebsitesText);

  for (var i = 0; i < totalCandidatesWebsites.length; i++) {
    createAdminPanelCandidatesWebsitesReportWebsiteDiv(
      adminPanelCandidatesWebsitesReportWebsitesDiv,
      totalCandidatesWebsites[i].website,
      (100*totalCandidatesWebsites[i].amount)/totalCandidatesWebsites[0].amount,
      totalCandidatesWebsites[i].amount,
    );
  }

}


function createAdminPanelCandidatesWebsitesReportWebsiteDiv(parentDiv, name, percent, valueText) {
  var adminPanelCandidatesWebsitesReportWebsiteDiv = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportWebsiteDiv",
  });
  parentDiv.append(adminPanelCandidatesWebsitesReportWebsiteDiv);

  var adminPanelCandidatesWebsitesReportWebsiteNameAndPercent = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportWebsiteNameAndPercent",
  });
  adminPanelCandidatesWebsitesReportWebsiteDiv.append(adminPanelCandidatesWebsitesReportWebsiteNameAndPercent);

  var candyProfileGithubRankingTechnologiesNameText = $('<div>',{
    text: name,
  });
  adminPanelCandidatesWebsitesReportWebsiteNameAndPercent.append(candyProfileGithubRankingTechnologiesNameText);

  var candyProfileGithubRankingTechnologiesPercentText = $('<div>',{
    text: valueText,
  });
  adminPanelCandidatesWebsitesReportWebsiteNameAndPercent.append(candyProfileGithubRankingTechnologiesPercentText);

  var adminPanelCandidatesWebsitesReportProgressDiv = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportProgressDiv",
  });
  adminPanelCandidatesWebsitesReportWebsiteDiv.append(adminPanelCandidatesWebsitesReportProgressDiv);

  var adminPanelCandidatesWebsitesReportProgressBar = $('<div>',{
    class: "adminPanelCandidatesWebsitesReportProgressBar",
  }).css('width', percent+"%");
  adminPanelCandidatesWebsitesReportProgressDiv.append(adminPanelCandidatesWebsitesReportProgressBar);

}
