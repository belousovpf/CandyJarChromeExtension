function createCandidatesCountriesReport(parentDiv, totalCandidatesCountries) {

  if (!totalCandidatesCountries.length) {
    return;
  }

  var adminPanelCandidatesCountriesReportDiv = $('<div/>',{
    id: "adminPanelCandidatesCountriesReportDiv",
    class: "adminPanelCandidatesCountriesReportDiv",
  });
  parentDiv.append(adminPanelCandidatesCountriesReportDiv);



  var adminPanelCandidatesCountriesReportCountriesDiv = $('<div>',{
    class: "adminPanelCandidatesCountriesReportCountriesDiv",
  });
  adminPanelCandidatesCountriesReportDiv.append(adminPanelCandidatesCountriesReportCountriesDiv);

  var adminPanelCandidatesCountriesReportCountriesText = $('<div>',{
    class: "adminPanelCandidatesCountriesReportCountriesText",
    text: "Candidates countries"
  });
  adminPanelCandidatesCountriesReportCountriesDiv.append(adminPanelCandidatesCountriesReportCountriesText);

  for (var i = 0; i < totalCandidatesCountries.length; i++) {
    createCandyProfileGithubRankingTechnologiesDiv(
      adminPanelCandidatesCountriesReportCountriesDiv,
      totalCandidatesCountries[i].country,
      (100*totalCandidatesCountries[i].amount)/totalCandidatesCountries[0].amount,
      totalCandidatesCountries[i].amount,
    );
  }

}


function createCandyProfileGithubRankingTechnologiesDiv(parentDiv, name, percent, valueText) {
  var adminPanelCandidatesCountriesReportCountryDiv = $('<div>',{
    class: "adminPanelCandidatesCountriesReportCountryDiv",
  });
  parentDiv.append(adminPanelCandidatesCountriesReportCountryDiv);

  var adminPanelCandidatesCountriesReportCountryNameAndPercent = $('<div>',{
    class: "adminPanelCandidatesCountriesReportCountryNameAndPercent",
  });
  adminPanelCandidatesCountriesReportCountryDiv.append(adminPanelCandidatesCountriesReportCountryNameAndPercent);

  var candyProfileGithubRankingTechnologiesNameText = $('<div>',{
    text: name,
  });
  adminPanelCandidatesCountriesReportCountryNameAndPercent.append(candyProfileGithubRankingTechnologiesNameText);

  var candyProfileGithubRankingTechnologiesPercentText = $('<div>',{
    text: valueText,
  });
  adminPanelCandidatesCountriesReportCountryNameAndPercent.append(candyProfileGithubRankingTechnologiesPercentText);

  var adminPanelCandidatesCountriesReportProgressDiv = $('<div>',{
    class: "adminPanelCandidatesCountriesReportProgressDiv",
  });
  adminPanelCandidatesCountriesReportCountryDiv.append(adminPanelCandidatesCountriesReportProgressDiv);

  var adminPanelCandidatesCountriesReportProgressBar = $('<div>',{
    class: "adminPanelCandidatesCountriesReportProgressBar",
  }).css('width', percent+"%");;
  adminPanelCandidatesCountriesReportProgressDiv.append(adminPanelCandidatesCountriesReportProgressBar);

}
