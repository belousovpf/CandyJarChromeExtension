function createUsersTable(parentDiv, usersData) {
  var adminPanelUsersTableBlock = $('<div/>',{
    id: "adminPanelUsersTableBlock",
    class: "adminPanelUsersTableBlock",
  });
  parentDiv.append(adminPanelUsersTableBlock);

  adminPanelUsersTableBlock.append(getUsersTable(usersData));
  $('#usersTable').DataTable();
}

function getUsersTable(usersData) {

  var table = $('<table/>',{id: "usersTable", class:"compact hover"});
  var thead = $('<thead/>',{});table.append(thead);
      var tr = $('<tr/>',{});thead.append(tr);
          var th = $('<th/>',{text: 'id',});tr.append(th);
          var th = $('<th/>',{text: 'email',});tr.append(th);
          var th = $('<th/>',{text: 'name',});tr.append(th);
          var th = $('<th/>',{text: 'regDate',});tr.append(th);
          var th = $('<th/>',{text: 'endDate',});tr.append(th);
          var th = $('<th/>',{text: 'online',});tr.append(th);
          // var th = $('<th/>',{text: 'linkedin',});tr.append(th);
          // var th = $('<th/>',{text: 'github',});tr.append(th);
          // var th = $('<th/>',{text: 'moikrug',});tr.append(th);
          // var th = $('<th/>',{text: 'xing',});tr.append(th);
          // var th = $('<th/>',{text: 'candyjar',});tr.append(th);

          var th = $('<th/>',{text: 'socials',});tr.append(th);
          var th = $('<th/>',{text: 'email',});tr.append(th);
          var th = $('<th/>',{text: 'popup',});tr.append(th);
          var th = $('<th/>',{text: 'search',});tr.append(th);
          var th = $('<th/>',{text: 'pdf',});tr.append(th);
          var th = $('<th/>',{text: 'star',});tr.append(th);
          var th = $('<th/>',{text: 'desc',});tr.append(th);
          var th = $('<th/>',{text: 'similar',});tr.append(th);
          var th = $('<th/>',{text: 'vacancies',});tr.append(th);
          var th = $('<th/>',{text: 'vacancyCandidates',});tr.append(th);
          var th = $('<th/>',{text: 'letters',});tr.append(th);
          var th = $('<th/>',{text: 'booleanSearch',});tr.append(th);

  var tbody = $('<tbody>',{});table.append(tbody);

  for (var i = 0; i < usersData.length; i++) {
    var user = usersData[i];
    var tr = $('<tr/>',{});tbody.append(tr);
      var td = $('<td/>',{text: user.user_id,});tr.append(td);
      var td = $('<td/>',{text: user.email,});tr.append(td);
      var td = $('<td/>',{text: user.name,});tr.append(td);
      var td = $('<td/>',{text: user.registration_date,});tr.append(td);
      var td = $('<td/>',{text: user.trial_end_date,});tr.append(td);
      var td = $('<td/>',{text: user.last_activity,});tr.append(td);
      // var td = $('<td/>',{text: user.linkedin_views,});tr.append(td);
      // var td = $('<td/>',{text: user.github_views,});tr.append(td);
      // var td = $('<td/>',{text: user.moikrug_views,});tr.append(td);
      // var td = $('<td/>',{text: user.xing_views,});tr.append(td);
      // var td = $('<td/>',{text: user.candyjar_views,});tr.append(td);

      var td = $('<td/>',{text: user.socials_click,});tr.append(td);
      var td = $('<td/>',{text: user.email_click,});tr.append(td);
      var td = $('<td/>',{text: user.popup_click,});tr.append(td);
      var td = $('<td/>',{text: user.search_click,});tr.append(td);
      var td = $('<td/>',{text: user.pdf_click,});tr.append(td);
      var td = $('<td/>',{text: user.add_star,});tr.append(td);
      var td = $('<td/>',{text: user.add_description,});tr.append(td);
      var td = $('<td/>',{text: user.similar_click,});tr.append(td);
      var td = $('<td/>',{text: user.vacancies,});tr.append(td);
      var td = $('<td/>',{text: user.vacancyCandidates,});tr.append(td);
      var td = $('<td/>',{text: user.letters,});tr.append(td);
      var td = $('<td/>',{text: user.booleanSearch,});tr.append(td);


      var trialEndDate = new Date(user.trial_end_date);
      if (trialEndDate > new Date()) {
        tr.css('backgroundColor', '#E4FFF9');
      }
  }




  // var tfoot = $('<tfoot>',{
  //   // id: "adminPanelUsersTableBlock",
  //   // class: "adminPanelUsersTableBlock",
  // });
  // table.append(tfoot);
  //
  //     var tr = $('<tr/>',{
  //       // id: "adminPanelUsersTableBlock",
  //       // class: "adminPanelUsersTableBlock",
  //     });
  //     tfoot.append(tr);
  //
  //         var th = $('<th/>',{
  //           // id: "adminPanelUsersTableBlock",
  //           // class: "adminPanelUsersTableBlock",
  //           text: 'name',
  //         });
  //         tr.append(th);
  //
  //         var th = $('<th/>',{
  //           // id: "adminPanelUsersTableBlock",
  //           // class: "adminPanelUsersTableBlock",
  //           text: 'position',
  //         });
  //         tr.append(th);

  return table;
}
