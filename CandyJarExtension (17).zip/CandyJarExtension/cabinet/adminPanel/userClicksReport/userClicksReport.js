function createUserClicksReport(parentDiv, totalUsersClicks) {

  if (!totalUsersClicks.length) {
    return;
  }

  var adminPanelUserClicksReportBlock = $('<div/>',{
    id: "adminPanelUserClicksReportBlock",
    class: "adminPanelUserClicksReportBlock",
  });
  parentDiv.append(adminPanelUserClicksReportBlock);



  var adminPanelUserClicksReportDiv = $('<div>',{
    class: "adminPanelUserClicksReportDiv",
  });
  adminPanelUserClicksReportBlock.append(adminPanelUserClicksReportDiv);

  var adminPanelUserClicksReportText = $('<div>',{
    class: "adminPanelUserClicksReportText",
    text: "User clicks"
  });
  adminPanelUserClicksReportDiv.append(adminPanelUserClicksReportText);

  for (var i = 0; i < totalUsersClicks.length; i++) {
    createAdminPanelUserClicksReportElement(
      adminPanelUserClicksReportDiv,
      totalUsersClicks[i].clickedElement,
      (100*totalUsersClicks[i].amount)/totalUsersClicks[0].amount,
      totalUsersClicks[i].amount,
    );
  }

}


function createAdminPanelUserClicksReportElement(parentDiv, name, percent, valueText) {
  var adminPanelUserClicksReportElement = $('<div>',{
    class: "adminPanelUserClicksReportElement",
  });
  parentDiv.append(adminPanelUserClicksReportElement);

  var adminPanelUserClicksReportNameAndPercent = $('<div>',{
    class: "adminPanelUserClicksReportNameAndPercent",
  });
  adminPanelUserClicksReportElement.append(adminPanelUserClicksReportNameAndPercent);

  var candyProfileGithubRankingTechnologiesNameText = $('<div>',{
    text: name,
  });
  adminPanelUserClicksReportNameAndPercent.append(candyProfileGithubRankingTechnologiesNameText);

  var candyProfileGithubRankingTechnologiesPercentText = $('<div>',{
    text: valueText,
  });
  adminPanelUserClicksReportNameAndPercent.append(candyProfileGithubRankingTechnologiesPercentText);

  var adminPanelUserClicksReportProgressDiv = $('<div>',{
    class: "adminPanelUserClicksReportProgressDiv",
  });
  adminPanelUserClicksReportElement.append(adminPanelUserClicksReportProgressDiv);

  var adminPanelUserClicksReportProgressBar = $('<div>',{
    class: "adminPanelUserClicksReportProgressBar",
  }).css('width', percent+"%");
  adminPanelUserClicksReportProgressDiv.append(adminPanelUserClicksReportProgressBar);

}
