function createCandidatesSpecializationsReport(parentDiv, totalCandidatesSpecializations) {

  if (!totalCandidatesSpecializations.length) {
    return;
  }

  var adminPanelCandidatesSpecializationsReportDiv = $('<div/>',{
    id: "adminPanelCandidatesSpecializationsReportDiv",
    class: "adminPanelCandidatesSpecializationsReportDiv",
  });
  parentDiv.append(adminPanelCandidatesSpecializationsReportDiv);



  var adminPanelCandidatesSpecializationsReportSpecializationsDiv = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportSpecializationsDiv",
  });
  adminPanelCandidatesSpecializationsReportDiv.append(adminPanelCandidatesSpecializationsReportSpecializationsDiv);

  var adminPanelCandidatesSpecializationsReportSpecializationsText = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportSpecializationsText",
    text: "Candidates specializations"
  });
  adminPanelCandidatesSpecializationsReportSpecializationsDiv.append(adminPanelCandidatesSpecializationsReportSpecializationsText);

  for (var i = 0; i < totalCandidatesSpecializations.length; i++) {
    createAdminPanelCandidatesSpecializationsReportSpecializationDiv(
      adminPanelCandidatesSpecializationsReportSpecializationsDiv,
      totalCandidatesSpecializations[i].specialization,
      (100*totalCandidatesSpecializations[i].amount)/totalCandidatesSpecializations[0].amount,
      totalCandidatesSpecializations[i].amount,
    );
  }

}


function createAdminPanelCandidatesSpecializationsReportSpecializationDiv(parentDiv, name, percent, valueText) {
  var adminPanelCandidatesSpecializationsReportSpecializationDiv = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportSpecializationDiv",
  });
  parentDiv.append(adminPanelCandidatesSpecializationsReportSpecializationDiv);

  var adminPanelCandidatesSpecializationsReportSpecializationNameAndPercent = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportSpecializationNameAndPercent",
  });
  adminPanelCandidatesSpecializationsReportSpecializationDiv.append(adminPanelCandidatesSpecializationsReportSpecializationNameAndPercent);

  var candyProfileGithubRankingTechnologiesNameText = $('<div>',{
    text: name,
  });
  adminPanelCandidatesSpecializationsReportSpecializationNameAndPercent.append(candyProfileGithubRankingTechnologiesNameText);

  var candyProfileGithubRankingTechnologiesPercentText = $('<div>',{
    text: valueText,
  });
  adminPanelCandidatesSpecializationsReportSpecializationNameAndPercent.append(candyProfileGithubRankingTechnologiesPercentText);

  var adminPanelCandidatesSpecializationsReportProgressDiv = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportProgressDiv",
  });
  adminPanelCandidatesSpecializationsReportSpecializationDiv.append(adminPanelCandidatesSpecializationsReportProgressDiv);

  var adminPanelCandidatesSpecializationsReportProgressBar = $('<div>',{
    class: "adminPanelCandidatesSpecializationsReportProgressBar",
  }).css('width', percent+"%");
  adminPanelCandidatesSpecializationsReportProgressDiv.append(adminPanelCandidatesSpecializationsReportProgressBar);

}
