function createUserRegistrationsReport(parentDiv, userRegistrationsData) {
  var adminPanelUserRegistrationsReportDiv = $('<div/>',{
    id: "adminPanelUserRegistrationsReportDiv",
    class: "adminPanelUserRegistrationsReportDiv",
    text: ""
  });
  parentDiv.append(adminPanelUserRegistrationsReportDiv);

  var adminPanelUserRegistrationsReportCanvas = $('<canvas/>',{
    id: "myChart",
    class: "adminPanelUserRegistrationsReportCanvas"
  });
  adminPanelUserRegistrationsReportDiv.append(adminPanelUserRegistrationsReportCanvas);

  labels = [];
  registrationData = [];
  authData = [];
  for (var i = 0; i < userRegistrationsData.length; i++) {
    labels.push(userRegistrationsData[i].monthName);
    registrationData.push(userRegistrationsData[i].registeredUsersIds.length);
    authData.push(userRegistrationsData[i].authUsersIds.length)
  }

  var registrationDataSet = {
    label: 'Registrations',
    data: registrationData,
    backgroundColor: 'rgba(30, 137, 40, 0.2)',
    borderColor: 'rgba(30, 137, 40, 1)',
    pointBackgroundColor: 'rgba(30, 137, 40, 1)',
    borderWidth: 1
  }

  var authDataSet = {
    label: 'Authorizations',
    data: authData,
    backgroundColor: 'rgba(138, 84, 78, 0.2)',
    borderColor: 'rgba(138, 84, 78, 1)',
    pointBackgroundColor: 'rgba(138, 84, 78, 1)',
    borderWidth: 1
  }

  var canvasCtx = adminPanelUserRegistrationsReportCanvas[0].getContext('2d');
  var myChart = new Chart(canvasCtx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [registrationDataSet, authDataSet],
    },
    options: {
      legend: {
        labels: {
          usePointStyle: true,
          boxWidth: 5,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
  });

  createUserActionsReport(parentDiv, userRegistrationsData);
  createCandidatesCountriesRussiaUkraineBelarusReport(parentDiv, userRegistrationsData);
}

function createUserActionsReport(parentDiv, userRegistrationsData) {
  var adminPanelUserRegistrationsReportDiv = $('<div/>',{
    id: "adminPanelUserRegistrationsReportDiv",
    class: "adminPanelUserRegistrationsReportDiv",
    text: ""
  });
  parentDiv.append(adminPanelUserRegistrationsReportDiv);

  var adminPanelUserRegistrationsReportCanvas = $('<canvas/>',{
    id: "myChart",
    class: "adminPanelUserRegistrationsReportCanvas"
  });
  adminPanelUserRegistrationsReportDiv.append(adminPanelUserRegistrationsReportCanvas);

  labels = [];
  selectionData = [];
  socialsData = [];
  popupData = [];
  for (var i = 0; i < userRegistrationsData.length; i++) {
    labels.push(userRegistrationsData[i].monthName);
    selectionData.push(userRegistrationsData[i].selectionUsersIds.length);
    socialsData.push(userRegistrationsData[i].socialsUsersIds.length);
    popupData.push(userRegistrationsData[i].popupUsersIds.length);
  }

  var selectionDataSet = {
    label: 'Selections',
    data: selectionData,
    backgroundColor: 'rgba(30, 137, 40, 0.2)',
    borderColor: 'rgba(30, 137, 40, 1)',
    pointBackgroundColor: 'rgba(30, 137, 40, 1)',
    borderWidth: 1
  }

  var socialsDataSet = {
    label: 'SocialsClick',
    data: socialsData,
    backgroundColor: 'rgba(138, 84, 78, 0.2)',
    borderColor: 'rgba(138, 84, 78, 1)',
    pointBackgroundColor: 'rgba(138, 84, 78, 1)',
    borderWidth: 1
  }

  var popupDataSet = {
    label: 'popupClick',
    data: popupData,
    backgroundColor: 'rgba(75, 192, 192, 0.2)',
    borderColor: 'rgba(75, 192, 192, 1)',
    pointBackgroundColor: 'rgba(75, 192, 192, 1)',
    borderWidth: 1
  }


  var canvasCtx = adminPanelUserRegistrationsReportCanvas[0].getContext('2d');
  var myChart = new Chart(canvasCtx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [selectionDataSet, socialsDataSet, popupDataSet],
    },
    options: {
      legend: {
        labels: {
          usePointStyle: true,
          boxWidth: 5,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
  });
}



function createCandidatesCountriesRussiaUkraineBelarusReport(parentDiv, userRegistrationsData) {
  var adminPanelUserRegistrationsReportDiv = $('<div/>',{
    id: "adminPanelUserRegistrationsReportDiv",
    class: "adminPanelUserRegistrationsReportDiv",
    text: ""
  });
  parentDiv.append(adminPanelUserRegistrationsReportDiv);

  var adminPanelUserRegistrationsReportCanvas = $('<canvas/>',{
    id: "myChart",
    class: "adminPanelUserRegistrationsReportCanvas"
  });
  adminPanelUserRegistrationsReportDiv.append(adminPanelUserRegistrationsReportCanvas);

  labels = [];
  russiaData = [];
  ukraineData = [];
  belarusData = [];
  for (var i = 0; i < userRegistrationsData.length; i++) {
    labels.push(userRegistrationsData[i].monthName);
    russiaData.push(userRegistrationsData[i].russiaDevelopersViews);
    ukraineData.push(userRegistrationsData[i].ukraineDevelopersViews);
    belarusData.push(userRegistrationsData[i].belarusDevelopersViews);
  }

  var russiaDataSet = {
    label: 'Russia',
    data: russiaData,
    backgroundColor: 'rgba(30, 137, 40, 0.2)',
    borderColor: 'rgba(30, 137, 40, 1)',
    pointBackgroundColor: 'rgba(30, 137, 40, 1)',
    borderWidth: 1
  }

  var ukraineDataSet = {
    label: 'Ukraine',
    data: ukraineData,
    backgroundColor: 'rgba(138, 84, 78, 0.2)',
    borderColor: 'rgba(138, 84, 78, 1)',
    pointBackgroundColor: 'rgba(138, 84, 78, 1)',
    borderWidth: 1
  }

  var belarusDataSet = {
    label: 'Belarus',
    data: belarusData,
    backgroundColor: 'rgba(75, 192, 192, 0.2)',
    borderColor: 'rgba(75, 192, 192, 1)',
    pointBackgroundColor: 'rgba(75, 192, 192, 1)',
    borderWidth: 1
  }


  var canvasCtx = adminPanelUserRegistrationsReportCanvas[0].getContext('2d');
  var myChart = new Chart(canvasCtx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [russiaDataSet, ukraineDataSet, belarusDataSet],
    },
    options: {
      legend: {
        labels: {
          usePointStyle: true,
          boxWidth: 5,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
  });
}
