var adminUserRegistrations = [];
var adminCurrentYearString = '2020';

function createAdminPanel(parentDiv) {

    // initializeMyTalentsPanelData();
    //
    var cabinetAdminPanel = $('<div>',{
      class: "cabinetAdminMainPart",
    });
    parentDiv.append(cabinetAdminPanel);

    var cabinetAdminPanelDiv = $('<div>',{
      class: "cabinetAdminPanelDiv",
    });
    cabinetAdminPanel.append(cabinetAdminPanelDiv);


    // var cabinetAdminPanelSelectionAside = $('<aside>',{
    //   class: "cabinetAdminPanelSelectionAside",
    // });
    // cabinetAdminPanelDiv.append(cabinetAdminPanelSelectionAside);

    // initializeFilterBlock();
    // initializePaginatorBlock();
    // //createOrUpdateFilterBlock(cabinetMyTalentsPanelSelectionAside, myTalentsPanelHistoryObject.filterObject, myTalentsPanelHistoryObject.selectedFilterObject);
    // subscribeToSelectedFilterObjectChange(onMyTalentsPageSelectedFilterObjectChange);
    // subscribeToPaginatorBlockSelectedFilterObjectChange(onMyTalentsPageSelectedFilterObjectChange);


    var cabinetAdminPanelContentDiv = $('<div>',{
      class: "cabinetAdminPanelContentDiv",
    });
    cabinetAdminPanelDiv.append(cabinetAdminPanelContentDiv);

    // var myTalentsFoundResultText = "";
    // if (myTalentsPanelHistoryObject.foundResultsValue > 0) {
    //   myTalentsFoundResultText = "Found results: " + myTalentsPanelHistoryObject.foundResultsValue;
    // }
    // var cabinetMyTalentsFoundResultsDiv = $('<div>',{
    //   class: "cabinetMyTalentsFoundResultsDiv",
    //   text: myTalentsFoundResultText,
    // });
    // cabinetMyTalentsPanelContentDiv.append(cabinetMyTalentsFoundResultsDiv);

    var cabinetAdminPanelCandidatesDiv = $('<div>',{
      class: "cabinetAdminPanelCandidatesDiv",
    });
    cabinetAdminPanelContentDiv.append(cabinetAdminPanelCandidatesDiv);

    // getUserStarredCandidates(myTalentsPanelHistoryObject, myTalentsCallBackUpdateFilterObjectOk, myTalentsCallBackUpdateFilterObjectError);
    // $(".cabinetMyTalentsPanelCandidatesDiv").empty();
    // $('.cabinetMyTalentsPanelCandidatesDiv').append(createLoaderAnimationDiv());

    getAdminData()
}

function getAdminData() {
  adminUserRegistrations = [];
  $(".cabinetAdminPanelCandidatesDiv").empty();
  $('.cabinetAdminPanelCandidatesDiv').append(createLoaderAnimationDiv());
  //getUserRegistrations(1, 1000, getUserRegistrationsReportDataTemplate());
  getUsersTableFromServer();
}

function getUsersTableFromServer() {
  $.ajax({
       type: 'GET',
       url: 'https://candyjar.io/api/getUsersTable',
       success: function(response) {
        $(".cabinetAdminPanelCandidatesDiv").empty();
        console.log(response);
        createUsersTable($('.cabinetAdminPanelCandidatesDiv'), response.usersTable);
        createUserRegistrationsReport($('.cabinetAdminPanelCandidatesDiv'), response.usersStatisticByMonths);
        createCandidatesCountriesReport($('.cabinetAdminPanelCandidatesDiv'), response.developersCountries);
       },
  });
}

// function getUserRegistrations(page, limit, userRegistrationsData) {
//   $.ajax({
//        type: 'GET',
//        url: 'https://candyjar.io/api/getUserRegistrations?page=' + page + '&limit=' + limit,
//        success: function(userRegistrations) {
//          for (var i = 0; i < userRegistrations.length; i++) {
//            var registrationDate = new Date(userRegistrations[i].registration_date);
//            var registrationYear = registrationDate.getFullYear();
//            if (registrationDate.getFullYear() == adminCurrentYearString) {
//              var month = registrationDate.getMonth();
//              for (var k = 0; k < userRegistrationsData.length; k++) {
//                if (userRegistrationsData[k].monthNumber == month) {
//                  userRegistrationsData[k].registrationsAmount++;
//                }
//              }
//            }
//          }
//          if (registrationYear == adminCurrentYearString) {
//            getUserRegistrations(page + 1, limit, userRegistrationsData)
//          } else {
//            getUserLogs(1, 1000, userRegistrationsData)
//          }
//        },
//   });
// }
//
// function getUserLogs(page, limit, userRegistrationsData) {
//   $.ajax({
//        type: 'GET',
//        url: 'https://candyjar.io/api/getUserLogs?page=' + page + '&limit=' + limit,
//        success: function(userLogs) {
//          // console.log(userLogs);
//          for (var i = 0; i < userLogs.length; i++) {
//            var userLog = userLogs[i];
//            var userLogDate = new Date(userLog.date);
//            var userLogDateYear = userLogDate.getFullYear();
//            if (userLogDateYear == adminCurrentYearString) {
//              var month = userLogDate.getMonth();
//              userRegistrationsData = analyzeUserIdsAuth(userRegistrationsData, userLog, month);
//              analyzeTotalCandidatesCountries(userLog);
//              analyzeTotalCandidatesSpecializations(userLog);
//              analyzeTotalCandidatesWebsites(userLog);
//              analyzeTotalUsersClicks(userLog);
//              analyzeUsersData(userLog);
//            }
//          }
//          if (userLogDateYear == adminCurrentYearString) {
//            getUserLogs(page + 1, limit, userRegistrationsData)
//          } else {
//            console.log(userRegistrationsData);
//            console.log(totalCandidatesCountries);
//            console.log(totalCandidatesSpecializations);
//            console.log(totalCandidatesWebsites);
//            console.log(totalUsersClicks);
//            console.log(usersData);
//            $(".cabinetAdminPanelCandidatesDiv").empty();
//            createUsersTable($('.cabinetAdminPanelCandidatesDiv'), usersData);
//            createUserRegistrationsReport($('.cabinetAdminPanelCandidatesDiv'), userRegistrationsData);
//            createCandidatesCountriesReport($('.cabinetAdminPanelCandidatesDiv'), totalCandidatesCountries);
//            createCandidatesSpecializationsReport($('.cabinetAdminPanelCandidatesDiv'), totalCandidatesSpecializations);
//            createCandidatesWebsitesReport($('.cabinetAdminPanelCandidatesDiv'), totalCandidatesWebsites);
//            createUserClicksReport($('.cabinetAdminPanelCandidatesDiv'), totalUsersClicks);
//          }
//        },
//   });
// }
//
// var usersData = [];
// function analyzeUsersData(userLog) {
//   var logUserId = userLog.user_id;
//   var logUserEmail = userLog.email;
//   var logUserName = userLog.name;
//   var logUserRegDate = userLog.registration_date;
//   var logUserEndDate = userLog.trial_end_date;
//   var logUserDate = userLog.date;
//
//   var isUserIdExist = false;
//   for (var index2 = 0; index2 < usersData.length; index2++) {
//     var userDataElement = usersData[index2];
//     if (userDataElement.user_id == logUserId) {
//       isUserIdExist = true;
//       analyzeUserDataElement(userDataElement, userLog);
//     }
//   }
//   if (!isUserIdExist) {
//     usersData.push(
//       {
//         'user_id': logUserId,
//         'email': logUserEmail,
//         'name': logUserName,
//         'registration_date': logUserRegDate.substring(0, 10),
//         'trial_end_date': logUserEndDate.substring(0, 10),
//         'last_activity': logUserDate,
//         'linkedin_views': 0,
//         'github_views': 0,
//         'moikrug_views': 0,
//         'xing_views': 0,
//         'candyjar_views': 0,
//         'socials_click': 0,
//         'email_click': 0,
//         'popup_click': 0,
//         'search_click': 0,
//         'pdf_click': 0,
//         'add_star': 0,
//         'add_description': 0,
//         'similar_click': 0,
//       }
//     );
//   }
// }
//
// function analyzeUserDataElement(userDataElement, userLog) {
//   if (userLog.request_name == 'searchbytag' && userLog.website_name == 'linkedin_profile'){userDataElement.linkedin_views++}
//   if (userLog.request_name == 'searchbytag' && userLog.website_name == 'github_profile'){userDataElement.github_views++}
//   if (userLog.request_name == 'searchbytag' && userLog.website_name == 'moikrug_profile'){userDataElement.moikrug_views++}
//   if (userLog.request_name == 'searchbytag' && userLog.website_name == 'xing_profile'){userDataElement.xing_views++}
//   if (userLog.request_name == 'searchbytag' && userLog.website_name == 'candyjar_profile'){userDataElement.candyjar_views++}
//
//   if (userLog.request_name == 'add_star'){userDataElement.add_star++}
//   if (userLog.request_name == 'add_description'){userDataElement.add_description++}
//   if (userLog.request_name == 'selection'){userDataElement.search_click++}
//   if (userLog.request_name == 'popup_click'){userDataElement.popup_click++}
//   if (userLog.request_name == 'pdf_click'){userDataElement.pdf_click++}
//   if (userLog.request_name == 'email_click'){userDataElement.email_click++}
//   if (userLog.request_name == 'socials_click'){userDataElement.socials_click++}
//   if (userLog.request_name == 'similar_click'){userDataElement.similar_click++}
//
//
//
// }
//
// var totalUsersClicks = [];
// function analyzeTotalUsersClicks(userLog) {
//
//   var clickedElement = '';
//   if (userLog.request_name == 'add_star') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'add_description') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'selection') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'popup_click') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'pdf_click') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'email_click') {
//     clickedElement = userLog.request_name;
//   }
//   if (userLog.request_name == 'socials_click') {
//     clickedElement = userLog.payloads.object_name;
//   }
//   if (userLog.request_name == 'similar_click') {
//     clickedElement = userLog.request_name;
//   }
//
//   if (clickedElement == '') {
//     return;
//   }
//
//
//   var isUsersClickedElementExist = false;
//   for (var index2 = 0; index2 < totalUsersClicks.length; index2++) {
//     var userClickElement = totalUsersClicks[index2];
//     if (userClickElement.clickedElement == clickedElement) {
//       isUsersClickedElementExist = true;
//       userClickElement.amount++;
//     }
//   }
//   if (!isUsersClickedElementExist) {
//     totalUsersClicks.push({"clickedElement":clickedElement, "amount": 1});
//   }
//   totalUsersClicks.sort(function(a, b) {return b.amount - a.amount;});
// }
//
// var totalCandidatesWebsites = [];
// function analyzeTotalCandidatesWebsites(userLog) {
//   if (userLog.request_name != "searchbytag") {
//     return;
//   }
//   var responseWebsite = userLog.website_name;
//   if (responseWebsite == '') {
//     return;
//   }
//   var isCandidatesWebsiteExist = false;
//   for (var index2 = 0; index2 < totalCandidatesWebsites.length; index2++) {
//     var candidateWebsiteElement = totalCandidatesWebsites[index2];
//     if (candidateWebsiteElement.website == responseWebsite) {
//       isCandidatesWebsiteExist = true;
//       candidateWebsiteElement.amount++;
//     }
//   }
//   if (!isCandidatesWebsiteExist) {
//     totalCandidatesWebsites.push({"website":responseWebsite, "amount": 1});
//   }
//   totalCandidatesWebsites.sort(function(a, b) {return b.amount - a.amount;});
// }
//
// var totalCandidatesSpecializations = [];
// function analyzeTotalCandidatesSpecializations(userLog) {
//   if (userLog.request_name != "searchbytag") {
//     return;
//   }
//   var responseSpecialization = '';
//   if (userLog.response && userLog.response.about && userLog.response.about.specialization ) {
//     responseSpecialization = userLog.response.about.specialization;
//   };
//   var responseLanguage = '';
//   if (userLog.response && userLog.response.about && userLog.response.about.language ) {
//     responseLanguage = userLog.response.about.language;
//   };
//   if (responseSpecialization == 'software-development' && responseLanguage != '') {
//     responseSpecialization = responseLanguage;
//   }
//   if (responseSpecialization == '') {
//     return;
//   }
//   var isCandidatesSpecializationExist = false;
//   for (var index2 = 0; index2 < totalCandidatesSpecializations.length; index2++) {
//     var candidateSpecializationElement = totalCandidatesSpecializations[index2];
//     if (candidateSpecializationElement.specialization == responseSpecialization) {
//       isCandidatesSpecializationExist = true;
//       candidateSpecializationElement.amount++;
//     }
//   }
//   if (!isCandidatesSpecializationExist) {
//     totalCandidatesSpecializations.push({"specialization":responseSpecialization, "amount": 1});
//   }
//   totalCandidatesSpecializations.sort(function(a, b) {return b.amount - a.amount;});
// }
//
// var totalCandidatesCountries = [];
// function analyzeTotalCandidatesCountries(userLog) {
//   if (userLog.request_name != "searchbytag") {
//     return;
//   }
//   var responseCountry = '';
//   if (userLog.response && userLog.response.about && userLog.response.about.country ) {
//     responseCountry = userLog.response.about.country;
//   };
//   if (responseCountry == '') {
//     return;
//   }
//   var isCandidatesCountryExist = false;
//   for (var index2 = 0; index2 < totalCandidatesCountries.length; index2++) {
//     var candidateCountryElement = totalCandidatesCountries[index2];
//     if (candidateCountryElement.country == responseCountry) {
//       isCandidatesCountryExist = true;
//       candidateCountryElement.amount++;
//     }
//   }
//   if (!isCandidatesCountryExist) {
//     totalCandidatesCountries.push({"country":responseCountry, "amount": 1});
//   }
//   totalCandidatesCountries.sort(function(a, b) {return b.amount - a.amount;});
// }
//
// function analyzeUserIdsAuth(userRegistrationsData, userLog, month) {
//   var userId = userLog.user_id;
//   for (var index = 0; index < userRegistrationsData.length; index++) {
//     var item = userRegistrationsData[index];
//     if (item.monthNumber == month) {
//       if (!item.userIdsAuth.includes(userId)) {
//         item.userIdsAuth.push(userId);
//       }
//     }
//   }
//   return userRegistrationsData;
// }
//
// function getUserRegistrationsReportDataTemplate() {
//   return [
//     {
//       "monthNumber": "0",
//       "monthName": "Jan",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "1",
//       "monthName": "Feb",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "2",
//       "monthName": "Mar",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "3",
//       "monthName": "Apr",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "4",
//       "monthName": "May",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "5",
//       "monthName": "Jun",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "6",
//       "monthName": "Jul",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "7",
//       "monthName": "Aug",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "8",
//       "monthName": "Sep",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "9",
//       "monthName": "Oct",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "10",
//       "monthName": "Nov",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//     {
//       "monthNumber": "11",
//       "monthName": "Dec",
//       "registrationsAmount": 0,
//       "userIdsAuth": [],
//     },
//   ];
// }
