function createCardAboutBlock(parentDiv, candidate) {
  var cardAboutBlock = $('<div>',{
    class: "cardAboutBlock",
    id: "cardAboutBlock" + candidate.login
  });
  parentDiv.append(cardAboutBlock);

  var cardAboutBlockName = $('<h6>',{
    class: "cardAboutBlockName",
    id : "cardAboutBlockName" + candidate.login,
    text: candidate.about.name,
  });
  cardAboutBlock.append(cardAboutBlockName);

  var cardAboutBlockMedia = $('<div>',{
    class: "cardAboutBlockMedia",
    id: "cardAboutBlockMedia" + candidate.login
  });
  cardAboutBlock.append(cardAboutBlockMedia);

  var cardAboutBlockMediaAvatar = $('<div>',{
    class: "cardAboutBlockMediaAvatar",
    id: "cardAboutBlockMediaAvatar" + candidate.login
  });
  cardAboutBlockMedia.append(cardAboutBlockMediaAvatar);

  var cardAboutBlockMediaAvatarImg = $('<img>',{
    class: "cardAboutBlockMediaAvatarImg",
    id: "cardAboutBlockMediaAvatarImg" + candidate.login,
    src: candidate.about.avatar_url
  });
  cardAboutBlockMediaAvatar.append(cardAboutBlockMediaAvatarImg);

  createCardRankingBlock(cardAboutBlockMediaAvatar, candidate);

  var cardAboutBlockNameLocationPosition = $('<div>',{
    class: "cardAboutBlockNameLocationPosition",
    id: "cardAboutBlockNameLocationPosition" + candidate.login,
  });
  cardAboutBlockMedia.append(cardAboutBlockNameLocationPosition);

  var cardAboutBlockLocation = $('<p>',{
    class: "cardAboutBlockLocation",
    id: "cardAboutBlockLocation" + candidate.login,
    text: candidate.about.location,
  });
  cardAboutBlockNameLocationPosition.append(cardAboutBlockLocation);

  var cardAboutBlockPosition = $('<p>',{
    class: "cardAboutBlockPosition",
    id: "cardAboutBlockPosition" + candidate.login,
    text: getPositionCompanyString(candidate.about.current_position, candidate.about.current_company),
  });
  cardAboutBlockNameLocationPosition.append(cardAboutBlockPosition);

}

function getPositionCompanyString(position, company) {
  var result = "";
  if (position === undefined || position.length == 0) {
    return result;
  }
  result = position;
  if (company === undefined || company.length == 0) {
    return result;
  }
  result += " (" + company + ")";

  return result;
}
