function createCardContactsBlock(parentDiv, candidate) {
  var cardContactsBlock = $('<div>',{
    class: "cardContactsBlock",
    id: "cardContactsBlock" + candidate.login,
  });
  parentDiv.append(cardContactsBlock);

  var cardContactsBlocksList = $('<ul>',{
    class: "cardContactsBlocksList",
    id: "cardContactsBlocksList" + candidate.login,
  });
  cardContactsBlock.append(cardContactsBlocksList);

  var emailsSet = getEmailsSetContactsBlock(candidate);
  for ( mail of emailsSet) {
    if (!isValidEmail(mail)) {
      continue;
    }
    createCardContactsEmailBlock(cardContactsBlocksList, mail, candidate);
  }

  createCardSocialsBlock(cardContactsBlock, candidate);


  //candyProfileContactsList.append(createCandyProfileContactsListItemAddEmailButtonLi(candyProfileContactsList, developerLogin));


}

function isCardContactsBlockExist(candidate) {
  if ($("#cardContactsBlock" + candidate.login).length) {
    return true;
  } else {
    return false;
  }
}

function createCardContactsEmailBlock(parentDiv, mail, candidate) {
  var cardContactsLi = $('<li>',{});
  parentDiv.append(cardContactsLi);


  var emailSvg = createEmailSvg();
  cardContactsLi.append(emailSvg);
  createCardContactsEmailButton(cardContactsLi, mail, candidate);



}

function createCardContactsEmailButton(parentDiv, mail, candidate) {

  if (!isSignInAndHaveDays()) {
    var newMail = ""
    var foundUmpersent = false;
    for (var i = 0; i < mail.length; i++) {
      if (mail[i] == "@") {
        foundUmpersent = true
      }
      if (foundUmpersent) {
        newMail += mail[i];
      } else {
        newMail += "*";
      }
    }
    mail = newMail;
  }

  var cardContactsEmailButton = $('<button>',{
    type: "button",
    class: "cardContactsEmailButton tooltipContactBlock",
    id: "cardContactsEmailButton" + candidate.login,
    text: mail,
    click: function () {
      if (isSignInAndHaveDays()) {
        $(".tooltiptextContactBlock").text("copied");
        const el = document.createElement('textarea');
        el.value = mail;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      } else {
        $(".tooltiptextContactBlock").text("please update your plan");
      }
      var requestString = getAddUserLogRequestString( 'email_click')
      chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
    },
    mouseleave: function () {
      if (isSignInAndHaveDays()) {
        $(".tooltiptextContactBlock").text("click to copy");
      } else {
        $(".tooltiptextContactBlock").text("need to update your plan");
      }
     },
  });
  parentDiv.append(cardContactsEmailButton);


  if (isSignInAndHaveDays()) {
    var tooltipText = $('<span>',{
      class: "tooltiptextContactBlock",
      text: "click to copy",
    });
    cardContactsEmailButton.append(tooltipText);
  } else {
    var tooltipText = $('<span>',{
      class: "tooltiptextContactBlock",
      text: "need to update your plan",
    });
    cardContactsEmailButton.append(tooltipText);
  }
}


function isValidEmail(mail) {

  if (mail.length == 0) {
    return false;
  }
  if (mail.includes("users.noreply.github.com")) {
    return false;
  }
  if (mail.includes(".local")) {
    return false;
  }
  if (!mail.includes("@")) {
    return false;
  }
  if (!mail.includes(".")) {
    return false;
  }

  return true;
}

function getEmailsSetContactsBlock(candidate) {
  const mails = new Set();
  if (candidate.about.email && candidate.about.email.length > 0) {
    if (isValidEmail(candidate.about.email)) {
      mails.add(candidate.about.email);
    }
  }
  if (candidate.about.emails && candidate.about.emails.length > 0) {
      for (index = 0; index < candidate.about.emails.length; index++) {
        if (isValidEmail(candidate.about.emails[index])) {
          mails.add(candidate.about.emails[index]);
        }
      }
  }
  if (candidate.user_emails && candidate.user_emails.length > 0) {
      for (index = 0; index < candidate.user_emails.length; index++) {
        var userEmail = candidate.user_emails[index];
        if (userEmail.user_email == authorizationInfo.email) {
          if (isValidEmail(userEmail.developer_email)) {
            mails.add(userEmail.developer_email);
          }
        }
      }
  }
  return mails;
}

function createEmailSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 512 512');
  svg.setAttribute('class', 'cardContactsEmailSvg');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.setAttribute('data-prefix', 'fal');
  svg.setAttribute('data-icon', 'envelope');
  svg.setAttribute('role', 'img');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 464 64 H 48 C 21.5 64 0 85.5 0 112 v 288 c 0 26.5 21.5 48 48 48 h 416 c 26.5 0 48 -21.5 48 -48 V 112 c 0 -26.5 -21.5 -48 -48 -48 Z M 48 96 h 416 c 8.8 0 16 7.2 16 16 v 41.4 c -21.9 18.5 -53.2 44 -150.6 121.3 c -16.9 13.4 -50.2 45.7 -73.4 45.3 c -23.2 0.4 -56.6 -31.9 -73.4 -45.3 C 85.2 197.4 53.9 171.9 32 153.4 V 112 c 0 -8.8 7.2 -16 16 -16 Z m 416 320 H 48 c -8.8 0 -16 -7.2 -16 -16 V 195 c 22.8 18.7 58.8 47.6 130.7 104.7 c 20.5 16.4 56.7 52.5 93.3 52.3 c 36.4 0.3 72.3 -35.5 93.3 -52.3 c 71.9 -57.1 107.9 -86 130.7 -104.7 v 205 c 0 8.8 -7.2 16 -16 16 Z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}
