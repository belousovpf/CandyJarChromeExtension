function createCardSocialsBlock(parentDiv, candidate) {
  var cardSocialsBlock = $('<div>',{
    class: "cardSocialsBlock",
    id: "cardSocialsBlock" + candidate.login
  });
  parentDiv.append(cardSocialsBlock);

  var cardContactsSocialsBlock = $('<div>',{
    class: "cardContactsSocialsBlock",
    id: "cardContactsSocialsBlock" + candidate.login,
  });
  cardSocialsBlock.append(visualizeIcons(cardContactsSocialsBlock, candidate.login, candidate.about, candidate.accounts));
}
