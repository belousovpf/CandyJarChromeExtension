function createCardButtonsMoveButtonTooltip(parentDiv, candidate) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 200,
    minHeight: 500,
    trigger: 'custom',
    position: 'bottom'
  });
}

function getCardButtonsMoveButtonTooltip(parentDiv, candidate) {
  var cardButtonMoveButtonTooltipDiv = $('<div/>', {
    class: 'cardButtonMoveButtonTooltipDiv',
  });

  var cardButtonMoveButtonTooltipDivCloseButton = $('<div>',{
    class: 'cardButtonMoveButtonTooltipDivCloseButton',
    text: '+',
    click: function() {
      parentDiv.tooltipster('hide');
    },
  });
  cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipDivCloseButton);

  var cardButtonMoveButtonTooltipLoaderDiv = $('<div/>', {
    class: 'cardButtonMoveButtonTooltipLoaderDiv',
  });

  var cardButtonMoveButtonTooltipNewVacancy = $('<button>',{
    class: 'cardButtonMoveButtonTooltipNewVacancy',
    text: 'Create Vacancy',
    click: function() {
       parentDiv.tooltipster('content', getCardButtonMoveButtonNewVacancyTooltipDiv(parentDiv, candidate));
    },
  });
  cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipNewVacancy);

  developerOutVacancies = getDeveloperOutVacancies(candidate);
  for (var k = 0; k < developerOutVacancies.length; k++) {
    var vacancy = developerOutVacancies[k];
    cardButtonMoveButtonTooltipVacancy = createCardButtonMoveButtonTooltipLoaderDivButton(parentDiv, cardButtonMoveButtonTooltipLoaderDiv, candidate, vacancy);
    cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipVacancy);
  }


  // var cardButtonMoveButtonTooltipHuntflow = $('<button>',{
  //   class: 'cardButtonMoveButtonTooltipHuntflow',
  //   text: 'Huntflow (soon)',
  // });
  // cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipHuntflow);

  friendworkToken = getFriendworkToken();
  if (currentPage === 'cabinet' && friendworkToken.length && isSignInAndHaveDays()) {
    var cardButtonMoveButtonTooltipFriendwork = $('<button>',{
      class: 'cardButtonMoveButtonTooltipFriendwork',
      text: 'Friendwork',
      click: function () {
        if ($(".friendworkButtonLoaderAnimationDiv").length) {
          return;
        }
        currentButton = $(this);
        $(this).append(createFriendworkButtonLoaderAnimationDiv());
        var requestString = getSearchByTagFullRequestString(candidate.login.toLowerCase(), false);
        requestString = encodeURI(requestString);
        $.get(requestString, function(candidate) {
          $(".friendworkButtonLoaderAnimationDiv").remove();
          friendworkCandidate = convertToFriendworkCandidate(candidate);
          currentButton.append(createFriendworkButtonLoaderAnimationDiv());
          moveToFriendWork(friendworkCandidate, friendworkToken, currentButton, parentDiv);
        });
      }
    });
    cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipFriendwork);
  }


   cardButtonMoveButtonTooltipDiv.append(cardButtonMoveButtonTooltipLoaderDiv);
  return cardButtonMoveButtonTooltipDiv;
}

function convertToFriendworkCandidate(candidate) {
  var friendWorkCandidate = {};
  if (candidate.about && candidate.about.name) {
    name = candidate.about.name;
    if (name.includes(' ')) {
      nameSirname = name.split(' ');
      friendWorkCandidate.FirstName = nameSirname[0];
      friendWorkCandidate.LastName = nameSirname[1];
    } else {
      friendWorkCandidate.FirstName = name;
    }
  }
  if (candidate.about.city) {
    friendWorkCandidate.City = candidate.about.city;
  } else if (candidate.about.country) {
    friendWorkCandidate.City = candidate.about.country;
  }
  friendWorkCandidate.ExternalLink = 'https://candyjar.io/p/' + candidate.login;
  friendWorkCandidate.Source = 'Другой источник';

  socialLinks = {};
  if (candidate.accounts.linkedinHTML) {
    socialLinks.LinkedIn = candidate.accounts.linkedinHTML;
  }
  if (candidate.accounts.githubHTML) {
    socialLinks.Github = candidate.accounts.githubHTML;
  }
  if (candidate.accounts.facebookHTML) {
    socialLinks.Facebook = candidate.accounts.facebookHTML;
  }
  if (candidate.accounts.vkHTML) {
    socialLinks.VK = candidate.accounts.vkHTML;
  }
  if (candidate.accounts.moiKrugHTML) {
    socialLinks.MoiKrug = candidate.accounts.moiKrugHTML;
  }
  friendWorkCandidate.SocialLinks = socialLinks;

  friendworkExperiences = [];
  friendworkEducations = [];
  for (index1 = 0; index1< candidate.work_experience.length; index1++) {
    element = candidate.work_experience[index1];
    if (element.type === "Work") {
      experience = {};
      experience.Company = element.company;
      experience.Position = element.position;
      experience.City = element.location;
      experience.FromYear = element.startYear;
      experience.ToYear = element.endYear;
      experience.Description = element.description;
      friendworkExperiences.push(experience)
    }
    if (element.type === "Education") {
      education = {};
      education.University = element.company;
      education.Faculty = element.position;
      education.GraduateYear = element.endYear;
      friendworkEducations.push(education)
    }
  }
  friendWorkCandidate.Experience = friendworkExperiences;
  friendWorkCandidate.Education = friendworkEducations;

  if (candidate.about && candidate.about.bio) {
    friendWorkCandidate.AboutMe = candidate.about.bio;
  }

  if (candidate.top_tags) {
    friendWorkCandidate.Skills = candidate.top_tags;
  }

  if (candidate.about && candidate.about.email) {
    friendWorkCandidate.Contacts = [{"E-mail":candidate.about.email}];
  }
  return friendWorkCandidate;
}

function moveToFriendWork(friendWorkCandidate, friendworkToken, friendworkButton, parentDiv) {
  $.ajax({
    type: "POST",
    headers: {'Authorization':'Bearer ' + friendworkToken},
    // url: 'http://test.api.rc4.friendwork.ru/Candidate/set',
    url: 'http://api.friend.work/Candidate/set',
    success: function(msg) {
      $(".friendworkButtonLoaderAnimationDiv").remove();
      friendworkButton.text("Friendwork (moved)");
      setTimeout(() => parentDiv.tooltipster('hide'), 2000);
    },
    data: JSON.stringify(friendWorkCandidate),
    contentType: 'application/json; charset=utf-8',
    dataType: 'json'
  }).done(function(msg) {
    $(".friendworkButtonLoaderAnimationDiv").remove();
  }).fail(function(xhr, status, error) {
    $(".friendworkButtonLoaderAnimationDiv").remove();
  });
}

function createFriendworkButtonLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "friendworkButtonLoaderAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function createCardButtonMoveButtonTooltipLoaderDivButton(parentDiv, tooltipLoaderDiv, candidate, vacancy) {
  var cardButtonMoveButtonTooltipVacancy = $('<button>',{
    class: 'cardButtonMoveButtonTooltipVacancy',
    text: vacancy.vacancyName,
    click: function() {
      if (currentPage == 'linkedin') {
        setCurrentCandidate(candidate);
      }
      tooltipLoaderDiv.append(createLoaderSmallAnimationDiv());
      var requestString = 'https://candyjar.io/api/moveDeveloperToMyAtsVacancy?vacancyId=' + vacancy.vacancyId + '&vacancyStepId=' + 1 + '&githubId=' + candidate.github_id;
      if (currentPage == 'cabinet') {
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {moveDeveloperToMyAtsVacancySuccess(response, candidate, parentDiv, tooltipLoaderDiv);},
             error: function(response) {moveDeveloperToMyAtsVacancyError(parentDiv, tooltipLoaderDiv);}
        });
      } else {
        chrome.runtime.sendMessage({type: "moveDeveloperToMyAtsVacancyRequest", request: requestString, candidate: candidate, parentDivId: parentDiv.attr('id'), tooltipLoaderDivId: tooltipLoaderDiv.attr('id')}, function(response) {});
      }
    }
  });
  return cardButtonMoveButtonTooltipVacancy;
}



function moveDeveloperToMyAtsVacancySuccess(response, candidate, parentDiv, tooltipLoaderDiv) {
  if (currentPage == 'linkedin') {
    candidate = getCurrentCandidate();
  }
  if (response && response.length) {
    for (var k = 0; k < response.length; k++) {
      if (response[k].type == 'vacancyCandidate' && response[k].githubId == candidate.github_id) {
        candidate.developerVacancies.push(response[k]);
      }
    }
    if (currentPage == 'linkedin') {
      setCurrentCandidate(candidate);
    }
    refreshCandidateVacanciesBlock(candidate);
    tooltipLoaderDiv.empty();
    parentDiv.tooltipster('hide');
  } else {
    tooltipLoaderDiv.empty();
    parentDiv.tooltipster('hide');
  }
}

function moveDeveloperToMyAtsVacancyError(parentDiv, tooltipLoaderDiv) {
  tooltipLoaderDiv.empty();
  parentDiv.tooltipster('hide');
}

function getDeveloperOutVacancies(candidate) {
  if (currentPage == 'linkedin') {
    candidate = getCurrentCandidate();
  }
  var result = [];
  developerVacancies = candidate.developerVacancies;
  for (var k = 0; k < developerVacancies.length; k++) {
    vacancy = developerVacancies[k];
    if (vacancy.type != 'vacancy') {
      continue;
    }
    var candidateInVacancy = false;
    for (var m = 0; m < developerVacancies.length; m++) {
      if (developerVacancies[m].type == 'vacancyCandidate' && developerVacancies[m].vacancyId == vacancy.vacancyId) {
        candidateInVacancy = true;
      }
    }
    if (!candidateInVacancy) {
      result.push(vacancy);
    }
  }
  return result;
}


function getCardButtonMoveButtonNewVacancyTooltipDiv(parentDiv, candidate) {
  var newVacancyTooltipDiv = $('<div/>', {
    class: 'newVacancyTooltipDiv'
  });

  var newVacancyTooltipDivCreateNewBlock = $('<div/>', {
    class: 'newVacancyTooltipDivCreateNewBlock',
    text: 'Create New'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivCreateNewBlock);

  var newVacancyTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyTooltipDivProjectNameBlock',
    type: 'text',
    maxLength: '25',
    placeholder: 'Enter Project Name',
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivProjectNameBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivFooterBlock);

  var newVacancyTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCancelButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCreateButton',
    text: 'Create',
    click: function () {
      vacancyName = newVacancyTooltipDivProjectNameBlock.val()
      if (vacancyName == '') {
        return;
      }
      vacancyName = encodeURI(vacancyName);
      newVacancyTooltipDivFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      var requestString = 'https://candyjar.io/api/createAndMoveDeveloperMyAtsVacancy?vacancyName=' + vacancyName + '&githubId=' + candidate.github_id;
      if (currentPage == 'cabinet') {
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {createAndMoveDeveloperMyAtsVacancySuccess(response, candidate, parentDiv, newVacancyTooltipDivFooterBlockLoaderDiv);},
             error: function(response) {createAndMoveDeveloperMyAtsVacancyError(parentDiv, newVacancyTooltipDivFooterBlockLoaderDiv);}
        });
      } else {
        chrome.runtime.sendMessage({type: "createAndMoveDeveloperMyAtsVacancyRequest", request: requestString, candidate: candidate, parentDivId: parentDiv.attr('id'), newVacancyTooltipDivFooterBlockLoaderDivId: newVacancyTooltipDivFooterBlockLoaderDiv.attr('id')}, function(response) {});
      }
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCreateButton);
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return newVacancyTooltipDiv;
}

function createAndMoveDeveloperMyAtsVacancySuccess(response, candidate, parentDiv, newVacancyTooltipDivFooterBlockLoaderDiv) {
  if (response && response.length) {
    Array.prototype.push.apply(candidate.developerVacancies, response);
    refreshCandidateVacanciesBlock(candidate);
    newVacancyTooltipDivFooterBlockLoaderDiv.empty();
    parentDiv.tooltipster('hide');

    if ($('#cabinetNavigationSearchId').length) {
      removeTextDecorationFromAllSearchPanelNavigationDivs();
      $('#cabinetNavigationSearchTextId').css("text-decoration","underline");
      removeMainPartDivs();
      createSearchPanel($('.cabinet-main-part'));
    }


  } else {
    newVacancyTooltipDivFooterBlockLoaderDiv.empty();
    parentDiv.tooltipster('hide');
  }
}

function createAndMoveDeveloperMyAtsVacancyError(parentDiv, newVacancyTooltipDivFooterBlockLoaderDiv) {
  newVacancyTooltipDivFooterBlockLoaderDiv.empty();
  parentDiv.tooltipster('hide');
}
