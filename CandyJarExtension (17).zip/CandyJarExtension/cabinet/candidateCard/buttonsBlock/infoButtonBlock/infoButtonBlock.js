function createCardInfoButtonBlock(parentDiv, candidate, selectedFilerObject, globalTags) {
  var cardInfoButtonBlock = $('<div>',{
    class: "cardInfoButtonBlock",
    id: "cardInfoButtonBlock" + candidate.login
  });
  parentDiv.append(cardInfoButtonBlock);

  createCardTagsBlock(cardInfoButtonBlock, candidate, selectedFilerObject, globalTags);
  createCardSocialsBlock(cardInfoButtonBlock, candidate);
  createCardCommentBlock(cardInfoButtonBlock, candidate);
}
