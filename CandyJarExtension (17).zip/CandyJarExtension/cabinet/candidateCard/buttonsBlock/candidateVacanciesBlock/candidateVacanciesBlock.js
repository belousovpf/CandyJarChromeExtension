function createCandidateVacanciesBlock(parentDiv, candidate) {

  var candidateVacanciesBlock = $('<div>',{
    class: "candidateVacanciesBlock",
    id: "candidateVacanciesBlock" + candidate.login
  });
  parentDiv.append(candidateVacanciesBlock);

  createCandidateVacanciesBlockVacancies(candidateVacanciesBlock, candidate);
}

function refreshCandidateVacanciesBlock(candidate) {
  parentDiv = $('#candidateVacanciesBlock' + candidate.login);
  parentDiv.empty();
  createCandidateVacanciesBlockVacancies(parentDiv, candidate);
}

function createCandidateVacanciesBlockVacancies(parentDiv, candidate) {
  vacancies = candidate.developerVacancies;
  if (!vacancies || !vacancies.length) {
    return;
  }
  for (var i = 0; i < vacancies.length; i++) {
    vacancy = vacancies[i];
    if (vacancy.type != 'vacancyCandidate' || vacancy.githubId != candidate.github_id) {
      continue;
    }
    candidateVacancyDiv = createCandidateVacancyDiv(candidate, vacancy, vacancies);
    candidateVacancyDiv.css('background-color',vacancy.vacancyColor);
    parentDiv.append(candidateVacancyDiv);
    createCardCandidateVacanciesTooltip(candidateVacancyDiv, candidate);

  }
}

function createCandidateVacancyDiv(candidate, vacancy, vacancies) {
  var candidateVacancyDiv = $('<div>',{
    class: "candidateVacancyDiv",
    click: function () {
      if ($(".downloadButtonLoaderAnimationDiv").length) {
        return;
      }
      $('.candidateVacancyDiv').tooltipster('hide');
      $(this).tooltipster('show');
      $(this).tooltipster('content', getCardButtonsVacancyButtonTooltip($(this), candidate, vacancy, vacancies));
    }
  });
  return candidateVacancyDiv;
}

function createCardCandidateVacanciesTooltip(parentDiv, candidate) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 200,
    minHeight: 500,
    trigger: 'custom',
    position: 'bottom'
  });
}

function getCardButtonsVacancyButtonTooltip(parentDiv, candidate, vacancy, vacancies) {
  var cardButtonsVacancyButtonTooltip = $('<div/>', {
    class: 'cardButtonsVacancyButtonTooltip',
  });

  var cardCandidateVacancyTooltipCloseButton = $('<div>',{
    class: 'cardCandidateVacancyTooltipCloseButton',
    text: '+',
    click: function() {
      parentDiv.tooltipster('hide');
    },
  });
  cardButtonsVacancyButtonTooltip.append(cardCandidateVacancyTooltipCloseButton);


  var cardCandidateVacancyTooltipVacancyName = $('<div>',{
    class: "cardCandidateVacancyTooltipVacancyName",
    text: vacancy.vacancyName,
  });
  cardButtonsVacancyButtonTooltip.append(cardCandidateVacancyTooltipVacancyName);

  var cardCandidateVacancyTooltipLoaderDiv = $('<div/>', {
    class: 'cardCandidateVacancyTooltipLoaderDiv',
  });
  cardCandidateVacancyTooltipVacancyName.append(cardCandidateVacancyTooltipLoaderDiv);

  var currentVacancySteps = getCurrentVacancySteps(vacancies, vacancy.vacancyId);
  currentVacancySteps.sort((a, b) => a.vacancyStepId - b.vacancyStepId);
  var candidateVacancyStep =  getCurrentDeveloperVacancyStep(vacancies, vacancy.vacancyId, candidate.github_id);
  if (candidateVacancyStep == '') {
      return cardButtonsVacancyButtonTooltip;
  }

  var cardVacancyStepsUl = $('<ul>',{
    class: "cardVacancyStepsUl",
  });
  cardButtonsVacancyButtonTooltip.append(cardVacancyStepsUl);

  for (var i = 0; i < currentVacancySteps.length; i++) {
    var vacancyStep = currentVacancySteps[i];
    if (vacancyStep.type != 'vacancyStep') {
      continue;
    }
    createCardVacancyStepsLi(cardVacancyStepsUl, candidate, vacancyStep, candidateVacancyStep, cardCandidateVacancyTooltipLoaderDiv, parentDiv);
    if (vacancyStep.vacancyStepId != currentVacancySteps[currentVacancySteps.length-1].vacancyStepId) {
    createCardVacancyDividerLi(cardVacancyStepsUl);
    }
  }

  var cardCandidateVacancyTooltipVacancyDeleteButton = $('<button>',{
    class: 'cardCandidateVacancyTooltipVacancyDeleteButton',
    text: 'Delete from vacancy',
    click: function() {
      cardCandidateVacancyTooltipLoaderDiv.append(createLoaderSmallAnimationDiv());
      var requestString = 'https://candyjar.io/api/deleteDeveloperFromMyAtsVacancy?vacancyId=' + vacancy.vacancyId + '&githubId=' + candidate.github_id;
      if (currentPage == 'cabinet') {
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {deleteDeveloperFromMyAtsVacancySuceess(response, candidate, vacancyStep, parentDiv, cardCandidateVacancyTooltipLoaderDiv);},
             error: function(response) {deleteDeveloperFromMyAtsVacancyError(parentDiv, cardCandidateVacancyTooltipLoaderDiv);}
        });
      } else {
        chrome.runtime.sendMessage({type: "deleteDeveloperFromMyAtsVacancyRequest", request: requestString, candidate: candidate, vacancyStep:vacancyStep, parentDivId: parentDiv.attr('id'), cardCandidateVacancyTooltipLoaderDivId: cardCandidateVacancyTooltipLoaderDiv.attr('id')}, function(response) {});
      }
    }
  });
  cardButtonsVacancyButtonTooltip.append(cardCandidateVacancyTooltipVacancyDeleteButton);

  return cardButtonsVacancyButtonTooltip;
}

function deleteDeveloperFromMyAtsVacancySuceess(response, candidate, vacancyStep, parentDiv, cardCandidateVacancyTooltipLoaderDiv) {
  if (response && response.length) {
    candidate = removeDeveloperFromDeveloperVacancies(candidate, vacancyStep.vacancyId);
    cardCandidateVacancyTooltipLoaderDiv.empty();
    parentDiv.tooltipster('hide');
    refreshCandidateVacanciesBlock(candidate);
    onCandidateVacancyStepChange(response);
  } else {
    cardCandidateVacancyTooltipLoaderDiv.empty();
    parentDiv.tooltipster('hide');
  }
}

function deleteDeveloperFromMyAtsVacancyError(parentDiv, cardCandidateVacancyTooltipLoaderDiv) {
  cardCandidateVacancyTooltipLoaderDiv.empty();
  parentDiv.tooltipster('hide');
}

function removeDeveloperFromDeveloperVacancies(candidate, vacancyId) {
  for (var k = 0; k < candidate.developerVacancies.length; k++) {
    developerStep = candidate.developerVacancies[k];
    if (developerStep.type == 'vacancyCandidate' && developerStep.vacancyId == vacancyId && developerStep.githubId == candidate.github_id) {
      candidate.developerVacancies.splice(k, 1);
      return candidate;
    }
  }
  return candidate;
}

function getCurrentDeveloperVacancyStep(vacancies, currentVacancyId, githubId) {
  var result = '';
  for (var i = 0; i < vacancies.length; i++) {
    vacancy = vacancies[i];
    if (vacancy.type == 'vacancyCandidate' && vacancy.vacancyId == currentVacancyId && vacancy.githubId == githubId) {
      return vacancy;
    }
  }
  return result;
}

function getCurrentVacancySteps(vacancies, currentVacancyId) {
  var result = [];
  for (var i = 0; i < vacancies.length; i++) {
    if (vacancies[i].vacancyId == currentVacancyId && vacancies[i].type == 'vacancyStep') {
      result.push(vacancies[i]);
    }
  }
  return result;
}

function createCardVacancyStepsLi(parentDiv, candidate, vacancyStep, candidateVacancyStep, loaderDiv, tooltipParentDiv) {
  var cardVacancyStepsLi = $('<li>',{
    class: "cardVacancyStepsLi",
  });
  parentDiv.append(cardVacancyStepsLi);

  var cardVacancyStepsLiCicleAndName = $('<span>',{
    class: "cardVacancyStepsLiCicleAndName",
    click: function() {
      if (vacancyStep.vacancyStepId == candidateVacancyStep.vacancyStepId) {
        return;
      }
      loaderDiv.append(createLoaderSmallAnimationDiv());
      var requestString = 'https://candyjar.io/api/moveDeveloperToMyAtsVacancyStep?vacancyId=' + vacancyStep.vacancyId + '&vacancyNewStepId=' + vacancyStep.vacancyStepId + '&githubId=' + candidate.github_id;
      if (currentPage == 'cabinet') {
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {moveDeveloperToMyAtsVacancyStepSuccess(response, candidate, vacancyStep, loaderDiv, tooltipParentDiv)},
             error: function(response) {moveDeveloperToMyAtsVacancyStepError(loaderDiv, tooltipParentDiv)}
        });
      } else {
        chrome.runtime.sendMessage({type: "moveDeveloperToMyAtsVacancyStepRequest", request: requestString, candidate: candidate, vacancyStep:vacancyStep, loaderDivId: loaderDiv.attr('id'), tooltipParentDivId: tooltipParentDiv.attr('id')}, function(response) {});
      }
    }
  });
  cardVacancyStepsLi.append(cardVacancyStepsLiCicleAndName);

  var cardVacancyStepsLiCicle = $('<div>',{
    class: "cardVacancyStepsLiCicle",
  });
  cardVacancyStepsLiCicleAndName.append(cardVacancyStepsLiCicle);

  var cardVacancyStepsLiCicleId = $('<span>',{
    class: "cardVacancyStepsLiCicleId",
    text: vacancyStep.vacancyStepId,
  });
  cardVacancyStepsLiCicle.append(cardVacancyStepsLiCicleId);

  var cardVacancyStepsLiCicleName = $('<span>',{
    class: "cardVacancyStepsLiCicleName",
    text: vacancyStep.vacancyStepName,
  });
  cardVacancyStepsLiCicleAndName.append(cardVacancyStepsLiCicleName);

  if (vacancyStep.vacancyStepId == candidateVacancyStep.vacancyStepId) {
    cardVacancyStepsLiCicle.css('background-color','#6492af');
    cardVacancyStepsLiCicleName.css('text-decoration','underline');
  }
}

function moveDeveloperToMyAtsVacancyStepSuccess(response, candidate, vacancyStep, loaderDiv, tooltipParentDiv) {
  if (response && response.length) {
    for (var k = 0; k < candidate.developerVacancies.length; k++) {
      developerStep = candidate.developerVacancies[k];
      if (developerStep.type == 'vacancyCandidate' && developerStep.vacancyId == vacancyStep.vacancyId && developerStep.githubId == candidate.github_id) {
        developerStep.vacancyStepId = vacancyStep.vacancyStepId;
        developerStep.vacancyStepName = vacancyStep.vacancyStepName;
      }
    }
    loaderDiv.empty();
    tooltipParentDiv.tooltipster('hide');
    refreshCandidateVacanciesBlock(candidate);
    onCandidateVacancyStepChange(response);
  } else {
    loaderDiv.empty();
    tooltipParentDiv.tooltipster('hide');
  }
}

function moveDeveloperToMyAtsVacancyStepError(loaderDiv, tooltipParentDiv) {
  loaderDiv.empty();
  tooltipParentDiv.tooltipster('hide');
}

function createCardVacancyDividerLi(parentDiv) {
  var cardVacancyDividerLi = $('<li>',{
    class: "cardVacancyDividerLi",
  });
  parentDiv.append(cardVacancyDividerLi);

  var cardVacancyDividerLiDiv = $('<div>',{
    class: "cardVacancyDividerLiDiv",
  });
  cardVacancyDividerLi.append(cardVacancyDividerLiDiv);


}
