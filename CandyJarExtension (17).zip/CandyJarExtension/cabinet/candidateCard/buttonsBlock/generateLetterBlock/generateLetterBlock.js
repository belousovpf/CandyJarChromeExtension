function createCardGenerateLetterBlock(parentDiv, candidate, generateLetterResponse) {
  var cardGenerateLetterBlock = $('<div>',{
    class: "cardGenerateLetterBlock",
    id: "cardGenerateLetterBlock" + candidate.login,
  });
  parentDiv.append(cardGenerateLetterBlock);

  letterText = "no data...";
  if (generateLetterResponse.letter) {
    letterText = generateLetterResponse.letter;
  }
  createCardFirstLetterTextDiv(cardGenerateLetterBlock, candidate, letterText);
  createCardLetterSettingsButton(cardGenerateLetterBlock, candidate, letterText);

}

function createCardFirstLetterTextDiv(parentDiv, candidate, letterText) {
  var cardFirstLetterTextDiv = $('<button>',{
    type: "button",
    class: "cardFirstLetterTextDiv tooltipGenerateText",
    id: "cardFirstLetterTextDiv" + candidate.login,
    text: letterText,
    click: function () {
      $("#tooltiptextGenerateText" + candidate.login).text("copied");
      const el = document.createElement('textarea');
      el.value = letterText;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      // var requestString = getAddUserLogRequestString('popup_profile', 'email_click')
      // chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
    },
    mouseleave: function () {
        $("#tooltiptextGenerateText" + candidate.login).text("click to copy");
    },
   }).css('position', "relative");
   parentDiv.append(cardFirstLetterTextDiv);

   var cardLetterTooltipText = $('<span>',{
     class: "tooltiptextGenerateText",
     id: "tooltiptextGenerateText" + candidate.login,
     text: "click to copy",
   });
   cardFirstLetterTextDiv.append(cardLetterTooltipText);
}

function createCardLetterSettingsButton(parentDiv, candidate, letterText) {
  var cardLetterSettingsButton = $('<button>',{
    type: "button",
    class: "cardLetterSettingsButton",
    id: "cardLetterSettingsButton" + candidate.login,
    text: "letter settings",
    click: function () {
      if (authorizationInfo != 0) {
        createSettingsChangeDiv(parentDiv, candidate, letterText);
      }
    },
    mouseleave: function () {
    },
  });
  parentDiv.append(cardLetterSettingsButton);
}

function createSettingsChangeDiv(parentDiv, candidate, letterText) {
  parentDiv.empty();
  var cardSettingsChangeList = $('<ul>',{
    class: "cardSettingsChangeList",
  });
  parentDiv.append(cardSettingsChangeList);

  createSettingsChangeInputLi(cardSettingsChangeList, "My name:", authorizationInfo.name, "cardSettingsChangeUsernameInput" + candidate.login);
  createSettingsChangeInputLi(cardSettingsChangeList, "Company:", authorizationInfo.company, "cardSettingsChangeCompanyInput" + candidate.login);
  createSettingsChangeGenderLi(cardSettingsChangeList, candidate, authorizationInfo.gender);
  createSettingsChangeWorkTypeLi(cardSettingsChangeList, candidate, authorizationInfo.workType);
  createSettingsChangeLanguageLi(cardSettingsChangeList, candidate, authorizationInfo.letterLanguage);

  var cardSettingsChangeOkCancelDiv = $('<div>',{
    class: "cardSettingsChangeOkCancelDiv",
  });
  parentDiv.append(cardSettingsChangeOkCancelDiv);

  var cardSettingsChangeOkDiv = $('<div>',{
    class: "cardSettingsChangeOkDiv",
    id: "cardSettingsChangeOkDiv" + candidate.login,
    text: 'ok',
    click: function () {
      userName = $("#cardSettingsChangeUsernameInput" + candidate.login).val();
      userCompany = $("#cardSettingsChangeCompanyInput" + candidate.login).val();
      gender = $("#cardSettingsChangeGenderSelect" + candidate.login).val();
      workType = $("#cardSettingsChangeWorkTypeSelect" + candidate.login).val();
      letterLanguage = $("#cardSettingsChangeLanguageSelect" + candidate.login).val();
      var requestString = getUpdateUserInfoRequestString(userName, userCompany, gender, workType, letterLanguage);
      requestString = encodeURI(requestString);
      $(this).append(createDownloadButtonLoaderAnimationDiv());
      if (currentPage == 'cabinet') {
        $.ajax({
             type: 'GET',
             url: requestString,
             success: function(response) {updateUserInfoRequestSuccess(response, candidate, parentDiv, letterText) },
             error: function() {updateUserInfoRequestError(candidate, parentDiv, letterText)}
        });
      } else {
        chrome.runtime.sendMessage({type: "updateUserInfoRequest", request: requestString, candidate: candidate, parentDivId: parentDiv.attr('id'), letterText: letterText}, function(response) {});
      }
    },
  });
  cardSettingsChangeOkCancelDiv.append(cardSettingsChangeOkDiv);

  var cardSettingsChangeCancelDiv = $('<div>',{
    class: "cardSettingsChangeCancelDiv",
    id: "cardSettingsChangeCancelDiv" + candidate.login,
    text: 'cancel',
    click: function () {
      parentDiv.empty();
      createCardFirstLetterTextDiv(parentDiv, candidate, letterText);
      createCardLetterSettingsButton(parentDiv, candidate, letterText);
    },
  });
  cardSettingsChangeOkCancelDiv.append(cardSettingsChangeCancelDiv);
}


function updateUserInfoRequestSuccess(response, candidate, parentDiv, letterText) {
  authorizationInfo = response;
  parentDiv.empty();
  createCardFirstLetterTextDiv(parentDiv, candidate, letterText);
  createCardLetterSettingsButton(parentDiv, candidate, letterText);
}

function updateUserInfoRequestError(candidate, parentDiv, letterText) {
  parentDiv.empty();
  createCardFirstLetterTextDiv(parentDiv, candidate, letterText);
  createCardLetterSettingsButton(parentDiv, candidate, letterText);
}

function createSettingsChangeInputLi(parentDiv, labelText, inputText, inputId) {
  var cardSettingsChangeListUsernameLi = $('<li>',{
    class: "cardSettingsChangeListLi"
  });
  parentDiv.append(cardSettingsChangeListUsernameLi);

  var cardSettingsChangeUsernameLabel = $('<div>',{
    class: "cardSettingsChangeLabel",
    text: labelText
  });
  cardSettingsChangeListUsernameLi.append(cardSettingsChangeUsernameLabel);

  var cardSettingsChangeUsernameInput = $('<input>',{
    type: "text",
    class: "cardSettingsChangeInput",
    id: inputId,
    value: inputText
   });
  cardSettingsChangeListUsernameLi.append(cardSettingsChangeUsernameInput);
}

function createSettingsChangeGenderLi(parentDiv, candidate, selectedGender) {
  var cardSettingsChangeListLi = $('<li>',{
    class: "cardSettingsChangeListLi"
  });
  parentDiv.append(cardSettingsChangeListLi);

  var cardSettingsChangeLabel = $('<div>',{
    class: "cardSettingsChangeLabel",
    text: "Gender:"
  });
  cardSettingsChangeListLi.append(cardSettingsChangeLabel);

  var cardSettingsChangeSelect = $('<select>',{
    class: "cardSettingsChangeInput",
    id: "cardSettingsChangeGenderSelect" + candidate.login
   });
  cardSettingsChangeListLi.append(cardSettingsChangeSelect);

  if ("male" == selectedGender) {
    cardSettingsChangeSelect.append(new Option("male", "male", true, true))
    cardSettingsChangeSelect.append(new Option("female", "female"))
  } else {
    cardSettingsChangeSelect.append(new Option("male", "male"))
    cardSettingsChangeSelect.append(new Option("female", "female", true, true))
  }
}

function createSettingsChangeWorkTypeLi(parentDiv, candidate, selectedWorkType) {
  var cardSettingsChangeListLi = $('<li>',{
    class: "cardSettingsChangeListLi"
  });
  parentDiv.append(cardSettingsChangeListLi);

  var cardSettingsChangeLabel = $('<div>',{
    class: "cardSettingsChangeLabel",
    text: "Type:"
  });
  cardSettingsChangeListLi.append(cardSettingsChangeLabel);

  var cardSettingsChangeSelect = $('<select>',{
    class: "cardSettingsChangeInput",
    id: "cardSettingsChangeWorkTypeSelect" + candidate.login
   });
  cardSettingsChangeListLi.append(cardSettingsChangeSelect);

  if ("inhouse" == selectedWorkType) {
    cardSettingsChangeSelect.append(new Option("inhouse", "inhouse", true, true))
    cardSettingsChangeSelect.append(new Option("freelance", "freelance"))
  } else {
    cardSettingsChangeSelect.append(new Option("inhouse", "inhouse"))
    cardSettingsChangeSelect.append(new Option("freelance", "freelance", true, true))
  }
}

function createSettingsChangeLanguageLi(parentDiv, candidate, selectedLanguage) {
  var cardSettingsChangeListLi = $('<li>',{
    class: "cardSettingsChangeListLi"
  });
  parentDiv.append(cardSettingsChangeListLi);

  var cardSettingsChangeLabel = $('<div>',{
    class: "cardSettingsChangeLabel",
    text: "Language:"
  });
  cardSettingsChangeListLi.append(cardSettingsChangeLabel);

  var cardSettingsChangeSelect = $('<select>',{
    class: "cardSettingsChangeInput",
    id: "cardSettingsChangeLanguageSelect" + candidate.login
   });
  cardSettingsChangeListLi.append(cardSettingsChangeSelect);

  if ("ru" == selectedLanguage) {
    cardSettingsChangeSelect.append(new Option("ru", "ru", true, true))
    cardSettingsChangeSelect.append(new Option("en", "en"))
  } else {
    cardSettingsChangeSelect.append(new Option("ru", "ru"))
    cardSettingsChangeSelect.append(new Option("en", "en", true, true))
  }
}



function isCardGenerateLetterBlockExist(candidate) {
  if ($("#cardGenerateLetterBlock" + candidate.login).length) {
    return true;
  } else {
    return false;
  }
}
