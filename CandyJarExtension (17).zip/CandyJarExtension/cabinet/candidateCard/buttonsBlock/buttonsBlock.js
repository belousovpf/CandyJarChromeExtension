var currentCandidate = '';
function setCurrentCandidate(candidate) {
  currentCandidate = candidate;
}

function getCurrentCandidate() {
  return currentCandidate;
}

function createCardButtonsBlock(parentDiv, candidate, selectedFilerObject, globalTags) {

  if (candidate.login.includes('www.linkedin')) {
    return;
  }
  if (candidate.login.includes('?')) {
    return;
  }

  if (currentPage == 'linkedin') {
    setCurrentCandidate(candidate);
  }

  var cardButtonsBlock = $('<div>',{
    class: "cardButtonsBlock",
    id: "cardButtonsBlock" + candidate.login
  });
  parentDiv.append(cardButtonsBlock);

  var cardButtonsOpenButton = $('<div>',{
    class: "cardButtonsOpenButton",
    id: "cardButtonsOpenButton" + candidate.login,
    text: 'Open',
    click: function () {
      if (isSignInAndHaveDays()) {
        var win = window.open("https://candyjar.io/p/" + candidate.login, '_blank');
        if (win) {win.focus();}
      } else {
        $('.cardButtonsOpenButton').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', createNeedToUpgradeBlockDiv(cardButtonsOpenButton));
      }
    },
  });
  cardButtonsBlock.append(cardButtonsOpenButton);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(cardButtonsOpenButton);
  }
  createCardInfoButtonBlock($("#candidateCardTagsBlockDiv"+candidate.login), candidate, selectedFilerObject, globalTags);


  var emailsSet = getEmailsSetContactsBlock(candidate);
  var validEmailsSize = 0
  for ( mail of emailsSet) {
    if (isValidEmail(mail)) {
      validEmailsSize++;
    }
  }
  createCardButtonsContactsButton2(cardButtonsBlock, candidate, validEmailsSize, selectedFilerObject, globalTags);
  //createCardButtonsContactsButton(cardButtonsBlocksList, candidate, validEmailsSize, selectedFilerObject);


  var notesSize = 0;
  if (candidate.description && candidate.description.length) {
    notesSize = 1;
  }
   createCardButtonsDownloadButton2(cardButtonsBlock, candidate, 0);


  createCardButtonsGenerateLetterButton(cardButtonsBlock, candidate, selectedFilerObject, globalTags);


   createCardButtonsMoveButton(cardButtonsBlock, candidate);
   createCandidateVacanciesBlock(cardButtonsBlock, candidate);


}

function createCardButtonsContactsButton2(parentDiv, candidate, contactsSize, selectedFilerObject, globalTags) {
  var cardButtonsBlockContactsButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockContactsButton2",
    id: "cardButtonsBlockContactsButton" + candidate.login,
    text: "Contacts (" + contactsSize + ")",
    click: function () {
      if (isSignInAndHaveDays()) {
        removeTextDecorationFromAllButtons(candidate);
        if (isCardContactsBlockExist(candidate)) {
          $("#candidateCardTagsBlockDiv" + candidate.login).empty();
          $('#cardButtonsBlockContactsButton' + candidate.login).css("text-decoration","");
          createCardInfoButtonBlock($("#candidateCardTagsBlockDiv"+candidate.login), candidate, selectedFilerObject, globalTags);
        } else {
          $("#candidateCardTagsBlockDiv" + candidate.login).empty();
          $('#cardButtonsBlockContactsButton' + candidate.login).css("text-decoration","underline");
          createCardContactsBlock($("#candidateCardTagsBlockDiv" + candidate.login), candidate)
        }
      } else {
        $('.cardButtonsBlockContactsButton2').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', createNeedToUpgradeBlockDiv(cardButtonsBlockContactsButton));
      }
    },
    mouseleave: function () {
    },
  });
  parentDiv.append(cardButtonsBlockContactsButton);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(cardButtonsBlockContactsButton);
  }
}

function createCardButtonsGenerateLetterButton(parentDiv, candidate, selectedFilterObject, globalTags) {
  var cardButtonsBlockGenerateLetterButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockGenerateLetterButton",
    id: "cardButtonsBlockGenerateLetterButton" + candidate.login,
    text: "Generate ",
    click: function () {
        if (isSignInAndHaveDays()) {
          if ($(".downloadButtonLoaderAnimationDiv").length) {return;}
          removeTextDecorationFromAllButtons(candidate);
           if (isCardGenerateLetterBlockExist(candidate)) {
             $("#candidateCardTagsBlockDiv" + candidate.login).empty();
             $('#cardButtonsBlockGenerateLetterButton' + candidate.login).css("text-decoration","");
             createCardInfoButtonBlock($("#candidateCardTagsBlockDiv"+candidate.login), candidate, selectedFilterObject, globalTags);
           } else {
             $(this).append(createDownloadButtonLoaderAnimationDiv());
             var requestString = getGenerateLetterRequestString(candidate.login.toLowerCase());
             requestString = encodeURI(requestString);
             if (currentPage == 'cabinet') {
               $.ajax({
                    type: 'GET',
                    url: requestString,
                    success: function(response) {generateLetterRequestSuccess(response, candidate);},
                    error: function() {generateLetterRequestError(candidate)}
               });
             } else {
               chrome.runtime.sendMessage({type: "generateLetterRequest", request: requestString, candidate: candidate}, function(response) {});
             }

           }
        } else {
          $('.cardButtonsBlockGenerateLetterButton').tooltipster('hide');
          $(this).tooltipster('show');
          $(this).tooltipster('content', createNeedToUpgradeBlockDiv(cardButtonsBlockGenerateLetterButton));
        }
    },
    mouseleave: function () {
    },
  });
  parentDiv.append(cardButtonsBlockGenerateLetterButton);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(cardButtonsBlockGenerateLetterButton);
  }

    var emailSvg = createCardButtonsBlockContactsSvg();
    cardButtonsBlockGenerateLetterButton.append(emailSvg);
}

function generateLetterRequestSuccess(response, candidate) {
  $(".downloadButtonLoaderAnimationDiv").remove();
  $("#candidateCardTagsBlockDiv" + candidate.login).empty();
  $('#cardButtonsBlockGenerateLetterButton' + candidate.login).css("text-decoration","underline");
  createCardGenerateLetterBlock($("#candidateCardTagsBlockDiv" + candidate.login), candidate, response);
}

function generateLetterRequestError(candidate) {
  $(".downloadButtonLoaderAnimationDiv").remove();
  $("#candidateCardTagsBlockDiv" + candidate.login).empty();
  $('#cardButtonsBlockGenerateLetterButton' + candidate.login).css("text-decoration","underline");
  createCardGenerateLetterBlock($("#candidateCardTagsBlockDiv" + candidate.login), candidate, "");
}

function createCardButtonsMessagesButton(parentDiv, candidate, messagesSize) {
  var messagesButtonLi = $('<li>',{});
  parentDiv.append(messagesButtonLi);
  messagesButtonLi.fadeTo('fast',.5);

  var emailSvg = createCardButtonsBlockContactsSvg();
  messagesButtonLi.append(emailSvg);

  var cardButtonsBlockMessagesButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockMessagesButton",
    id: "cardButtonsBlockMessagesButton" + candidate.login,
    text: messagesSize + "  Messages",
    click: function () {
      // removeTextDecorationFromAllButtons(candidate)
      // $('#cardButtonsBlockMessagesButton' + candidate.login).css("text-decoration","underline");
      // $("#candidateCardTagsBlockDiv" + candidate.login).empty();
    },
    mouseleave: function () {
    },
  });
  messagesButtonLi.append(cardButtonsBlockMessagesButton);
}

function createCardButtonsViewsButton(parentDiv, candidate, viewsSize) {
  var viewsButtonLi = $('<li>',{});
  parentDiv.append(viewsButtonLi);
  viewsButtonLi.fadeTo('fast',.5);

  var emailSvg = createCardButtonsBlockViewsSvg();
  viewsButtonLi.append(emailSvg);

  var cardButtonsBlockViewsButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockViewsButton",
    id: "cardButtonsBlockViewsButton" + candidate.login,
    text: viewsSize + "  Views",
    click: function () {
      // removeTextDecorationFromAllButtons(candidate)
      // $('#cardButtonsBlockViewsButton' + candidate.login).css("text-decoration","underline");
      // $("#candidateCardTagsBlockDiv" + candidate.login).empty();
    },
    mouseleave: function () {
    },
  });
  viewsButtonLi.append(cardButtonsBlockViewsButton);
}

function createCardButtonsATSButton(parentDiv, candidate, atsSize) {
  var atsButtonLi = $('<li>',{});
  parentDiv.append(atsButtonLi);
  atsButtonLi.fadeTo('fast',.5);

  var emailSvg = createCardButtonsBlockViewsSvg();
  atsButtonLi.append(emailSvg);

  var cardButtonsBlockAtsButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockAtsButton",
    id: "cardButtonsBlockAtsButton" + candidate.login,
    text: atsSize + "  ATS",
    click: function () {
      // removeTextDecorationFromAllButtons(candidate)
      // $('#cardButtonsBlockAtsButton' + candidate.login).css("text-decoration","underline");
      // $("#candidateCardTagsBlockDiv" + candidate.login).empty();
    },
    mouseleave: function () {
    },
  });
  atsButtonLi.append(cardButtonsBlockAtsButton);
}

function createCardButtonsDownloadButton2(parentDiv, candidate, downloadSize) {

  var cardButtonsBlockDownloadButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockDownloadButton2",
    id: "cardButtonsBlockDownloadButton" + candidate.login,
    text: "Download",
    click: function () {
      if (isSignInAndHaveDays()) {
        if ($(".downloadButtonLoaderAnimationDiv").length) {
          return;
        }
        $(this).append(createDownloadButtonLoaderAnimationDiv());
        var requestString = getSearchByTagFullRequestString(candidate.login.toLowerCase(), false);
        requestString = encodeURI(requestString);
        $.get(requestString, function(candidate) {
          $(".downloadButtonLoaderAnimationDiv").remove();
          createPDF(candidate);
        });
        requestString = getAddUserLogRequestString( 'pdf_click')
        $.get(requestString, function(data) {});
      } else {
        $('.cardButtonsBlockDownloadButton2').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', createNeedToUpgradeBlockDiv(cardButtonsBlockDownloadButton));
      }
    },
    mouseleave: function () {
    },
  });
  parentDiv.append(cardButtonsBlockDownloadButton);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(cardButtonsBlockDownloadButton);
  }
}

function createCardButtonsMoveButton(parentDiv, candidate) {

  var cardButtonsBlockMoveButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockMoveButton",
    id: "cardButtonsBlockMoveButton" + candidate.login,
    text: "Move To",
    click: function () {
      if ($(".downloadButtonLoaderAnimationDiv").length) {
        return;
      }
      $('.cardButtonsBlockMoveButton').tooltipster('hide');
      $(this).tooltipster('show');
      $(this).tooltipster('content', getCardButtonsMoveButtonTooltip($(this), candidate));
    }
  });
  parentDiv.append(cardButtonsBlockMoveButton);
  createCardButtonsMoveButtonTooltip(cardButtonsBlockMoveButton, candidate);
}

function createCardButtonsDownloadButton(parentDiv, candidate, downloadSize) {
  var downloadButtonLi = $('<li>',{});
  parentDiv.append(downloadButtonLi);

  var emailSvg = createCardButtonsBlockDownloadSvg();
  downloadButtonLi.append(emailSvg);

  var cardButtonsBlockDownloadButton = $('<button>',{
    type: "button",
    class: "cardButtonsBlockDownloadButton",
    id: "cardButtonsBlockDownloadButton" + candidate.login,
    text: "Download",
    click: function () {
      if ($(".downloadButtonLoaderAnimationDiv").length) {
        return;
      }
      downloadButtonLi.append(createDownloadButtonLoaderAnimationDiv());
      // removeTextDecorationFromAllButtons(candidate)
      // $('#cardButtonsBlockDownloadButton' + candidate.login).css("text-decoration","underline");
      // $("#candidateCardTagsBlockDiv" + candidate.login).empty();
      var requestString = getSearchByTagFullRequestString(candidate.login.toLowerCase(), false);
      requestString = encodeURI(requestString);
      $.get(requestString, function(candidate) {
        $(".downloadButtonLoaderAnimationDiv").remove();
        createPDF(candidate);
      });
      requestString = getAddUserLogRequestString( 'pdf_click')
      $.get(requestString, function(data) {});
    },
    mouseleave: function () {
    },
  });
  downloadButtonLi.append(cardButtonsBlockDownloadButton);
}

function createDownloadButtonLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "downloadButtonLoaderAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}


function removeTextDecorationFromAllButtons(candidate) {
  $('#cardButtonsBlockInfoButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockAtsButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockContactsButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockNotesButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockViewsButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockMessagesButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockDownloadButton' + candidate.login).css("text-decoration","");
  $('#cardButtonsBlockGenerateLetterButton' + candidate.login).css("text-decoration","");
}

function createCardButtonsBlockViewsSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'cardNotesSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M288 288a64 64 0 0 0 0-128c-1 0-1.88.24-2.85.29a47.5 47.5 0 0 1-60.86 60.86c0 1-.29 1.88-.29 2.85a64 64 0 0 0 64 64zm284.52-46.6C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 96a128 128 0 1 1-128 128A128.14 128.14 0 0 1 288 96zm0 320c-107.36 0-205.46-61.31-256-160a294.78 294.78 0 0 1 129.78-129.33C140.91 153.69 128 187.17 128 224a160 160 0 0 0 320 0c0-36.83-12.91-70.31-33.78-97.33A294.78 294.78 0 0 1 544 256c-50.53 98.69-148.64 160-256 160z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}

function createCardButtonsBlockNotesSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'cardNotesSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M448 348.106V80c0-26.51-21.49-48-48-48H48C21.49 32 0 53.49 0 80v351.988c0 26.51 21.49 48 48 48h268.118a48 48 0 0 0 33.941-14.059l83.882-83.882A48 48 0 0 0 448 348.106zm-120.569 95.196a15.89 15.89 0 0 1-7.431 4.195v-95.509h95.509a15.88 15.88 0 0 1-4.195 7.431l-83.883 83.883zM416 80v239.988H312c-13.255 0-24 10.745-24 24v104H48c-8.837 0-16-7.163-16-16V80c0-8.837 7.163-16 16-16h352c8.837 0 16 7.163 16 16z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}

function createCardButtonsBlockContactsSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 512 512');
  svg.setAttribute('class', 'cardNotesSvg');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.setAttribute('data-prefix', 'fal');
  svg.setAttribute('data-icon', 'envelope');
  svg.setAttribute('role', 'img');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 464 64 H 48 C 21.5 64 0 85.5 0 112 v 288 c 0 26.5 21.5 48 48 48 h 416 c 26.5 0 48 -21.5 48 -48 V 112 c 0 -26.5 -21.5 -48 -48 -48 Z M 48 96 h 416 c 8.8 0 16 7.2 16 16 v 41.4 c -21.9 18.5 -53.2 44 -150.6 121.3 c -16.9 13.4 -50.2 45.7 -73.4 45.3 c -23.2 0.4 -56.6 -31.9 -73.4 -45.3 C 85.2 197.4 53.9 171.9 32 153.4 V 112 c 0 -8.8 7.2 -16 16 -16 Z m 416 320 H 48 c -8.8 0 -16 -7.2 -16 -16 V 195 c 22.8 18.7 58.8 47.6 130.7 104.7 c 20.5 16.4 56.7 52.5 93.3 52.3 c 36.4 0.3 72.3 -35.5 93.3 -52.3 c 71.9 -57.1 107.9 -86 130.7 -104.7 v 205 c 0 8.8 -7.2 16 -16 16 Z");
  path1.setAttributeNS(null, "fill", "#6d36ab");
  svg.appendChild(path1);

  return svg;
}

function createCardButtonsBlockInfoSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'cardNotesSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "m256 512c-44.112 0-80-35.888-80-80v-160c0-44.112 35.888-80 80-80s80 35.888 80 80v160c0 44.112-35.888 80-80 80zm0-288c-26.467 0-48 21.533-48 48v160c0 26.467 21.533 48 48 48 26.468 0 48-21.533 48-48v-160c0-26.467-21.532-48-48-48z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "m256 160c-44.112 0-80-35.888-80-80s35.888-80 80-80 80 35.888 80 80-35.888 80-80 80zm0-128c-26.467 0-48 21.533-48 48s21.533 48 48 48 48-21.533 48-48-21.533-48-48-48z");
  path2.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path2);

  return svg;
}

function createCardButtonsBlockDownloadSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'cardNotesSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 529.988281 214.855469 C 529.988281 214.101562 529.988281 213.351562 529.988281 212.601562 C 530.03125 118.699219 453.945312 42.539062 360.042969 42.496094 C 302.925781 42.46875 249.613281 71.121094 218.117188 118.769531 C 155.171875 97.757812 87.109375 131.75 66.097656 194.699219 C 62.015625 206.921875 59.929688 219.71875 59.914062 232.605469 C 59.914062 233.457031 59.914062 234.316406 59.914062 235.175781 C 17.144531 246.289062 -8.519531 289.964844 2.589844 332.734375 C 11.742188 367.964844 43.519531 392.578125 79.917969 392.632812 L 259.285156 392.632812 C 264.808594 392.632812 269.285156 388.152344 269.285156 382.628906 C 269.285156 377.105469 264.808594 372.628906 259.285156 372.628906 L 79.917969 372.628906 C 46.777344 372.429688 20.070312 345.40625 20.265625 312.265625 C 20.441406 282.550781 42.335938 257.441406 71.746094 253.21875 C 77.035156 252.507812 80.835938 247.765625 80.378906 242.449219 C 80.109375 239.226562 79.917969 235.917969 79.917969 232.605469 C 79.988281 177.296875 124.882812 132.519531 180.191406 132.589844 C 193.308594 132.605469 206.292969 135.199219 218.410156 140.222656 C 223 142.128906 228.296875 140.375 230.839844 136.101562 C 273.027344 64.789062 365.035156 41.179688 436.347656 83.367188 C 482.023438 110.390625 510.023438 159.53125 509.984375 212.601562 C 509.984375 215.914062 509.894531 219.125 509.625 222.34375 C 509.160156 227.726562 513.050781 232.503906 518.414062 233.136719 C 556.789062 237.882812 584.046875 272.839844 579.300781 311.214844 C 574.96875 346.226562 545.261719 372.542969 509.984375 372.628906 C 506.976562 372.632812 503.96875 372.457031 500.984375 372.097656 C 499.546875 371.921875 498.089844 372.105469 496.742188 372.628906 L 339.597656 372.628906 C 334.074219 372.628906 329.597656 377.105469 329.597656 382.628906 C 329.597656 388.152344 334.074219 392.632812 339.597656 392.632812 L 499.984375 392.632812 C 500.746094 392.628906 501.507812 392.523438 502.242188 392.320312 C 504.773438 392.53125 507.363281 392.632812 509.984375 392.632812 C 559.699219 392.632812 600 352.332031 600 302.617188 C 600 260.609375 570.945312 224.1875 529.988281 214.855469 Z M 529.988281 214.855469 ");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M 377.742188 455.570312 L 309.953125 523.363281 L 309.953125 242.609375 C 309.953125 237.085938 305.476562 232.605469 299.953125 232.605469 C 294.429688 232.605469 289.949219 237.085938 289.949219 242.609375 L 289.949219 523.363281 L 222.160156 455.570312 C 218.1875 451.734375 211.855469 451.84375 208.015625 455.816406 C 204.273438 459.691406 204.273438 465.835938 208.015625 469.714844 L 292.878906 554.578125 C 296.785156 558.480469 303.117188 558.480469 307.023438 554.578125 L 391.886719 469.714844 C 395.722656 465.742188 395.613281 459.410156 391.640625 455.570312 C 387.765625 451.828125 381.621094 451.828125 377.742188 455.570312 Z M 377.742188 455.570312 ");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path2);

  return svg;
}
