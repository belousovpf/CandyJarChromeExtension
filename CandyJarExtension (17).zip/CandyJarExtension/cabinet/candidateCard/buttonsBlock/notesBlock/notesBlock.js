function createCardNotesBlock(parentDiv, candidate) {
  var cardNotesBlock = $('<div>',{
    class: "cardNotesBlock",
    id: "cardNotesBlock" + candidate.login,
  });
  parentDiv.append(cardNotesBlock);

  var description = "";
  if (candidate.description && candidate.description.length) {
    description = candidate.description;
  }

  var cardNote = $('<div>',{
    class: "cardNote",
    id: "cardNote" + candidate.login,
    text: description,
  });
  cardNotesBlock.append(cardNote);

  getCardNotesAddNotesDivButton(cardNotesBlock, candidate, description);

}

function isCardNotesBlockExist(candidate) {
  if ($("#cardNotesBlock" + candidate.login).length) {
    return true;
  } else {
    return false;
  }
}

function getCardNotesAddNotesDivButton(parentDiv, candidate, existNotes) {
  var cardNotesAddNotesDiv = $('<li>',{
    class: "cardNotesAddNotesDiv",
    id: "cardNotesAddNotesDiv" + candidate.login,
  });
  parentDiv.append(cardNotesAddNotesDiv);

  var cardNotesAddNotesDivButton = $('<button>',{
    type: "button",
    class: "cardNotesAddNotesDivButton",
    text: "add note",
    click: function () {
      $("#cardNotesAddNotesDiv" + candidate.login).remove();
      parentDiv.append(getCardNotesInputNotesDiv(parentDiv, candidate, existNotes));
    }
   });
  cardNotesAddNotesDiv.append(cardNotesAddNotesDivButton);

}

function getCardNotesInputNotesDiv(parentDiv, candidate, existNotes) {
  var cardNotesBlockInputNotesDiv = $('<li>',{
    class: "cardNotesBlockInputNotesDiv",
    id: "cardNotesBlockInputNotesDiv" + candidate.login,
  });
  parentDiv.append(cardNotesBlockInputNotesDiv);

  var cardNotesBlockInputNotesDivInput = $('<textarea>',{
    rows: "5",
    class: "cardNotesBlockInputNotesDivInput",
    text: existNotes,
   });
  cardNotesBlockInputNotesDiv.append(cardNotesBlockInputNotesDivInput);


  var cardNotesBlockInputNotesDivOkButton = $('<button>',{
    type: "button",
    class: "cardNotesBlockInputNotesDivOkButton",
    text: "OK",
    click: function () {
       $("#cardNotesBlockInputNotesDiv" + candidate.login).remove();
       var value = cardNotesBlockInputNotesDivInput.val();
       if (value.length > 0) {
         existNotes = value;
         var noteElement = document.getElementById("cardNote" + candidate.login);
         noteElement.innerHTML = existNotes;
         var formData = new FormData();
         formData.append("login_id", candidate.github_id);
         formData.append("description", existNotes);

         var data = {
           login_id: candidate.github_id,
           description: existNotes
         };

         var body = 'login=' + encodeURIComponent(candidate.github_id) + '&description=' + encodeURIComponent(existNotes) + '&website_name=cabinet';
         candidate.description = existNotes;
         sendUserComment(body);
       }
       parentDiv.append(getCardNotesAddNotesDivButton(parentDiv, candidate, existNotes));
    }
   });
  cardNotesBlockInputNotesDiv.append(cardNotesBlockInputNotesDivOkButton);

}
