function createNeedToUpgradeBlockTooltip(parentDiv) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    autoClose: true,
    interactive: true,
    arrow: true,
    //theme: 'tooltipster-shadow',
    theme: 'tooltipster-punk',
    maxWidth: 100,
    // minHeight: 500,
    trigger: 'click',
    position: 'bottom'
  });
}

function createNeedToUpgradeBlockDiv(parentDiv) {
  var needToUpgradeTooltipDiv = $('<div/>', {
    class: 'needToUpgradeTooltipDiv'
  });

  // var needToUpgradeTooltipDivCreateNewBlock = $('<div/>', {
  //   class: 'needToUpgradeTooltipDivCreateNewBlock',
  //   text: 'Need to upgrade'
  // });
  // needToUpgradeTooltipDiv.append(needToUpgradeTooltipDivCreateNewBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'needToUpgradeTooltipDivFooterBlock'
  });
  needToUpgradeTooltipDiv.append(newVacancyTooltipDivFooterBlock);

  var needToUpgradeTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'needToUpgradeTooltipDivFooterBlockCancelButton',
    text: 'need to ',
    click: function () {
      //parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(needToUpgradeTooltipDivFooterBlockCancelButton);

  var needToUpgradeTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'needToUpgradeTooltipDivFooterBlockCreateButton',
    text: 'Upgrade',
    click: function () {
      var win = window.open("https://product.candyjar.io/search-engine-pricing", '_blank');
      if (win) {win.focus();}
    },
  });
  newVacancyTooltipDivFooterBlock.append(needToUpgradeTooltipDivFooterBlockCreateButton);


  return needToUpgradeTooltipDiv;
}
