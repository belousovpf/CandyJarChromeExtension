function createCardStarredBlock(parentDiv, candidate) {

  if (candidate.login.includes('www.linkedin')) {
    return;
  }

  var cardStarredBlock = $('<div>',{
    class: "cardStarredBlock",
    id: "cardStarredBlock" + candidate.login
  });
  parentDiv.append(cardStarredBlock);

  var cardStarredBlockSpan = $('<span>',{
    class: "cardStarredBlockSpan fa fa-star",
    id: "cardStarredBlockSpan" + candidate.login,
    click: function () {
      if (isSignInAndHaveDays()) {
        if ($(".addStarToDeveloperLoaderAnimationDiv").length) {
          return;
        }
        cardStarredBlock.append(createAddStarToDeveloperLoaderAnimationDiv());
        if($(this).css("color") == "rgb(221, 221, 221)") {
          if (currentPage == 'cabinet') {addStarToCandidate(candidate.github_id, true, starredBlockCallbackFunction,  'cabinet');}
          else {chrome.runtime.sendMessage({type: "addStarToCandidateRequest", developerId: candidate.github_id, isStarred: true, website_name:'linkedin'}, function(response) {});}
          $(this).css("color", "orange");
          candidate.is_starred = 1;
        } else {
          if (currentPage == 'cabinet') {addStarToCandidate(candidate.github_id, false, starredBlockCallbackFunction,  'cabinet');}
          else {chrome.runtime.sendMessage({type: "addStarToCandidateRequest", developerId: candidate.github_id, isStarred: false, website_name:'linkedin'}, function(response) {});}
          $(this).css("color", "rgb(221, 221, 221)");
          candidate.is_starred = 0;
        }
      } else {
        $('.cardStarredBlockSpan').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', createNeedToUpgradeBlockDiv(cardStarredBlockSpan));
      }
    }
  });
  cardStarredBlock.append(cardStarredBlockSpan);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(cardStarredBlockSpan);
  }

  if (candidate.is_starred && candidate.is_starred == 1) {
    $('#cardStarredBlockSpan' + candidate.login).css("color", "orange");
  }
}

function createAddStarToDeveloperLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "addStarToDeveloperLoaderAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function starredBlockCallbackFunction() {
  console.log('2');
    $(".addStarToDeveloperLoaderAnimationDiv").remove();
}
