function createCardRankingBlock(parentDiv, candidate) {
  var cardRankingBlock = $('<div>',{
    class: "cardRankingBlock",
    id: "cardRankingBlock" + candidate.login
  });
  parentDiv.append(cardRankingBlock);

  addCandyjarCardRankDiv(cardRankingBlock, candidate.login, candidate.tags_count, candidate.github_metrics);
}
