function createCandidateCard(parentElement, candidate, selectedFilerObject, globalTags) {

  var candidateCard = $('<div>',{
    class: "candidateCard",
    id: "candidateCard" + candidate.login
  });
  parentElement.append(candidateCard);


  var candidateCardAboutBlockDiv = $('<div>',{
    class: "candidateCardAboutBlockDiv",
    id: "candidateCardAboutBlockDiv" + candidate.login
  });
  candidateCard.append(candidateCardAboutBlockDiv);

  //createCardRankingBlock(candidateCardAboutBlockDiv, candidate);
  createCardLastViewBlock(candidateCardAboutBlockDiv, candidate);
  createCardAboutBlock(candidateCardAboutBlockDiv, candidate);
  createCorporateDescriptionsBlock(candidateCardAboutBlockDiv, candidate)


  var candidateCardTagsBlockDiv = $('<div>',{
    class: "candidateCardTagsBlockDiv",
    id: "candidateCardTagsBlockDiv" + candidate.login
  });
  candidateCard.append(candidateCardTagsBlockDiv);


  var candidateCardButtonsBlockDiv = $('<div>',{
    class: "candidateCardButtonsBlockDiv",
    id: "candidateCardButtonsBlockDiv" + candidate.login
  });
  candidateCard.append(candidateCardButtonsBlockDiv);

  createCardButtonsBlock(candidateCardButtonsBlockDiv, candidate, selectedFilerObject, globalTags);
  createCardStarredBlock(candidateCardButtonsBlockDiv, candidate);




  // createCardAboutSection(card, candidate);
  // createCardTagsSection(card, candidate)
  //
  //
  //
  // var cardButtons = $('<div>',{
  //   class: "cardButtons",
  //   text: "buttons",
  // });
  // card.append(cardButtons);
}

function getCandidate() {
  var candidate = new Object();
  candidate.login = "Tapac";

  var candidateAbout = new Object();
  candidateAbout.avatar_url = "https://avatars3.githubusercontent.com/u/194469?v=4";
  candidateAbout.email = "hello2@gmail.com";
  candidateAbout.emails = ["hello@gmail.com"];
  candidateAbout.phone = "";
  candidateAbout.skype = "";
  candidateAbout.name = "Marat Mingazov";
  candidateAbout.location = "Russia, Tatarstan";
  candidateAbout.current_position = "Software Engineer";
  candidateAbout.current_company = "JetBrains";


  candidate.about = candidateAbout;

  var candidateGithubMetrics = new Object();
  candidateGithubMetrics.total_github_activity = 100;
  candidateGithubMetrics.total_linkedin_activity = 100;
  candidateGithubMetrics.total_activity = 100;
  candidate.github_metrics = candidateGithubMetrics;

  var tagsCount1 = {name:"Kotlin", count:3, github_activity:100, type:"technology"};
  var tagsCount2 = {name:"Java", count:7, github_activity:10, type:"technology"};
  var tagsCount3 = {name:"Spring", count:4, github_activity:10, type:"technology"};
  var tagsCount = [tagsCount1, tagsCount2, tagsCount3];
  candidate.tags_count = tagsCount;


  candidate.top_tags = ["kotlin", "java", "spring", "hibernate", "mysql", "php", "symfony", "javascript", "jquery", "frontend", "software-developerment"];

  var candidateAccounts = new Object();
  candidateAccounts.linkedinHTML = "a";
  candidateAccounts.twitterHTML = "a";
  candidateAccounts.facebookHTML = "a";
  candidateAccounts.hhHTML = "a";
  candidateAccounts.stackoverflowHTML = "a";
  candidateAccounts.telegramHTML = "a";
  candidateAccounts.vkHTML = "a";
  candidateAccounts.githubHTML = "a";
  candidateAccounts.bitbucketHTML = "a";
  candidateAccounts.gitlabHTML = "a";
  candidateAccounts.moikrugHTML = "a";
  candidateAccounts.hackerrankHTML = "a";
  candidate.accounts = candidateAccounts;

  candidate.profileLastView = [
    {"email":"linsades@gmail.com","last_view":["2020-08-19 17:32:56","2020-08-19 17:32:49","2020-08-19 17:32:46","2020-08-19 17:31:23","2020-08-19 17:31:21"],"comments":"my comment about this developer"}
  ];

  candidate.user_emails = [
    {user_email:"linsades@gmail.com",developer_email:"developer1@mail.ru"},{user_email:"marat@gmail.com",developer_email:"developer2@mail.ru"}
  ];

  return candidate;
}
