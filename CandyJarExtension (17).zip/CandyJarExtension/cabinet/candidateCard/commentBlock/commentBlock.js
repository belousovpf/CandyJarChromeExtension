function createCardCommentBlock(parentDiv, candidate) {
  var cardCommentBlock = $('<div>',{
    class: "cardCommentBlock",
    id: "cardCommentBlock" + candidate.login,
  });
  parentDiv.append(cardCommentBlock);

  var description = "";
  if (candidate.description && candidate.description.length) {
    description = candidate.description;
  }

  var cardCommentTextArea = $('<textarea>',{
    rows: "1",
    class: "cardCommentTextArea",
    id: "cardCommentTextArea" + candidate.login,
    placeholder: 'my comment here...',
    text: description,
    focus: function () {
      $(this).attr('rows', 5);
    },
    blur: function () {
      var text = $(this).val();
      var data = {
        login_id: candidate.github_id,
        description: text
      };
      var body = 'login=' + encodeURIComponent(candidate.github_id) + '&description=' + encodeURIComponent(text) + '&website_name=cabinet';
      candidate.description = text;
      chrome.runtime.sendMessage({type: "sendUserComment", data: body}, function(response) {});
      //sendUserComment(body);
      $(this).attr('rows', 1);
    },
   });
  cardCommentBlock.append(cardCommentTextArea);
}
