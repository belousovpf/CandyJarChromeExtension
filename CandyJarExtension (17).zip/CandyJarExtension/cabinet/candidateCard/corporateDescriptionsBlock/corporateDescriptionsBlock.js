function createCorporateDescriptionsBlock(parentDiv, candidate) {
  var userEmail = authorizationInfo.email;
  if (candidate.corporateDescriptions && candidate.corporateDescriptions.length > 1) {
    candidate.corporateDescriptions.sort((a, b) => b.updated_at > a.updated_at? 1 : -1);
    for (var i = 0; i < candidate.corporateDescriptions.length; i++) {
      var corporateDescriptionItem = candidate.corporateDescriptions[i];

      if (userEmail == corporateDescriptionItem.user_email) {
        continue;
      }

      userLogin = corporateDescriptionItem.user_name;
      if (userLogin && userLogin.length) {
        userLogin = userLogin.split(' ')[0];
      } else {
        userLogin = '';
      }

      lastViewedData = corporateDescriptionItem.updated_at;
      if (lastViewedData && lastViewedData.length) {
        lastViewedData = lastViewedData.substring(0,10);
      } else {
        lastViewedData = '';
      }

      description = corporateDescriptionItem.description;
      if (!description || !description.length) {
        continue;
      }

      var corporateDescriptionBlock = $('<div>',{
        class: "corporateDescriptionBlock",
      });
      parentDiv.append(corporateDescriptionBlock);

      var corporateDescriptionBlockText = $('<p>',{
        class: "corporateDescriptionBlockText",
        text: description
      });
      corporateDescriptionBlock.append(corporateDescriptionBlockText);

      var corporateDescriptionBlockHeader = $('<div>',{
        class: "corporateDescriptionBlockHeader",
      });
      corporateDescriptionBlock.append(corporateDescriptionBlockHeader);

      var corporateDescriptionBlockUserName = $('<div>',{
        class: "corporateDescriptionBlockUserName",
        text: '',
      });
      corporateDescriptionBlockHeader.append(corporateDescriptionBlockUserName);

      var corporateDescriptionBlockUserDate = $('<div>',{
        class: "corporateDescriptionBlockUserDate",
        text: userLogin + ' (' + lastViewedData + ')'
      });
      corporateDescriptionBlockHeader.append(corporateDescriptionBlockUserDate);
    }
  }
}
