function createCardTagsBlock(parentDiv, candidate, selectedFilerObject, globalTags) {
  var cardTagsBlock = $('<div>',{
    class: "cardTagsBlock",
    id: "cardTagsBlock" + candidate.login
  });
  parentDiv.append(cardTagsBlock);

  for (var i = 0; i < candidate.top_tags.length; i++) {
    var currentTag = candidate.top_tags[i];
    var cardTagsBlockTag = $('<div>',{
      class: "cardTagsBlockTag" + " tooltip" + candidate.login + currentTag,
      id: "cardTagsBlockTag" + candidate.login + currentTag,
      text: currentTag,
    });
    if (!isSignInAndHaveDays() && i > 1) {
      cardTagsBlockTag.addClass('cardTagsBlockTagBlur');
    }
    cardTagsBlock.append(cardTagsBlockTag);


    if (selectedFilerObject && selectedFilerObject.skills && selectedFilerObject.skills.includes(currentTag)) {
      cardTagsBlockTag.css("background-color","#AA85D5");
      cardTagsBlockTag.css("color","#fff");
    }

    if (selectedFilerObject && selectedFilerObject.topics && selectedFilerObject.topics.includes(currentTag)) {
      cardTagsBlockTag.css("background-color","#AA85D5");
      cardTagsBlockTag.css("color","#fff");
    }

    if (selectedFilerObject && selectedFilerObject.booleanSearch) {
      for (var m = 0; m < selectedFilerObject.booleanSearch.length; m++) {
        var andElements = selectedFilerObject.booleanSearch[m];
        for (var n = 0; n < andElements.length; n++) {
          var andElement = andElements[n];
          var elements = andElement.split(" ");
          for (var k = 0; k < elements.length; k++) {
            var element = elements[k];
            if (element == currentTag) {
              cardTagsBlockTag.css("background-color","#AA85D5");
              cardTagsBlockTag.css("color","#fff");
            }
          }

        }
      }
    }

    if (currentTag == "hireable") {
      cardTagsBlockTag.css("background-color","#00bbda");
      cardTagsBlockTag.css("color","#fff");
    }

    description = "";
    link = "";
    if (globalTags && globalTags.length)
    for (var k = 0; k < globalTags.length; k++) {
      globalTag = globalTags[k];
      if (globalTag.id == currentTag) {
        description = globalTag.descriptionEn;
        link = globalTag.link;
      }
    }
    if (isSignInAndHaveDays()) {
      createTagTooltip(cardTagsBlockTag, candidate, currentTag, description, link);
    }

  }
}

function createTagTooltip(tagDiv, candidate, currentTag, description, link) {
  if (description.length && link.length) {
    var filterBlockCheckboxDitalizationDiv = createTagsBlockTooltipDiv(candidate.login + currentTag);
    tagDiv.append(filterBlockCheckboxDitalizationDiv);
    filterBlockCheckboxDitalizationDiv.append(createTooltipHTMLTip(currentTag, description, link));

    tagDiv.tooltipster({
      content: filterBlockCheckboxDitalizationDiv,
      animation: "swing",
      interactive: true,
      arrow: true,
      theme: 'tooltipster-shadow',
      maxWidth: 300,
    });
    filterBlockCheckboxDitalizationDiv.remove();
  }
}

function createTooltipHTMLTip(name, description, link) {
  var tooltipBlock = $('<div/>', {
    class: "tagsBlockTooltipHTML"
  });

  var tooltipBlockName = $('<a>',{
    class: "tooltipBlockName",
    target: "_blank",
    href: link,
    text: name,
  });
  tooltipBlock.append(tooltipBlockName);


  var tooltipBlockDescription = $('<div/>', {
    class: "tooltipBlockDescription",
    text: description
  });
  tooltipBlock.append(tooltipBlockDescription);

  return tooltipBlock;
}

function createTagsBlockTooltipDiv(divId) {
  var filterBlockCheckboxDitalizationDiv = $('<div/>', {
    class: "filterBlockCheckboxDitalizationDiv",
    id: 'filterBlockCheckboxDitalizationDiv' + divId,
  });
  return filterBlockCheckboxDitalizationDiv;
}
