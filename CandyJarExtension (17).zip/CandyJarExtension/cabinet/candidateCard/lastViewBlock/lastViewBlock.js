function createCardLastViewBlock(parentDiv, candidate) {
  if (candidate.updated_at && candidate.updated_at.length) {
    var lastViewedData = candidate.updated_at;
    var userLogin = 'Me';
    var userEmail = authorizationInfo.email;

    if (candidate.corporateDescriptions && candidate.corporateDescriptions.length > 1) {
      candidate.corporateDescriptions.sort((a, b) => b.updated_at > a.updated_at? 1 : -1);
      if (candidate.corporateDescriptions[0].user_email != userEmail) {
        userLogin = candidate.corporateDescriptions[0].user_name;
        lastViewedData = candidate.corporateDescriptions[0].updated_at;
        if (userLogin.length) {
          userLogin = userLogin.split(' ')[0];
        }
      }
    }

    var cardLastViewBlockText = $('<div>',{
      class: "cardLastViewBlockText",
      id: "cardLastViewBlockText" + candidate.login,
      text: userLogin + ' viewed: ',
    });
    parentDiv.append(cardLastViewBlockText);

    lastViewedData = lastViewedData.substring(0,10);
    var cardLastViewBlock = $('<div>',{
      class: "cardLastViewBlock",
      id: "cardLastViewBlock" + candidate.login,
      text: lastViewedData,
    });
    parentDiv.append(cardLastViewBlock);
    if (!isSignInAndHaveDays()) {
      cardLastViewBlock.addClass('cardLastViewBlockBlur');
    }
  }
}
