
  var searchPanelHistoryObject;

function initializeSearchPanelData() {
  searchPanelHistoryObject = initializeHistoryObject();
  getSearchPanelCountrySpecializationId(searchPanelHistoryObject, callBackUpdateFilterObjectOk, callBackUpdateFilterObjectError);
  getSearchPanelTags(searchPanelHistoryObject, callBackUpdateFilterObjectOk, callBackUpdateFilterObjectError);
  searchPanelHistoryObject.filterObject.topics = getFilterBlockTopics();
  searchPanelHistoryObject.filterObject.experiences = ['junior', 'middle', 'senior'];
}


function createSearchPanel(parentDiv) {

  $(".cabinet-main").css("background-color","#edf2f5");

  var searchPanel = $('<div>',{
    class: "cabinetSearchMainPart",
  });
  parentDiv.append(searchPanel);

  var cabinetSearchPanelDiv = $('<div>',{
    class: "cabinetSearchPanelDiv",
  });
  searchPanel.append(cabinetSearchPanelDiv);



  var searchPanelSelectionAside = $('<aside>',{
    class: "searchPanelSelectionAside",
  });
  cabinetSearchPanelDiv.append(searchPanelSelectionAside);

  initializeFilterBlock();
  initializePaginatorBlock();
  initializeSearchButtonBlock();
  createSearchButtonBlock(searchPanelSelectionAside, searchPanelHistoryObject.selectedFilterObject);
  createOrUpdateFilterBlock(searchPanelSelectionAside, searchPanelHistoryObject.filterObject, searchPanelHistoryObject.selectedFilterObject);
  createSearchButtonBlock(searchPanelSelectionAside, searchPanelHistoryObject.selectedFilterObject);
  //subscribeToSelectedFilterObjectChange(onSearchPageSelectedFilterObjectChange);
  subscribeToPaginatorBlockSelectedFilterObjectChange(onSearchPageSelectedFilterObjectChange);
  subscribeToSearchButtonBlockSelectedFilterObjectChange(onSearchPageSelectedFilterObjectChange);


  var searchPanelContentDiv = $('<div>',{
    class: "searchPanelContentDiv",
  });
  cabinetSearchPanelDiv.append(searchPanelContentDiv);

  text = "";
  if (searchPanelHistoryObject.foundResultsValue > 0) {
    text = "Found results: " + searchPanelHistoryObject.foundResultsValue;
  }
  var foundResultsDiv = $('<div>',{
    class: "foundResultsDiv",
    text: text,
  });
  searchPanelContentDiv.append(foundResultsDiv);

  var searchPanelCandidatesDiv = $('<div>',{
    class: "searchPanelCandidatesDiv",
  });
  searchPanelContentDiv.append(searchPanelCandidatesDiv);

  if (searchPanelHistoryObject.selectedCandidates.length) {
      $(".searchPanelCandidatesDiv").empty();
  } else {

    var searchPanelEmptyCandidatesDiv = $('<div>',{
      class: "searchPanelEmptyCandidatesDiv",
      text: "Please Select Country and Languages"
    });
    searchPanelCandidatesDiv.append(searchPanelEmptyCandidatesDiv);

  }

  if (searchPanelHistoryObject.selectedFilterObject) {
       refreshSearching(searchPanelHistoryObject.selectedFilterObject);
  }
  // addSelectedCandidatesToPanel(searchPanelCandidatesDiv, searchPanelHistoryObject.selectedCandidates, searchPanelHistoryObject.selectedFilterObject, searchPanelHistoryObject.filterObject.tags);
  //
  //
  // if (searchPanelHistoryObject.selectedCandidates.length) {
  //   createPaginatorBlock(searchPanelCandidatesDiv, searchPanelHistoryObject.selectedFilterObject, false);
  // }

}

function onSearchPageSelectedFilterObjectChange(selectedFilterObject) {
  var authorizedDays = 0;
  if (authorizationInfo && authorizationInfo.days) {
    authorizedDays = authorizationInfo.days
  }
  if (authorizedDays <= 0 && selectedFilterObject.page > 1) {
    $(".searchPanelCandidatesDiv").empty();
    createSearchPanelNeedSubscriptionDiv($(".searchPanelCandidatesDiv"));
    return;
  }

  var datasetIds = getDataSetIdFromCountrySpecializationId(selectedFilterObject, searchPanelHistoryObject.countrySpecializationId);
  selectedFilterObject.limit = calculateLimitSize(datasetIds.length);

  if (datasetIds.length) {
    if (!$('#FilterBlockFadeDiv').length) {
      $('#filterBlock').fadeTo('fast',.5);
      $('#filterBlock').append('<div id="FilterBlockFadeDiv" style="position: absolute;top:0;left:0;width: 100%;height:100%;z-index:2;opacity:0.4;filter: alpha(opacity = 50)"></div>');
    }
    if (!$('#SearchButtonBlockFadeDiv').length) {
      $('.searchButtonBlock').fadeTo('fast',.5);
      $('.searchButtonBlock').append('<div id="SearchButtonBlockFadeDiv" class="SearchButtonBlockFadeDiv" style="position: absolute;top:0;left:0;width: 100%;height:100%;z-index:2;opacity:0.4;filter: alpha(opacity = 50)"></div>');
    }
    $(".searchPanelCandidatesDiv").empty();
    $('.searchPanelCandidatesDiv').append(createLoaderAnimationDiv());
    var datasetId = datasetIds[0];
    candyMakeSelectionRequestRecursevly(0, datasetIds, selectedFilterObject)
  }
}

function candyMakeSelectionRequestRecursevly(index, datasetIds, selectedFilterObject) {
  if (index >= datasetIds.length) {
    return;
  }
  var datasetId = datasetIds[index];
  var filter = calculateFilter(selectedFilterObject);
  candyMakeSelectionRequest(datasetId, selectedFilterObject.limit, selectedFilterObject.page, filter, searchPanelSelectionRequestOk, searchPanelSelectionRequestFail, selectedFilterObject, selectedFilterObject.booleanSearch);
  index++;
  setTimeout(function() {
      candyMakeSelectionRequestRecursevly(index, datasetIds, selectedFilterObject);
  }, 500);
}

function calculateFilter(selectedFilterObject) {
  var filter = [];

  var includes = [];
  var excludes = [];
  var query = "";
  var addition = [];
  var dataExist = false;

  if (selectedFilterObject.skills.length) {
    for (var i = 0; i < selectedFilterObject.skills.length; i++) {
      var skill = selectedFilterObject.skills[i];
      if (!includes.includes(skill)) {
        includes.push(skill);
        dataExist = true;
      }
    }
  }

  if (selectedFilterObject.topics.length) {
    for (var i = 0; i < selectedFilterObject.topics.length; i++) {
      var topic = selectedFilterObject.topics[i];
      if (!includes.includes(topic)) {
        includes.push(topic);
        dataExist = true;
      }
    }
  }

  if (selectedFilterObject.experiences.length) {
    for (var i = 0; i < selectedFilterObject.experiences.length; i++) {
      var experience = selectedFilterObject.experiences[i];
      if (!includes.includes(experience)) {
        includes.push(experience);
        dataExist = true;
      }
    }
  }

  if (selectedFilterObject.regions.length) {
    for (var i = 0; i < selectedFilterObject.regions.length; i++) {
      if (selectedFilterObject.isRegionsExclude) {
        excludes.push(selectedFilterObject.regions[i]);
      } else {
        includes.push(selectedFilterObject.regions[i]);
      }
      dataExist = true;
    }
  }

  if (selectedFilterObject.companies.length) {
    for (var i = 0; i < selectedFilterObject.companies.length; i++) {
      if (selectedFilterObject.isCompaniesExclude) {
        try {
          window.btoa(selectedFilterObject.companies[i]);
          excludes.push(selectedFilterObject.companies[i]);
        }
        catch (e) {}
      } else {
        try {
          window.btoa(selectedFilterObject.companies[i]);
          includes.push(selectedFilterObject.companies[i]);
        }
        catch (e) {}
      }
      dataExist = true;
    }
  }

  if (selectedFilterObject.hireableOnly) {
    if (!includes.includes('hireable')) {
      includes.push('hireable');
      dataExist = true;
    }
  }

  if (selectedFilterObject.hideViewed) {
    if (!includes.includes('no_viewed')) {
      includes.push('no_viewed');
      dataExist = true;
    }
  }

  if (selectedFilterObject.emptyWork) {
    if (!includes.includes('empty_work')) {
      includes.push('empty_work');
      dataExist = true;
    }
  }

  if (selectedFilterObject.fullMatch) {
    if (!includes.includes('full_match')) {
      includes.push('full_match');
      dataExist = true;
    }
  }

  if (selectedFilterObject.hasEmail) {
    if (!includes.includes('has-email')) {
      includes.push('has-email');
      dataExist = true;
    }
  }

  filter.push(includes);
  filter.push(excludes);
  filter.push(query);
  filter.push(addition);

  if (!dataExist) {
    filter = [];
  }

  return filter;
}

function calculateLimitSize(datasetIdsSize) {
  if (datasetIdsSize <= 1) {
    return 20;
  } else if (datasetIdsSize == 2) {
    return 10;
  } else if (datasetIdsSize == 3) {
    return 6;
  } else if (datasetIdsSize == 4) {
    return 5;
  } else if (datasetIdsSize == 6) {
    return 3;
  } else {
    return 2;
  }
}

function callBackUpdateFilterObjectOk(response, historyObject) {
  createOrUpdateFilterBlock($(".searchPanelSelectionAside"), historyObject.filterObject, historyObject.selectedFilterObject);
}

function callBackUpdateFilterObjectError(response, historyObject) {
}





function getDataSetIdFromCountrySpecializationId(filterObject, countrySpecializationId) {
  var datasetIds = []
  for (var i = 0; i < filterObject.countries.length; i++) {
    var country = filterObject.countries[i];
    for (var k = 0; k < filterObject.languages.length; k++) {
      var language = filterObject.languages[k];
      var datasetId = getDatasetIdFromCountrySpecialization(country, language, countrySpecializationId);
      if (datasetId > -1) {
        datasetIds.push(datasetId);
      } else {
        console.log("wrong datasetId / " + country + " / " + language);
      }
    }
    for (var l = 0; l < filterObject.specializations.length; l++) {
      var specialization = filterObject.specializations[l];
      var datasetId = getDatasetIdFromCountrySpecialization(country, specialization, countrySpecializationId);
      if (datasetId > -1) {
        datasetIds.push(datasetId);
      } else {
        console.log("wrong datasetId / " + country + " / " + specialization);
      }
    }
  }
  return datasetIds;
}

function getDatasetIdFromCountrySpecialization(pCountry, pSpecialization, pCountrySpecializationId) {
  var result = -1;
  for (var i = 0; i < pCountrySpecializationId.length; i++) {
    var countrySpecializationElement = pCountrySpecializationId[i];
    var country = countrySpecializationElement.country;
    var specialization = countrySpecializationElement.position;
    var id = countrySpecializationElement.id;
    if (country == pCountry && specialization == pSpecialization) {
      return id;
    }
  }
  return result;
}


function searchPanelSelectionRequestOk(response, selectedFilterObject) {
  $('#FilterBlockFadeDiv').remove();
  $('#filterBlock').fadeTo('fast',1);
  $('.SearchButtonBlockFadeDiv').remove();
  $('.searchButtonBlock').fadeTo('fast',1);

  var candidatesSize = response[0];
  var newCandidates = response[1];

  if (searchPanelHistoryObject.selectedFilterObjectVersion != selectedFilterObject.version) {
    searchPanelHistoryObject.selectedFilterObjectVersion = selectedFilterObject.version;
    searchPanelHistoryObject.selectedCandidates = [];
    searchPanelHistoryObject.foundResultsValue = 0;
  }

  searchPanelHistoryObject.selectedFilterObject = selectedFilterObject;

  $(".searchPanelCandidatesDiv").empty();
  searchPanelHistoryObject.selectedCandidates = addToSelectedCandidates(newCandidates, searchPanelHistoryObject.selectedCandidates);
  addSelectedCandidatesToPanel($(".searchPanelCandidatesDiv"), searchPanelHistoryObject.selectedCandidates, searchPanelHistoryObject.selectedFilterObject, searchPanelHistoryObject.filterObject.tags);

  searchPanelHistoryObject.foundResultsValue = searchPanelHistoryObject.foundResultsValue + candidatesSize;
  $(".foundResultsDiv").text("Found results: " + searchPanelHistoryObject.foundResultsValue);




  var isLastPage = false;
  if (!searchPanelHistoryObject.selectedCandidates.length) {
    isLastPage = true;
  }
  createPaginatorBlock($(".searchPanelCandidatesDiv"), selectedFilterObject, isLastPage);


}



function searchPanelSelectionRequestFail(country, specialization, limit, page, filter, resultOkFunction, resultFailFunction, filterObject) {
  $('#FilterBlockFadeDiv').remove();
  $('#filterBlock').fadeTo('fast',1);
  $('.SearchButtonBlockFadeDiv').remove();
  $('.searchButtonBlock').fadeTo('fast',1);
  $(".searchPanelCandidatesDiv").empty();
  $(".foundResultsDiv").text('Something was wrong. Please check your authorization');
}
