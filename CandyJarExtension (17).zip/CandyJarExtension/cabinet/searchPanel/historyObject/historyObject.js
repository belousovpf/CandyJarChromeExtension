function initializeHistoryObject() {
  var historyObject = new Object();
  historyObject.filterObject = getFilterObjectTempalte();
  historyObject.selectedFilterObject = getFilterObjectTempalte();
  historyObject.selectedFilterObjectVersion = 0;
  historyObject.selectedCandidates = [];
  historyObject.allStarredCandidates = [];
  historyObject.foundResultsValue = 0;
  historyObject.countrySpecializationId = [];

  return historyObject;
}

function getUserStarredCandidates(historyObject, successCallback, errorCallback) {
  $.ajax({
       type: 'GET',
       url: 'https://candyjar.io/api/getUserStarredCandidates',
       success: function(response) {
         console.log(response);
         historyObject.allStarredCandidates = response;
         updateMyTalentsFilterObjectFromStarredCandidates(response, historyObject);
         successCallback(response, historyObject);
       },
       error: function(response) {errorCallback(response, historyObject);}
  });
}


function getSearchPanelCountrySpecializationId(historyObject, callbackOkFunction, callbackErrorFunction) {
  $.ajax({
       type: 'GET',
       url: "https://candyjar.io/api/selections",
       success: function(response) {
         historyObject.countrySpecializationId = response;
         historyObject = updateFilterObjectFromCountrySpecializationId(historyObject);
         getSearchPanelRegionsRecursevly(0, historyObject);
         callbackOkFunction(response, historyObject);
       },
       error: function(response) {
         callbackErrorFunction(response, historyObject);
       }
  });
}

function getSearchPanelTags(historyObject, callbackOkFunction, callbackErrorFunction) {
  $.ajax({
       type: 'GET',
       url: "https://candyjar.io/api/tags",
       success: function(response) {
        for (var i = 0; i < response.length; i++) {
          var tagElement = response[i];
          historyObject.filterObject.skills.push(tagElement.id);
          if (tagElement.descriptionEn.length) {
            historyObject.filterObject.tags.push(tagElement);
          }
        }
        callbackOkFunction(response, historyObject);
       },
       error: function(response) {
          callbackErrorFunction(response, historyObject);
       }
  });
}

function getSearchPanelRegionsRecursevly(index, historyObject) {
  if (!historyObject.filterObject.countries) {
    return;
  }
  if (index >= historyObject.filterObject.countries.length) {
    return;
  }
  var country = historyObject.filterObject.countries[index];
  getSearchPanelRegions(country, historyObject)

  index++;
  setTimeout(function() {
      getSearchPanelRegionsRecursevly(index, historyObject);
  }, 500);
}

function getSearchPanelRegions(country, historyObject) {
  $.ajax({
       type: 'GET',
       url: "https://candyjar.io/api/country_list/" + country,
       success: function(response) {
        var regions = [];
        for (var i = 0; i < response.countries.length; i++) {
          var regionElement = response.countries[i];
          var regionId = regionElement.id;
          var regionName = regionElement.region;

          var region = new Object();
          region.id = regionElement.id;
          region.name = regionElement.region + ", " + country;

          if (!isRegionExist(region, regions)) {
            regions.push(region);
          }
        }
        var countryRegionsElement = new Object();
        countryRegionsElement.country = country;
        countryRegionsElement.regions = regions;
        historyObject.filterObject.countryRegions.push(countryRegionsElement);
       },
       error: function(response) {

       }
  });
}

function isRegionExist(currentRegion, regions) {
  var result = false;
  for (var i = 0; i < regions.length; i++) {
    if (currentRegion.id == regions[i].id) {
      result = true;
    }
  }
  return result;
}

function updateMyTalentsFilterObjectFromStarredCandidates(candidates, historyObject) {
  filterObject = historyObject.filterObject;
   for (var i = 0; i < candidates.length; i++) {
     var candidate = candidates[i];
     if (!candidate.login) {continue;}
     var country = candidate.about.country;
     var specialization = candidate.about.specialization;
     var language = candidate.about.language;

    if (!filterObject.countries.includes(country)) {
      filterObject.countries.push(country);
    }
    if (specialization == 'software-development'
        || specialization == 'fullstack-developer'
        || specialization == 'frontend-developer'
        || specialization == 'web-developer'
      || specialization == 'nodejs-developer') {
      if (!filterObject.languages.includes(language) && language.length) {
        filterObject.languages.push(language);
      }
    } else {
      if (!filterObject.specializations.includes(specialization) && specialization.length) {
        filterObject.specializations.push(specialization);
      }
    }
   }
   return historyObject;
}

function updateFilterObjectFromCountrySpecializationId(historyObject) {
  filterObject = historyObject.filterObject;
  countrySpecializationId = historyObject.countrySpecializationId;
  for (var i = 0; i < countrySpecializationId.length; i++) {
    var countrySpecializationElement = countrySpecializationId[i];
    var country = countrySpecializationElement.country;
    var specialization = countrySpecializationElement.position;

    if (!filterObject.countries.includes(country)) {
      filterObject.countries.push(country);
    }
    if (isItLanguageName(specialization)) {
      if (!filterObject.languages.includes(specialization)) {
        filterObject.languages.push(specialization);
      }
    } else {
      if (!filterObject.specializations.includes(specialization)) {
        filterObject.specializations.push(specialization);
      }
    }
  }
  return historyObject;
}

function isItLanguageName(name) {
  name = name.toLowerCase();
  if (name.includes("java")) {
    return true;
  }
  if (name.includes("javascript")) {
    return true;
  }
  if (name.includes("android")) {
    return true;
  }
  if (name.includes("ios")) {
    return true;
  }
  if (name.includes("python")) {
    return true;
  }
  if (name.includes("php")) {
    return true;
  }
  if (name.includes("ruby")) {
    return true;
  }
  if (name.includes("c#")) {
    return true;
  }
  if (name.includes("c++")) {
    return true;
  }
  if (name.includes("go")) {
    return true;
  }
  if (name.includes("scala")) {
    return true;
  }
  if (name.includes("sharepoint developer")) {
    return true;
  }

  return false;
}
