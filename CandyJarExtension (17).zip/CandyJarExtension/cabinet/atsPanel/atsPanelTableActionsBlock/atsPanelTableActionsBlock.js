function createAtsPanelTableActionsBlock(parentDiv, vacancy) {
  var atsPanelTableActionsBlock = $('<div>',{
    class: "atsPanelTableActionsBlock",
  });
  parentDiv.append(atsPanelTableActionsBlock);

  var atsPanelTableActionsBlockButton = $('<button>',{
    class: 'atsPanelTableActionsBlockButton',
    id: 'atsPanelTableActionsBlockButton' + vacancy.vacancyId,
    text: '...',
    click: function() {
      $('.atsPanelTableActionsBlockButton').tooltipster('hide');
      $(this).tooltipster('show');
      $(this).tooltipster('content', getAtsPanelTableActionsButtonTooltipDiv(atsPanelTableActionsBlockButton, vacancy));
    },
  });
  atsPanelTableActionsBlock.append(atsPanelTableActionsBlockButton);

  createAtsPanelTableActionsBlockButtonTooltip(atsPanelTableActionsBlockButton, vacancy);
}

function createAtsPanelTableActionsBlockButtonTooltip(parentDiv, vacancy) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 200,
    minHeight: 500,
    trigger: 'custom',
    position: 'bottom'
  });
}



function getAtsPanelTableActionsButtonTooltipDiv(parentDiv, vacancy) {
  var atsPanelTableActionsButtonTooltipDiv = $('<div/>', {
    class: 'atsPanelTableActionsButtonTooltipDiv',
  });

  var atsPanelTableActionsVacancyCloseButton = $('<div>',{
    class: 'atsPanelTableActionsVacancyCloseButton',
    text: '+',
    click: function() {
      parentDiv.tooltipster('hide');
    },
  });
  atsPanelTableActionsButtonTooltipDiv.append(atsPanelTableActionsVacancyCloseButton);


  var atsPanelTableActionsVacancyRenameButton = $('<button>',{
    class: 'atsPanelTableActionsVacancyRenameButton',
    text: 'rename',
    click: function() {
      parentDiv.tooltipster('content', getAtsPanelVacancyRenameDiv(parentDiv, vacancy));
    },
  });
  atsPanelTableActionsButtonTooltipDiv.append(atsPanelTableActionsVacancyRenameButton);

  var atsPanelTableActionsVacancyRenameButton = $('<button>',{
    class: 'atsPanelTableActionsVacancyRenameButton',
    text: 'duplicate',
    click: function() {
       parentDiv.tooltipster('content', getAtsPanelVacancyDublicateDiv(parentDiv, vacancy));
    },
  });
  atsPanelTableActionsButtonTooltipDiv.append(atsPanelTableActionsVacancyRenameButton);

  var atsPanelTableActionsVacancyDeleteButton = $('<button>',{
    class: 'atsPanelTableActionsVacancyDeleteButton',
    text: 'delete',
    click: function() {
      parentDiv.tooltipster('content', getAtsPanelVacancyRemoveDiv(parentDiv, vacancy));
    },
  });
  atsPanelTableActionsButtonTooltipDiv.append(atsPanelTableActionsVacancyDeleteButton);

  return atsPanelTableActionsButtonTooltipDiv;
}

function getAtsPanelVacancyRenameDiv(parentDiv, vacancy) {
  var atsPanelVacancyRenameDiv = $('<div/>', {
    class: 'atsPanelVacancyRenameDiv'
  });

  var newVacancyTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyTooltipDivProjectNameBlock',
    type: 'text',
    value: vacancy.vacancyName,
    maxLength: '25',
    placeholder: 'Enter Project Name',
  });
  atsPanelVacancyRenameDiv.append(newVacancyTooltipDivProjectNameBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  atsPanelVacancyRenameDiv.append(newVacancyTooltipDivFooterBlock);

  var newVacancyTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCancelButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCreateButton',
    text: 'Rename',
    click: function () {

      vacancyName = newVacancyTooltipDivProjectNameBlock.val()
      vacancyNameInitial = newVacancyTooltipDivProjectNameBlock.val()
      if (vacancyName == '') {
        return;
      }

      vacancyName = encodeURI(vacancyName);
      vacancyName = vacancyName.replace(/#/g, "%23");
      vacancyName = vacancyName.replace(/\+/g, "%2B");
      newVacancyTooltipDivFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/updateMyAtsVacancy?vacancyId=' + vacancy.vacancyId + "&vacancyName=" + vacancyName,
           success: function(response) {
             $('#vacancyName' + vacancy.vacancyId).text(vacancyNameInitial);
             newVacancyTooltipDivFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
           },
           error: function(response) {parentDiv.tooltipster('hide');}
      });
    },

  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCreateButton);

  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return atsPanelVacancyRenameDiv;
}

function getAtsPanelVacancyDublicateDiv(parentDiv, vacancy) {
  var atsPanelVacancyRenameDiv = $('<div/>', {
    class: 'atsPanelVacancyRenameDiv'
  });

  var newVacancyTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyTooltipDivProjectNameBlock',
    type: 'text',
    value: vacancy.vacancyName,
    maxLength: '25',
    placeholder: 'Enter Project Name',
  });
  atsPanelVacancyRenameDiv.append(newVacancyTooltipDivProjectNameBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  atsPanelVacancyRenameDiv.append(newVacancyTooltipDivFooterBlock);

  var newVacancyTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCancelButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCreateButton',
    text: 'Duplicate',
    click: function () {

      vacancyName = newVacancyTooltipDivProjectNameBlock.val()
      vacancyNameInitial = newVacancyTooltipDivProjectNameBlock.val()
      if (vacancyName == '') {
        return;
      }

      vacancyName = encodeURI(vacancyName);
      newVacancyTooltipDivFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/duplicateMyAtsVacancy?baseVacancyId=' + vacancy.vacancyId + "&newVacancyName=" + vacancyName,
           success: function(response) {
              newVacancyTooltipDivFooterBlockLoaderDiv.empty();
              parentDiv.tooltipster('hide');
              clearCabinetAtsPanelDiv();
              createAtsPanelVacanciesView();
           },
           error: function(response) {
             parentDiv.tooltipster('hide');
           }
      });
    },

  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCreateButton);

  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return atsPanelVacancyRenameDiv;
}


function getAtsPanelVacancyRemoveDiv(parentDiv, vacancy) {
  var atsPanelVacancyRemoveDiv = $('<div/>', {
    class: 'atsPanelVacancyRemoveDiv'
  });

  var newVacancyTooltipDivCreateNewBlock = $('<div/>', {
    class: 'newVacancyTooltipDivCreateNewBlock',
    text: 'Are you sure?'
  });
  atsPanelVacancyRemoveDiv.append(newVacancyTooltipDivCreateNewBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  atsPanelVacancyRemoveDiv.append(newVacancyTooltipDivFooterBlock);

  var atsPanelVacancyRemoveNoButton = $('<button>',{
    class: 'atsPanelVacancyRemoveNoButton',
    text: 'No',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(atsPanelVacancyRemoveNoButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var atsPanelVacancyRemoveYesButton = $('<button>',{
    class: 'atsPanelVacancyRemoveYesButton',
    text: 'Yes, delete',
    click: function () {


      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/deleteMyAtsVacancy?vacancyId=' + vacancy.vacancyId,
           success: function(response) {
             newVacancyTooltipDivFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
             $('#atsTableBodyTr'+vacancy.vacancyId).remove();
           },
           error: function(response) {parentDiv.tooltipster('hide');}
      });

    },

  });
  newVacancyTooltipDivFooterBlock.append(atsPanelVacancyRemoveYesButton);
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return atsPanelVacancyRemoveDiv;
}
