function createAtsPanelNewVacancyBlock(parentDiv) {
  var atsPanelNewVacancyBlock = $('<div>',{
    class: "atsPanelNewVacancyBlock",
  });
  parentDiv.append(atsPanelNewVacancyBlock);

  var atsPanelNewVacancyButton = $('<button>',{
    class: 'atsPanelNewVacancyButton',
    text: 'New Vacancy',
    click: function () {},
  });
  atsPanelNewVacancyBlock.append(atsPanelNewVacancyButton);

  createAtsPanelNewVacancyButtonTooltip(atsPanelNewVacancyButton);
}

function createAtsPanelNewVacancyButtonTooltip(parentDiv) {
  newVacancyTooltipDiv = getAtsPanelNewVacancyButtonTooltipDiv(parentDiv);
  parentDiv.tooltipster({
    content: newVacancyTooltipDiv,
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 300,
    maxWidth: 500,
    trigger: 'click',
    position: 'right'
  });
}

function getAtsPanelNewVacancyButtonTooltipDiv(parentDiv) {
  var newVacancyTooltipDiv = $('<div/>', {
    class: 'newVacancyTooltipDiv'
  });

  var newVacancyTooltipDivCreateNewBlock = $('<div/>', {
    class: 'newVacancyTooltipDivCreateNewBlock',
    text: 'Create New'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivCreateNewBlock);

  var newVacancyTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyTooltipDivProjectNameBlock',
    type: 'text',
    maxLength: '25',
    placeholder: 'Enter Project Name',
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivProjectNameBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivFooterBlock);

  var newVacancyTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCancelButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCreateButton',
    text: 'Create',
    click: function () {
      vacancyName = newVacancyTooltipDivProjectNameBlock.val()
      if (vacancyName == '') {
        return;
      }
      vacancyName = encodeURI(vacancyName);
      vacancyName = vacancyName.replace(/#/g, "%23");
      vacancyName = vacancyName.replace(/\+/g, "%2B");
      newVacancyTooltipDivFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/createMyAtsVacancy?vacancyName=' + vacancyName,
           success: function(response) {
             generateAtsTableRow($('#atsTableBody'), response[0])
             newVacancyTooltipDivFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
           },
           error: function(response) {console.log('error');}
      });
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCreateButton);

  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return newVacancyTooltipDiv;
}
