function createAtsPanelFindBlock(parentDiv, vacancyRows) {
  var atsPanelFindBlockInputDiv = $('<div>',{
    class: "atsPanelFindBlockInputDiv",
  });
  parentDiv.append(atsPanelFindBlockInputDiv);


  var atsPanelFindBlockInputBox = $('<input/>', {
    class: 'atsPanelFindBlockInputBox',
    type: 'text',
    maxLength: '25',
    placeholder: 'Find Candidates',
    keyup: function () {
      value = $(this).val();
      $(".cabinetAtsPanelCandidatesDiv").empty();
      if (value == '') {
        return;
      }
      foundCandidates = findCandidates(vacancyRows, value);
      addSelectedCandidatesToPanel($(".cabinetAtsPanelCandidatesDiv"), foundCandidates, atsPanelHistoryObject.selectedFilterObject, atsPanelHistoryObject.filterObject.tags);
    }
  });
  atsPanelFindBlockInputDiv.append(atsPanelFindBlockInputBox);

}
