function createAtsPanelVacancyNewStepTooltip(parentDiv, vacancyId) {
  newVacancyTooltipDiv = getAtsPanelVacancyNewStepTooltipDiv(parentDiv, vacancyId);
  parentDiv.tooltipster({
    content: newVacancyTooltipDiv,
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 300,
    maxWidth: 500,
    trigger: 'click',
    position: 'top'
  });
}

function getAtsPanelVacancyNewStepTooltipDiv(parentDiv, vacancyId) {
  var newVacancyStepTooltipDiv = $('<div/>', {
    class: 'newVacancyStepTooltipDiv'
  });

  var newVacancyStepTooltipDivCreateNewBlock = $('<div/>', {
    class: 'newVacancyStepTooltipDivCreateNewBlock',
    text: 'Create New'
  });
  newVacancyStepTooltipDiv.append(newVacancyStepTooltipDivCreateNewBlock);

  var newVacancyStepTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyStepTooltipDivProjectNameBlock',
    type: 'text',
    maxLength: '20',
    placeholder: 'Enter Step Name',
  });
  newVacancyStepTooltipDiv.append(newVacancyStepTooltipDivProjectNameBlock);

  var newVacancyStepTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyStepTooltipDivFooterBlock'
  });
  newVacancyStepTooltipDiv.append(newVacancyStepTooltipDivFooterBlock);

  var newVacancyStepTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyStepTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyStepTooltipDivFooterBlock.append(newVacancyStepTooltipDivFooterBlockCancelButton);

  var newVacancyStepTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyStepTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyStepTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyStepTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyStepTooltipDivFooterBlockCreateButton',
    text: 'Create',
    click: function () {
       vacancyStepName = newVacancyStepTooltipDivProjectNameBlock.val()
      if (vacancyStepName == '') {
        return;
      }
      vacancyStepName = encodeURI(vacancyStepName);
      newVacancyStepTooltipDivFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/createMyAtsVacancyStep?vacancyStepName=' + vacancyStepName + '&vacancyId=' + vacancyId,
           success: function(response) {
             newVacancyStepTooltipDivFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
             clearCabinetAtsPanelDiv();
             createAtsPanelVacancyView(response);
           },
           error: function(response) {console.log('error');}
      });
    },
  });
  newVacancyStepTooltipDivFooterBlock.append(newVacancyStepTooltipDivFooterBlockCreateButton);

  newVacancyStepTooltipDivFooterBlock.append(newVacancyStepTooltipDivFooterBlockLoaderDiv);

  return newVacancyStepTooltipDiv;
}
