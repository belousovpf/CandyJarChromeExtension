function createAtsPanelVacancyStepTooltip(parentDiv) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 200,
    minHeight: 500,
    trigger: 'custom',
    position: 'bottom'
  });
}

function getAtsPanelVacancyStepTooltip(parentDiv, vacancyId, vacancyStepId, vacancyStepName, stepPosition) {
  var atsPanelVacancyStepTooltipDiv = $('<div/>', {
    class: 'atsPanelVacancyStepTooltipDiv',
  });

  var atsPanelVacancyStepTooltipDivCloseButton = $('<div>',{
    class: 'atsPanelVacancyStepTooltipDivCloseButton',
    text: '+',
    click: function() {
      parentDiv.tooltipster('hide');
    },
  });
  atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipDivCloseButton);

  var atsPanelVacancyStepTooltipLoaderDiv = $('<div/>', {
    class: 'atsPanelVacancyStepTooltipLoaderDiv',
  });

  if(stepPosition != 'first' && stepPosition != 'firstAndLast') {
    var atsPanelVacancyStepTooltipDivMoveUpButton = $('<button>',{
      class: 'atsPanelVacancyStepTooltipDivRenameButton',
      text: 'move Up',
      click: function() {
      atsPanelVacancyStepTooltipLoaderDiv.append(createLoaderSmallAnimationDiv());
       $.ajax({
            type: 'GET',
            url: 'https://candyjar.io/api/moveMyAtsVacancyStep?vacancyId=' + vacancyId + '&vacancyStepId=' + vacancyStepId + '&vacancyStepMoveDirection=' + -1,
            success: function(response) {
              atsPanelVacancyStepTooltipLoaderDiv.empty();
              parentDiv.tooltipster('hide');
              clearCabinetAtsPanelDiv();
              createAtsPanelVacancyView(response);
            },
            error: function(response) {
              atsPanelVacancyStepTooltipLoaderDiv.empty();
              parentDiv.tooltipster('hide');
            }
       });
      },
    });
    atsPanelVacancyStepTooltipDivMoveUpButton.html('move Up &#8593;');
    atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipDivMoveUpButton);
  }

  if(stepPosition != 'last' && stepPosition != 'firstAndLast') {
    var atsPanelVacancyStepTooltipDivMoveDownButton = $('<button>',{
      class: 'atsPanelVacancyStepTooltipDivRenameButton',
      text: 'move Down',
      click: function() {
        atsPanelVacancyStepTooltipLoaderDiv.append(createLoaderSmallAnimationDiv());
         $.ajax({
              type: 'GET',
              url: 'https://candyjar.io/api/moveMyAtsVacancyStep?vacancyId=' + vacancyId + '&vacancyStepId=' + vacancyStepId + '&vacancyStepMoveDirection=' + 1,
              success: function(response) {
                atsPanelVacancyStepTooltipLoaderDiv.empty();
                parentDiv.tooltipster('hide');
                clearCabinetAtsPanelDiv();
                createAtsPanelVacancyView(response);
              },
              error: function(response) {
                atsPanelVacancyStepTooltipLoaderDiv.empty();
                parentDiv.tooltipster('hide');
              }
         });
      },
    });
    atsPanelVacancyStepTooltipDivMoveDownButton.html('move Down &#8595;');
    atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipDivMoveDownButton);
  }


  var atsPanelVacancyStepTooltipDivRenameButton = $('<button>',{
    class: 'atsPanelVacancyStepTooltipDivRenameButton',
    text: 'rename',
    click: function() {
      parentDiv.tooltipster('content', getAtsPanelVacancyStepRenameDiv(parentDiv, vacancyId, vacancyStepId));
    },
  });
  atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipDivRenameButton);

  if(stepPosition != 'first' && stepPosition != 'firstAndLast') {
    var atsPanelVacancyStepTooltipDivDeleteButton = $('<button>',{
      class: 'atsPanelVacancyStepTooltipDivDeleteButton',
      text: 'delete',
      click: function() {
         parentDiv.tooltipster('content', getAtsPanelVacancyStepRemoveDiv(parentDiv, vacancyId, vacancyStepId));
      },
    });
    atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipDivDeleteButton);
  }

  atsPanelVacancyStepTooltipDiv.append(atsPanelVacancyStepTooltipLoaderDiv);
  return atsPanelVacancyStepTooltipDiv;
}

function getAtsPanelVacancyStepRenameDiv(parentDiv, vacancyId, vacancyStepId) {
  var atsPanelVacancyStepRenameDiv = $('<div/>', {
    class: 'atsPanelVacancyStepRenameDiv'
  });

  var atsPanelVacancyStepRenameProjectName = $('<input/>', {
    class: 'atsPanelVacancyStepRenameProjectName',
    type: 'text',
    value: '',
    maxLength: '20',
    placeholder: 'Enter Step Name',
  });
  atsPanelVacancyStepRenameDiv.append(atsPanelVacancyStepRenameProjectName);

  var atsPanelVacancyStepFooterBlock = $('<div/>', {
    class: 'atsPanelVacancyStepFooterBlock'
  });
  atsPanelVacancyStepRenameDiv.append(atsPanelVacancyStepFooterBlock);

  var atsPanelVacancyStepFooterBlockCancelButton = $('<button>',{
    class: 'atsPanelVacancyStepFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepFooterBlockCancelButton);

  var atsPanelVacancyStepFooterBlockLoaderDiv = $('<div/>', {
    class: 'atsPanelVacancyStepFooterBlockLoaderDiv',
    id: 'atsPanelVacancyStepFooterBlockLoaderDiv'
  });

  var atsPanelVacancyStepFooterBlockCreateButton = $('<button>',{
    class: 'atsPanelVacancyStepFooterBlockCreateButton',
    text: 'Rename',
    click: function () {
      vacancyStepName = atsPanelVacancyStepRenameProjectName.val()
      if (vacancyStepName == '') {
        return;
      }

      vacancyStepName = encodeURI(vacancyStepName);
      atsPanelVacancyStepFooterBlockLoaderDiv.append(createLoaderSmallAnimationDiv());
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/updateMyAtsVacancyStep?vacancyId=' + vacancyId + "&vacancyStepId=" + vacancyStepId + "&vacancyStepName=" + vacancyStepName,
           success: function(response) {
             atsPanelVacancyStepFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
             clearCabinetAtsPanelDiv();
             createAtsPanelVacancyView(response);
           },
           error: function(response) {
             atsPanelVacancyStepFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
           }
      });
    },

  });
  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepFooterBlockCreateButton);

  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepFooterBlockLoaderDiv);

   return atsPanelVacancyStepRenameDiv;
}

function getAtsPanelVacancyStepRemoveDiv(parentDiv, vacancyId, vacancyStepId) {
  var atsPanelVacancyStepRemoveDiv = $('<div/>', {
    class: 'atsPanelVacancyStepRemoveDiv'
  });

  var newVacancyStepTooltipAreYouSure = $('<div/>', {
    class: 'newVacancyStepTooltipAreYouSure',
    text: 'Are you sure?'
  });
  atsPanelVacancyStepRemoveDiv.append(newVacancyStepTooltipAreYouSure);

  var atsPanelVacancyStepFooterBlock = $('<div/>', {
    class: 'atsPanelVacancyStepFooterBlock'
  });
  atsPanelVacancyStepRemoveDiv.append(atsPanelVacancyStepFooterBlock);

  var atsPanelVacancyStepRemoveNoButton = $('<button>',{
    class: 'atsPanelVacancyStepRemoveNoButton',
    text: 'No',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepRemoveNoButton);

  var atsPanelVacancyStepFooterBlockLoaderDiv = $('<div/>', {
    class: 'atsPanelVacancyStepFooterBlockLoaderDiv',
    id: 'atsPanelVacancyStepFooterBlockLoaderDiv'
  });

  var atsPanelVacancyStepRemoveYesButton = $('<button>',{
    class: 'atsPanelVacancyStepRemoveYesButton',
    text: 'Yes, delete',
    click: function () {
      $.ajax({
           type: 'GET',
           url: 'https://candyjar.io/api/deleteMyAtsVacancyStep?vacancyId=' + vacancyId + '&vacancyStepId=' + vacancyStepId,
           success: function(response) {
             atsPanelVacancyStepFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
             clearCabinetAtsPanelDiv();
             atsPanelHistoryObject.currentStepId = 1;
             createAtsPanelVacancyView(response);
           },
           error: function(response) {
             atsPanelVacancyStepFooterBlockLoaderDiv.empty();
             parentDiv.tooltipster('hide');
           }
      });
    },
  });
  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepRemoveYesButton);

  atsPanelVacancyStepFooterBlock.append(atsPanelVacancyStepFooterBlockLoaderDiv);

  return atsPanelVacancyStepRemoveDiv;
}
