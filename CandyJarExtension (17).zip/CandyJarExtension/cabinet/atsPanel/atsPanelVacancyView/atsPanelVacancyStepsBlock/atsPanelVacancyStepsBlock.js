function createAtsPanelVacancyStepsBlock(parentDiv, vacancyRows) {

  var atsPanelVacancyStepsBlock = $('<div>',{
    class: "atsPanelVacancyStepsBlock",
  });
  parentDiv.append(atsPanelVacancyStepsBlock);

  if (vacancyRows.length) {
    var atsPanelVacancyViewVacancyNameDiv = $('<div>',{
      class: "atsPanelVacancyViewVacancyNameDiv",
      text: vacancyRows[0].vacancyName,
    });
    atsPanelVacancyStepsBlock.append(atsPanelVacancyViewVacancyNameDiv);
  }

  var atsPanelVacancyStepsBlockText = $('<div>',{
    class: "atsPanelVacancyStepsBlockText",
    text: "Steps: "
  });
  atsPanelVacancyStepsBlock.append(atsPanelVacancyStepsBlockText);


  var atsPanelVacancyStepsUl = $('<ul>',{
    class: "atsPanelVacancyStepsUl",
  });
  atsPanelVacancyStepsBlock.append(atsPanelVacancyStepsUl);

  var stepPosition = '';
  vacancyRows.sort((a, b) => a.vacancyStepId - b.vacancyStepId);
  for (var i = 0; i < vacancyRows.length; i++) {
    var vacancyLine = vacancyRows[i];
    if (vacancyLine.type != 'vacancyStep') {
      continue;
    }
    var vacancyStepId = vacancyLine.vacancyStepId;
    var vacancyStepName = vacancyLine.vacancyStepName;
    var vacancyStepCandidatesCount = 0;
    for (var k = 0; k < vacancyRows.length; k++) {
      if (vacancyRows[k].type == 'vacancyCandidate' && vacancyRows[k].vacancyStepId == vacancyStepId) {
        vacancyStepCandidatesCount++;
      }
    }
    if (stepPosition == '') {
      stepPosition = 'first';
    } else {
      stepPosition = 'middle';
    }
    if (vacancyStepId == vacancyRows[vacancyRows.length - 1].vacancyStepId) {
      if (stepPosition == 'first') {
        stepPosition = 'firstAndLast';
      } else {
        stepPosition = 'last';
      }
    }
    createAtsPanelVacancyStepsLi(atsPanelVacancyStepsUl, vacancyStepId, vacancyStepName + ' (' + vacancyStepCandidatesCount + ')', vacancyLine.vacancyId, stepPosition, vacancyRows);
    createAtsPanelVacancyDividerLi(atsPanelVacancyStepsUl);
  }
  createAtsPanelVacancyStepsLiNew(atsPanelVacancyStepsUl, vacancyRows[0].vacancyId);


}

function createAtsPanelVacancyStepsLi(parentDiv, vacancyStepId, vacancyStepName, vacancyId, stepPosition, vacancyRows) {
  var atsPanelVacancyStepsLi = $('<li>',{
    class: "atsPanelVacancyStepsLi",
  });
  parentDiv.append(atsPanelVacancyStepsLi);

  var atsPanelVacancyStepsLiCicleAndName = $('<span>',{
    class: "atsPanelVacancyStepsLiCicleAndName",
    click: function () {
      clearCabinetAtsPanelDiv();
      atsPanelHistoryObject.currentStepId = vacancyStepId;
      createAtsPanelVacancyView(vacancyRows);
    }
  });
  atsPanelVacancyStepsLi.append(atsPanelVacancyStepsLiCicleAndName);

  var atsPanelVacancyStepsLiCicle = $('<div>',{
    class: "atsPanelVacancyStepsLiCicle",
  });
  atsPanelVacancyStepsLiCicleAndName.append(atsPanelVacancyStepsLiCicle);

  if (vacancyStepId == atsPanelHistoryObject.currentStepId) {
    atsPanelVacancyStepsLiCicle.css('background-color','#6492af');
  }

  var atsPanelVacancyStepsLiCicleLabel = $('<span>',{
    class: "atsPanelVacancyStepsLiCicleId",
    text: vacancyStepId,
  });
  atsPanelVacancyStepsLiCicle.append(atsPanelVacancyStepsLiCicleLabel);

  var atsPanelVacancyStepsLiCicleTitle = $('<span>',{
    class: "atsPanelVacancyStepsLiCicleName",
    text: vacancyStepName,
  });
  atsPanelVacancyStepsLiCicleAndName.append(atsPanelVacancyStepsLiCicleTitle);

  var atsPanelVacancyStepsLiCicleActions = $('<button>',{
    class: 'atsPanelVacancyStepsLiCicleActions',
    text: '',
    click: function() {
      $('.atsPanelVacancyStepsLiCicleActions').tooltipster('hide');
      $(this).tooltipster('show');
      $(this).tooltipster('content', getAtsPanelVacancyStepTooltip(atsPanelVacancyStepsLiCicleActions, vacancyId, vacancyStepId, vacancyStepName, stepPosition));
    },
  });
  atsPanelVacancyStepsLiCicleActions.html('&#183;&#183;&#183;');
  atsPanelVacancyStepsLi.append(atsPanelVacancyStepsLiCicleActions);
  createAtsPanelVacancyStepTooltip(atsPanelVacancyStepsLiCicleActions, vacancyId, vacancyStepId, vacancyStepName);
}

function createAtsPanelVacancyStepsLiNew(parentDiv, vacancyId) {
  var atsPanelVacancyStepsLi = $('<li>',{
    class: "atsPanelVacancyStepsLi",
  });
  parentDiv.append(atsPanelVacancyStepsLi);

  var atsPanelVacancyStepsLiCicleNew = $('<div>',{
    class: "atsPanelVacancyStepsLiCicleNew",
  });
  atsPanelVacancyStepsLi.append(atsPanelVacancyStepsLiCicleNew);
  createAtsPanelVacancyNewStepTooltip(atsPanelVacancyStepsLiCicleNew, vacancyId);

  var atsPanelVacancyStepsLiCicleIdNew = $('<span>',{
    class: "atsPanelVacancyStepsLiCicleIdNew",
    text: '+',
  });
  atsPanelVacancyStepsLiCicleNew.append(atsPanelVacancyStepsLiCicleIdNew);


}

function createAtsPanelVacancyDividerLi(parentDiv) {
  var createAtsPanelVacancyDividerLi = $('<li>',{
    class: "createAtsPanelVacancyDividerLi",
  });
  parentDiv.append(createAtsPanelVacancyDividerLi);

  var createAtsPanelVacancyDividerLiDiv = $('<div>',{
    class: "createAtsPanelVacancyDividerLiDiv",
  });
  createAtsPanelVacancyDividerLi.append(createAtsPanelVacancyDividerLiDiv);


}
