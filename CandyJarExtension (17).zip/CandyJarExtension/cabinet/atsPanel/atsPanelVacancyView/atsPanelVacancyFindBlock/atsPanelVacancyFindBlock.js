function createAtsPanelVacancyFindBlock(parentDiv, vacancyRows) {
  var atsPanelVacancyFindBlockInputDiv = $('<div>',{
    class: "atsPanelVacancyFindBlockInputDiv",
  });
  parentDiv.append(atsPanelVacancyFindBlockInputDiv);

  var atsPanelVacancyFindBlockText = $('<div>',{
    class: "atsPanelVacancyFindBlockText",
    text: "Find Candidate: "
  });
  atsPanelVacancyFindBlockInputDiv.append(atsPanelVacancyFindBlockText);

  var atsPanelVacancyFindBlockInputBox = $('<input/>', {
    class: 'atsPanelVacancyFindBlockInputBox',
    type: 'text',
    maxLength: '25',
    placeholder: '',
    keyup: function () {
      value = $(this).val();
      if (value == '') {
        return;
      }
      foundCandidates = findCandidates(vacancyRows, value);
      $(".atsPanelVacancyCandidatesDiv").empty();
      addSelectedCandidatesToPanel($(".atsPanelVacancyCandidatesDiv"), foundCandidates, atsPanelHistoryObject.selectedFilterObject, atsPanelHistoryObject.filterObject.tags);
    }
  });
  atsPanelVacancyFindBlockInputDiv.append(atsPanelVacancyFindBlockInputBox);

}

function findCandidates(vacancyRows, symbols) {
  candidates = [];

  for (var i = 0; i < vacancyRows.length; i++) {
    developer = vacancyRows[i];
    if (developer.type != 'vacancyCandidate') {continue;}
    if(!developer.login){continue;}

    if (developer.about.location && developer.about.location.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.about.name && developer.about.name.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.about.language && developer.about.language.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.about.email && developer.about.email.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.about.currentCompany && developer.about.currentCompany.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.description && developer.description.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
    if (developer.login && developer.login.toLowerCase().includes(symbols)) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }

    needToAdd = false;
    for (var k = 0; k < developer.about.emails.length; k++) {
      currentEmail = developer.about.emails[k];
      if (currentEmail && currentEmail.toLowerCase().includes(symbols)) {
        needToAdd = true;
      }
    }
    for (var k = 0; k < developer.tags.length; k++) {
      currentTag = developer.tags[k];
      if (currentTag && currentTag.toLowerCase().includes(symbols)) {
        needToAdd = true;
      }
    }
    if (needToAdd) {
      if (!isCandidatePushed(candidates, developer)) {
        candidates.push(developer);
      }
      continue;
    }
  }
  return candidates;
}

function isCandidatePushed(candidates, candidate) {
  for (var a = 0; a < candidates.length; a++) {
    if (candidates[a].github_id == candidate.github_id) {
      return true;
    }
  }
  return false;
}
