function createAtsPanelVacancyView(vacancyRows) {
  parentDiv = $('#cabinetAtsPanelDiv');
  var atsPanelVacancyViewSelectionAside = $('<aside>',{
    class: "atsPanelVacancyViewSelectionAside",
  });
  parentDiv.append(atsPanelVacancyViewSelectionAside);

  var atsPanelVacancyViewSelectionBlock = $('<aside>',{
    class: "atsPanelVacancyViewSelectionBlock",
  });
  atsPanelVacancyViewSelectionAside.append(atsPanelVacancyViewSelectionBlock);

  createAtsPanelVacancyStepsBlock(atsPanelVacancyViewSelectionBlock, vacancyRows);
  createAtsPanelVacancyFindBlock(atsPanelVacancyViewSelectionBlock, vacancyRows);

  var atsPanelVacancyViewContentDiv = $('<div>',{
    class: "atsPanelVacancyViewContentDiv",
  });
  parentDiv.append(atsPanelVacancyViewContentDiv);

  var atsPanelVacancyButtonsDiv = $('<div>',{
    class: "atsPanelVacancyButtonsDiv",
  });
  atsPanelVacancyViewContentDiv.append(atsPanelVacancyButtonsDiv);

  var atsPanelVacancyCandidatesDiv = $('<div>',{
    class: "atsPanelVacancyCandidatesDiv",
  });
  atsPanelVacancyViewContentDiv.append(atsPanelVacancyCandidatesDiv);


  var atsPanelVacancyGoBackButton = $('<button>',{
    class: 'atsPanelVacancyGoBackButton',
    click: function () {
      clearCabinetAtsPanelDiv();
      createAtsPanelVacanciesView();
    },
    text: "Go Back",
  });
  atsPanelVacancyGoBackButton.html('&#8592; Go Back');
  atsPanelVacancyButtonsDiv.append(atsPanelVacancyGoBackButton);

  var atsPanelVacancyFoundResultsDiv = $('<div>',{
    class: "atsPanelVacancyFoundResultsDiv",
    text: 'no candidates added yet...',
  });
  atsPanelVacancyCandidatesDiv.append(atsPanelVacancyFoundResultsDiv);

  initializePaginatorBlock();
  subscribeToPaginatorBlockSelectedFilterObjectChange(onAtsPanelVacancyViewHistoryObjectChange);
  atsPanelHistoryObject.vacancyRows = vacancyRows;
  onAtsPanelVacancyViewHistoryObjectChange(atsPanelHistoryObject.selectedFilterObject);

}

function onCandidateVacancyStepChange(vacancyRows) {
  if ($(".atsPanelVacancyCandidatesDiv").length) {
    clearCabinetAtsPanelDiv();
    createAtsPanelVacancyView(vacancyRows);
  }
}

function onAtsPanelVacancyViewHistoryObjectChange(selectedFilterObject) {

   selectedFilterObject.limit = 20;
   atsPanelHistoryObject.selectedFilterObject = selectedFilterObject;

   $(".atsPanelVacancyCandidatesDiv").empty();
   $('.atsPanelVacancyCandidatesDiv').append(createLoaderAnimationDiv());
   response = selectAtsPanelVacancyDevelopers(atsPanelHistoryObject);
   atsPanelVacancyRequestOk(response, atsPanelHistoryObject)

}


function selectAtsPanelVacancyDevelopers(atsPanelHistoryObject) {
   var skipCandidates = (atsPanelHistoryObject.selectedFilterObject.page-1) * atsPanelHistoryObject.selectedFilterObject.limit;
   var skippedCandidates = 0;
   var isRelevant = true;
   var developers = [];
   var limit = atsPanelHistoryObject.selectedFilterObject.limit;
   var relevantDevelopersNumber = 0;

  for (var i = 0; i < atsPanelHistoryObject.vacancyRows.length; i++) {
    developer = atsPanelHistoryObject.vacancyRows[i];
    if (developer.type != 'vacancyCandidate') {continue;}
    if (developer.vacancyStepId != atsPanelHistoryObject.currentStepId) {continue;}
    if(!developer.login){continue;}


    relevantDevelopersNumber++;
    if (skippedCandidates < skipCandidates) {
      skippedCandidates++;
      continue;
    }

    if (developers.length < limit) {
      developers.push(developer);
    }
   }

  return [relevantDevelopersNumber, developers];
}

function atsPanelVacancyRequestOk(response, atsPanelHistoryObject) {

  var candidatesSize = response[0];
  var newCandidates = response[1];

  $(".atsPanelVacancyCandidatesDiv").empty();

   addSelectedCandidatesToPanel($(".atsPanelVacancyCandidatesDiv"), newCandidates, atsPanelHistoryObject.selectedFilterObject, atsPanelHistoryObject.filterObject.tags);


  var isLastPage = false;
  if (!newCandidates.length) {
    isLastPage = true;
  }

  if (atsPanelHistoryObject.selectedFilterObject.page == 1 && newCandidates.length == 0) {
    var atsPanelVacancyFoundResultsDiv = $('<div>',{
      class: "atsPanelVacancyFoundResultsDiv",
      text: 'no candidates added yet...',
    });
    $(".atsPanelVacancyCandidatesDiv").append(atsPanelVacancyFoundResultsDiv);
  } else {
    createPaginatorBlock($(".atsPanelVacancyCandidatesDiv"), atsPanelHistoryObject.selectedFilterObject, isLastPage);
  }
}
