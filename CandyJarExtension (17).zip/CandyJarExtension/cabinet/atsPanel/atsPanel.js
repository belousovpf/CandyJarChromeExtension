var atsPanelHistoryObject = initializeAtsPanelHistoryObject();

function createAtsPanel(parentDiv) {
    var cabinetAtsMainPart = $('<div>',{
      class: "cabinetAtsMainPart",
    });
    parentDiv.append(cabinetAtsMainPart);

    var cabinetAtsPanelDiv = $('<div>',{
      class: "cabinetAtsPanelDiv",
      id: "cabinetAtsPanelDiv",
    });
    cabinetAtsMainPart.append(cabinetAtsPanelDiv);


    createAtsPanelVacanciesView();

  }

  function initializeAtsPanelHistoryObject() {
    var historyObject = new Object();
    historyObject.currentStepId = 1;
    historyObject.vacancyRows = [];
    historyObject.filterObject = getFilterObjectTempalte();
    historyObject.selectedFilterObject = getFilterObjectTempalte();
    // historyObject.selectedFilterObjectVersion = 0;
    // historyObject.selectedCandidates = [];
    // historyObject.allStarredCandidates = [];
    // historyObject.foundResultsValue = 0;
    // historyObject.countrySpecializationId = [];
    return historyObject;
  }



  function createAtsPanelVacanciesView() {
    parentDiv = $('#cabinetAtsPanelDiv');
    var cabinetAtsPanelContentDiv = $('<div>',{
      class: "cabinetAtsPanelContentDiv",
    });
    parentDiv.append(cabinetAtsPanelContentDiv);

    var cabinetAtsPanelHeaderDiv = $('<div>',{
      class: "cabinetAtsPanelHeaderDiv",
    });
    cabinetAtsPanelContentDiv.append(cabinetAtsPanelHeaderDiv);

    var cabinetAtsPanelCandidatesDiv = $('<div>',{
      class: "cabinetAtsPanelCandidatesDiv",
    });
    cabinetAtsPanelContentDiv.append(cabinetAtsPanelCandidatesDiv);

    createAtsPanelNewVacancyBlock(cabinetAtsPanelHeaderDiv);



    var cabinetAtsPanelTableDiv = $('<div>',{
      class: "cabinetAtsPanelTableDiv",
    });
    cabinetAtsPanelContentDiv.append(cabinetAtsPanelTableDiv);

    generateAtsTable(cabinetAtsPanelTableDiv);

    var cabinetAtsPanelLoaderDiv = $('<div>',{
      class: "cabinetAtsPanelLoaderDiv",
      id: "cabinetAtsPanelLoaderDiv",
    });
    cabinetAtsPanelContentDiv.append(cabinetAtsPanelLoaderDiv);

    cabinetAtsPanelLoaderDiv.append(createLoaderAnimationDiv());

    $.ajax({
         type: 'GET',
         url: 'https://candyjar.io/api/getMyAtsVacancies',
         success: function(response) {
           cabinetAtsPanelLoaderDiv.empty();
           for (var i = 0; i < response.length; i++) {
             if (response[i].type == 'vacancy') {
              generateAtsTableRow($('#atsTableBody'), response[i], parentDiv);
             }
           }
         },
         error: function(response) {console.log('error');}
    });

    $.ajax({
         type: 'GET',
         // url: 'https://candyjar.io/api/getMyAtsVacancies',
         url: 'https://candyjar.io/api/getMyAtsAllData',
         success: function(response) {
           createAtsPanelFindBlock(cabinetAtsPanelHeaderDiv, response);
         },
         error: function(response) {console.log('error');}
    });
  }


  function generateAtsTable(parentDiv) {
    var table = $('<table/>',{id: 'atsTable', class:"atsTable"});
    parentDiv.append(table);
    var thead = $('<thead/>',{class:'atsTableHead'});table.append(thead);
        var tr = $('<tr/>',{class:'atsTableHeadTr'});thead.append(tr);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'NAME'});tr.append(th);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'CANDIDATES'});tr.append(th);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'CREATED'});tr.append(th);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'LAST UPDATED'});tr.append(th);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'COLOR'});tr.append(th);
            var th = $('<th/>',{class:'atsTableHeadTh', text: 'ACTIONS'});tr.append(th);
    var tbody = $('<tbody>',{id: 'atsTableBody', class:'atsTableBody'});table.append(tbody);
  }

  function generateAtsTableRow(tbody, vacancy) {
    var tr = $('<tr/>',{
      class:'atsTableBodyTr',
      id:'atsTableBodyTr'+vacancy.vacancyId,
    });
    tbody.prepend(tr);

      var td = $('<td/>', {
        id: 'vacancyName' + vacancy.vacancyId,
        text: vacancy.vacancyName,
        click: function () {
          if ($('.lds-ring').length) {
            return;
          }
          $('#cabinetAtsPanelLoaderDiv').append(createLoaderAnimationDiv());
          $.ajax({
               type: 'GET',
               url: 'https://candyjar.io/api/getMyAtsVacancyData?vacancyId=' + vacancy.vacancyId,
               success: function(response) {
                 console.log('111');
                 console.log(response);
                 clearCabinetAtsPanelDiv();
                 atsPanelHistoryObject.currentStepId = 1;
                 createAtsPanelVacancyView(response);
               },
               error: function(response) {console.log('error');}
          });
        },
      });
      tr.append(td);

      var td = $('<td/>',{text: vacancy.candidatesCount});tr.append(td);
      var td = $('<td/>',{text: vacancy.vacancyCreated.substring(0,10)});tr.append(td);
      var td = $('<td/>',{text: vacancy.vacancyUpdated.substring(0,10)});tr.append(td);
      var td = $('<td/>',{});tr.append(td);

      var tdColor = $('<input>',{
        class: 'tdColor',
        type: 'color',
        value: vacancy.vacancyColor,
        change: function () {
          vacancyColor = $(this).val();
          vacancyColor = vacancyColor.replace(/#/g, "%23");
          $.ajax({
               type: 'GET',
               url: 'https://candyjar.io/api/updateMyAtsVacancy?vacancyId=' + vacancy.vacancyId + "&vacancyColor=" + vacancyColor,
               success: function(response) {console.log(response);},
               error: function(response) {console.log('error');}
          });
        },
      });
      td.append(tdColor);

      var td = $('<td/>',{});tr.append(td);
      createAtsPanelTableActionsBlock(td, vacancy);
  }

  function clearCabinetAtsPanelDiv() {
    $('#cabinetAtsPanelDiv').empty();
  }
