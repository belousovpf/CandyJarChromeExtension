function createPaginatorBlock(parentDiv, selectedFilterObject, isLastPage) {
  var paginatorDiv = $('<div>',{
    class: "paginatorDiv",
    id: "paginatorDiv"
  });
  parentDiv.append(paginatorDiv);

  createPaginatorLeftArrowButton(paginatorDiv, selectedFilterObject);

  var paginatorBlock = $('<div>',{
    class: "paginatorBlock",
    id: "paginatorBlock"
  });
  paginatorDiv.append(paginatorBlock);



  if (selectedFilterObject.page <= 1) {
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 1, true);
    if (!isLastPage) {
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 2, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 3, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 4, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 5, false);
    }
  } else if (selectedFilterObject.page == 2) {
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 1, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 2, true);
    if (!isLastPage) {
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 3, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 4, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 5, false);
    }
  } else if (selectedFilterObject.page == 3) {
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 1, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 2, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, 3, true);
    if (!isLastPage) {
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 4, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 5, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, 6, false);
    }
  } else {
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page - 3, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page - 2, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page - 1, false);
    createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page, true);
    if (!isLastPage) {
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page + 1, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page + 2, false);
      createPaginatorPageButton(paginatorBlock, selectedFilterObject, selectedFilterObject.page + 3, false);
    }
  };

  createPaginatorRightArrowButton(paginatorDiv, selectedFilterObject);



}

function createPaginatorPageButton(parentDiv, selectedFilterObject, pageNumber, isCurrentPage) {
  var paginatorPageButton = $('<button>',{
    class: "paginatorPageButton",
    id: "paginatorPageButton",
    click: function () {
      selectedFilterObject.page = pageNumber;
      selectedFilterObject.version = selectedFilterObject.version + 1;
      for (var i = 0; i < paginatorBlockSubscribedFunctions.length; i++) {
        paginatorBlockSubscribedFunctions[i](selectedFilterObject);
      }
    },
  });
  parentDiv.append(paginatorPageButton);

  if (isCurrentPage) {
    paginatorPageButton.css("background-color", "#6d36ab");
    paginatorPageButton.css("color", "#fff");
  }

  var paginatorPageButtonSpan = $('<span>',{
    text: pageNumber
  });
  paginatorPageButton.append(paginatorPageButtonSpan);

}

var paginatorBlockSubscribedFunctions = [];
function initializePaginatorBlock() {
  paginatorBlockSubscribedFunctions = [];
}

function subscribeToPaginatorBlockSelectedFilterObjectChange(functionName) {
  paginatorBlockSubscribedFunctions.push(functionName);
}

function createPaginatorRightArrowButton(parentDiv, selectedFilterObject) {
  var paginatorRightArrowButton = $('<button>',{
    class: "paginatorRightArrowButton",
    id: "paginatorRightArrowButton",
    click: function () {
      selectedFilterObject.page = selectedFilterObject.page + 4;
      selectedFilterObject.version = selectedFilterObject.version + 1;
      for (var i = 0; i < paginatorBlockSubscribedFunctions.length; i++) {
        paginatorBlockSubscribedFunctions[i](selectedFilterObject);
      }
    },
  });
  parentDiv.append(paginatorRightArrowButton);

  paginatorRightArrowButton.append(giveRightArrowSvg);
}

function createPaginatorLeftArrowButton(parentDiv, selectedFilterObject) {
  var paginatorLeftArrowButton = $('<button>',{
    class: "paginatorLeftArrowButton",
    id: "paginatorLeftArrowButton",
    click: function () {
      selectedFilterObject.page = 1;
      selectedFilterObject.version = selectedFilterObject.version + 1;
      for (var i = 0; i < paginatorBlockSubscribedFunctions.length; i++) {
        paginatorBlockSubscribedFunctions[i](selectedFilterObject);
      }
    },
  });
  parentDiv.append(paginatorLeftArrowButton);

  paginatorLeftArrowButton.append(giveLeftArrowSvg);
}

function giveRightArrowSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'paginatorRightArrowSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M4.3 8.3a1 1 0 011.4 0l6.3 6.29 6.3-6.3a1 1 0 111.4 1.42l-7 7a1 1 0 01-1.4 0l-7-7a1 1 0 010-1.42z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}

function giveLeftArrowSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'paginatorLeftArrowSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M4.3 8.3a1 1 0 011.4 0l6.3 6.29 6.3-6.3a1 1 0 111.4 1.42l-7 7a1 1 0 01-1.4 0l-7-7a1 1 0 010-1.42z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}
