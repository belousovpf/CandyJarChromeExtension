var myTalentsPanelHistoryObject;

function initializeMyTalentsPanelData() {
  myTalentsPanelHistoryObject = initializeHistoryObject();
}


function createMyTalentsPanel(parentDiv) {

    initializeMyTalentsPanelData();

    var cabinetMyTalentsPanel = $('<div>',{
      class: "cabinetMyTalentsMainPart",
    });
    parentDiv.append(cabinetMyTalentsPanel);

    var cabinetMyTalentsPanelDiv = $('<div>',{
      class: "cabinetMyTalentsPanelDiv",
    });
    cabinetMyTalentsPanel.append(cabinetMyTalentsPanelDiv);


    var cabinetMyTalentsPanelSelectionAside = $('<aside>',{
      class: "cabinetMyTalentsPanelSelectionAside",
    });
    cabinetMyTalentsPanelDiv.append(cabinetMyTalentsPanelSelectionAside);

    initializeFilterBlock();
    initializePaginatorBlock();
    //createOrUpdateFilterBlock(cabinetMyTalentsPanelSelectionAside, myTalentsPanelHistoryObject.filterObject, myTalentsPanelHistoryObject.selectedFilterObject);
    subscribeToSelectedFilterObjectChange(onMyTalentsPageSelectedFilterObjectChange);
    subscribeToPaginatorBlockSelectedFilterObjectChange(onMyTalentsPageSelectedFilterObjectChange);


    var cabinetMyTalentsPanelContentDiv = $('<div>',{
      class: "cabinetMyTalentsPanelContentDiv",
    });
    cabinetMyTalentsPanelDiv.append(cabinetMyTalentsPanelContentDiv);

    var myTalentsFoundResultText = "";
    if (myTalentsPanelHistoryObject.foundResultsValue > 0) {
      myTalentsFoundResultText = "Found results: " + myTalentsPanelHistoryObject.foundResultsValue;
    }
    var cabinetMyTalentsFoundResultsDiv = $('<div>',{
      class: "cabinetMyTalentsFoundResultsDiv",
      text: myTalentsFoundResultText,
    });
    cabinetMyTalentsPanelContentDiv.append(cabinetMyTalentsFoundResultsDiv);

    var cabinetMyTalentsPanelCandidatesDiv = $('<div>',{
      class: "cabinetMyTalentsPanelCandidatesDiv",
    });
    cabinetMyTalentsPanelContentDiv.append(cabinetMyTalentsPanelCandidatesDiv);

    getUserStarredCandidates(myTalentsPanelHistoryObject, myTalentsCallBackUpdateFilterObjectOk, myTalentsCallBackUpdateFilterObjectError);
    $(".cabinetMyTalentsPanelCandidatesDiv").empty();
    $('.cabinetMyTalentsPanelCandidatesDiv').append(createLoaderAnimationDiv());

    // if (myTalentsPanelHistoryObject.selectedCandidates.length) {
    //     $(".cabinetMyTalentsPanelCandidatesDiv").empty();
    // } else {
    //   // var searchPanelEmptyCandidatesDiv = $('<div>',{
    //   //   class: "searchPanelEmptyCandidatesDiv",
    //   //   text: "Please Select Country and Languages"
    //   // });
    //   // searchPanelCandidatesDiv.append(searchPanelEmptyCandidatesDiv);
    // }

    // addSelectedCandidatesToPanel(cabinetMyTalentsPanelCandidatesDiv, myTalentsPanelHistoryObject.selectedCandidates, myTalentsPanelHistoryObject.selectedFilterObject);
    //
    // if (myTalentsPanelHistoryObject.selectedCandidates.length) {
    //   createPaginatorBlock(cabinetMyTalentsPanelCandidatesDiv, myTalentsPanelHistoryObject.selectedFilterObject, false);
    // }


}

function onMyTalentsPageSelectedFilterObjectChange(selectedFilterObject) {
  var authorizedDays = 0;
  if (authorizationInfo && authorizationInfo.days) {
    authorizedDays = authorizationInfo.days
  }
  if (authorizedDays <= 0 && selectedFilterObject.page > 1) {
    $(".cabinetMyTalentsPanelCandidatesDiv").empty();
    createSearchPanelNeedSubscriptionDiv($(".cabinetMyTalentsPanelCandidatesDiv"));
    return;
  }
  selectedFilterObject.limit = 20;

  if (!$('#FilterBlockFadeDiv').length) {
    $('#filterBlock').fadeTo('fast',.5);
    $('#filterBlock').append('<div id="FilterBlockFadeDiv" style="position: absolute;top:0;left:0;width: 100%;height:100%;z-index:2;opacity:0.4;filter: alpha(opacity = 50)"></div>');
  }
  $(".cabinetMyTalentsPanelCandidatesDiv").empty();
  $('.cabinetMyTalentsPanelCandidatesDiv').append(createLoaderAnimationDiv());

  response = selectDevelopers(myTalentsPanelHistoryObject.allStarredCandidates, selectedFilterObject);
  myTalentsPanelSelectionRequestOk(response, selectedFilterObject)

}

function selectDevelopers(allStarredCandidates, selectedFilterObject) {
  var skipCandidates = (selectedFilterObject.page-1) * selectedFilterObject.limit;
  var skippedCandidates = 0;
  var isRelevant = true;
  var developers = [];
  var limit = selectedFilterObject.limit;
  var relevantDevelopersNumber = 0;

  for (var i = 0; i < allStarredCandidates.length; i++) {
    developer = allStarredCandidates[i];
    if(!developer.login){continue;}

    var isRelevantByCountry = false;
    for (var index = 0; index < selectedFilterObject.countries.length; index++) {
      var selectedCountry = selectedFilterObject.countries[index];
      if (developer.about.country == selectedCountry) {
        isRelevantByCountry = true;
      }
    }
    if (!isRelevantByCountry && selectedFilterObject.countries.length) {
      continue;
    }

    var isRelevantByLanguageSpecialization = false;
    for (var index = 0; index < selectedFilterObject.languages.length; index++) {
      var selectedLanguage = selectedFilterObject.languages[index];
      if (developer.about.language == selectedLanguage) {
        isRelevantByLanguageSpecialization = true;
      }
    }

    for (var index = 0; index < selectedFilterObject.specializations.length; index++) {
      var selectedSpecialization = selectedFilterObject.specializations[index];
      if (developer.about.specialization == selectedSpecialization) {
        isRelevantByLanguageSpecialization = true;
      }
    }
    if (!isRelevantByLanguageSpecialization) {
      if (selectedFilterObject.languages.length || selectedFilterObject.specializations.length) {
        continue;
      }
    }

    if (selectedFilterObject.hireableOnly && !developer.tags.includes('hireable')) {
      continue;
    }

    if (selectedFilterObject.hideViewed) {
      var currentDate = new Date();
      var updatedAtDate = new Date();
      if (developer.updated_at) {
        updatedAtDate = new Date(updatedAt);
      }
      var days =  parseInt((currentDate.getTime()-updatedAtDate.getTime())/(24*3600*1000));
      if (days < 180) {
        continue;
      }
    }

    if (selectedFilterObject.emptyWork) {
      if (developer.accounts && developer.accounts.linkedinHTML && developer.accounts.linkedinHTML.length) {
            continue;
      }
    }

    relevantDevelopersNumber++;

    if (skippedCandidates < skipCandidates) {
      skippedCandidates++;
      continue;
    }

    if (developers.length < limit) {
      developers.push(developer);
    }




  }

  return [relevantDevelopersNumber, developers];
}

function myTalentsPanelSelectionRequestOk(response, selectedFilterObject) {
   $('#FilterBlockFadeDiv').remove();
   $('#filterBlock').fadeTo('fast',1);

  var candidatesSize = response[0];
  var newCandidates = response[1];

  if (myTalentsPanelHistoryObject.selectedFilterObjectVersion != selectedFilterObject.version) {
    myTalentsPanelHistoryObject.selectedFilterObjectVersion = selectedFilterObject.version;
    myTalentsPanelHistoryObject.selectedCandidates = [];
    myTalentsPanelHistoryObject.foundResultsValue = 0;
  }

  $(".cabinetMyTalentsPanelCandidatesDiv").empty();
  myTalentsPanelHistoryObject.selectedCandidates = addToSelectedCandidates(newCandidates, myTalentsPanelHistoryObject.selectedCandidates);
  addSelectedCandidatesToPanel($(".cabinetMyTalentsPanelCandidatesDiv"), myTalentsPanelHistoryObject.selectedCandidates, myTalentsPanelHistoryObject.selectedFilterObject, myTalentsPanelHistoryObject.filterObject.tags);

  myTalentsPanelHistoryObject.foundResultsValue = myTalentsPanelHistoryObject.foundResultsValue + candidatesSize;
  $(".cabinetMyTalentsFoundResultsDiv").text("Found results: " + myTalentsPanelHistoryObject.foundResultsValue);


  myTalentsPanelHistoryObject.selectedFilterObject = selectedFilterObject;

  var isLastPage = false;
  if (!myTalentsPanelHistoryObject.selectedCandidates.length) {
    isLastPage = true;
  }
  createPaginatorBlock($(".cabinetMyTalentsPanelCandidatesDiv"), selectedFilterObject, isLastPage);
}

function myTalentsCallBackUpdateFilterObjectOk(response, historyObject) {
  if (response.length) {
    createOrUpdateFilterBlock($(".cabinetMyTalentsPanelSelectionAside"), historyObject.filterObject, historyObject.selectedFilterObject);
    onMyTalentsPageSelectedFilterObjectChange(historyObject.selectedFilterObject);
  } else {
    var myTalentsPanelEmptyCandidatesDiv = $('<div>',{
      class: "myTalentsPanelEmptyCandidatesDiv",
      text: "Here you will see your Starred candidates."
    });
    $(".cabinetMyTalentsPanelCandidatesDiv").empty();
    $('.cabinetMyTalentsPanelCandidatesDiv').append(myTalentsPanelEmptyCandidatesDiv);
  }
}


function myTalentsCallBackUpdateFilterObjectError(response, historyObject) {
}
