function createSearchButtonBlock(parentDiv, selectedFilterObject) {
  var searchButtonBlock = $('<div>',{
    class: "searchButtonBlock",
    id: "searchButtonBlock"
  });
  parentDiv.append(searchButtonBlock);


  var searchButton = $('<button>',{
    class: 'searchButton',
    id: 'searchButton',
    text: 'Search',
    click: function () {
      $('.searchButtonBlockText').remove();
      if (selectedFilterObject.countries.length == 0 || (selectedFilterObject.languages.length == 0 && selectedFilterObject.specializations.length == 0) ) {
        createSearchButtonBlockText(searchButtonBlock, 'please select country and language');
      } else {
        selectedFilterObject.version = selectedFilterObject.version + 1;
        selectedFilterObject.page = 1;
        for (var i = 0; i < searchButtonBlockSubscribedFunctions.length; i++) {
          searchButtonBlockSubscribedFunctions[i](selectedFilterObject);
        }
      }
    },
  });
  searchButtonBlock.append(searchButton, selectedFilterObject);


  createSaveButton(searchButtonBlock, selectedFilterObject);

}

function refreshSearching(selectedFilterObject) {
  selectedFilterObject.version = selectedFilterObject.version + 1;
  for (var i = 0; i < searchButtonBlockSubscribedFunctions.length; i++) {
    searchButtonBlockSubscribedFunctions[i](selectedFilterObject);
  }
}

function createSaveButton(parentDiv, selectedFilterObject) {
  var saveButton = $('<button>',{
    class: 'saveButton',
    // id: 'saveButton',
    text: 'Save',
    click: function () {
      if ($(".saveSearchRequestsButtonLoaderAnimationDiv").length) {
        return;
      }
      $('.searchButtonBlockText').remove();
      if (selectedFilterObject.countries.length == 0 || (selectedFilterObject.languages.length == 0 && selectedFilterObject.specializations.length == 0) ) {
        createSearchButtonBlockText(parentDiv, 'nothing to save');
      } else {
        if (!isSignInAndHaveDays()) {
          $('.panelApiRenewSubscriptionDiv').remove();
          $('.panelApiRenewSubscriptionContactUsDiv').remove();
          createSearchPanelNeedSubscriptionDiv(parentDiv)
          //createSearchButtonBlockText(parentDiv, 'please updgrade your plan');
          return;
        }

        $('.saveButton').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', getFilterBlockSaveButtonTooltipDiv($(this), selectedFilterObject));
      }
    },
  });
  parentDiv.append(saveButton);
  createFilterBlockSaveButtonTooltip(saveButton);


  var savedRequestsDiv = $('<div>',{
    class: "savedRequestsDiv",
    id: "savedRequestsDiv"
  });
  parentDiv.append(savedRequestsDiv);

  if (authorizationInfo.searchRequests) {
    updateSavedRequests(authorizationInfo.searchRequests);
  }
}

function createFilterBlockSaveButtonTooltip(parentDiv) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 300,
    maxWidth: 500,
    trigger: 'custom',
    position: 'right'
  });
}

function getFilterBlockSaveButtonTooltipDiv(parentDiv, selectedFilterObject) {
  var defaultRequestName = getSearchingRequestString(selectedFilterObject);


  var newVacancyTooltipDiv = $('<div/>', {
    class: 'newVacancyTooltipDiv'
  });

  var newVacancyTooltipDivCreateNewBlock = $('<div/>', {
    class: 'newVacancyTooltipDivCreateNewBlock',
    text: 'Save Search Request'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivCreateNewBlock);

  var newVacancyTooltipDivProjectNameBlock = $('<input/>', {
    class: 'newVacancyTooltipDivProjectNameBlock',
    type: 'text',
    value: defaultRequestName,
    placeholder: 'Enter Name',
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivProjectNameBlock);

  var newVacancyTooltipDivFooterBlock = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlock'
  });
  newVacancyTooltipDiv.append(newVacancyTooltipDivFooterBlock);

  var newVacancyTooltipDivFooterBlockCancelButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCancelButton',
    text: 'Cancel',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCancelButton);

  var newVacancyTooltipDivFooterBlockLoaderDiv = $('<div/>', {
    class: 'newVacancyTooltipDivFooterBlockLoaderDiv',
    id: 'newVacancyTooltipDivFooterBlockLoaderDiv'
  });

  var newVacancyTooltipDivFooterBlockCreateButton = $('<button>',{
    class: 'newVacancyTooltipDivFooterBlockCreateButton',
    text: 'Save',
    click: function () {
      saveRequestName = newVacancyTooltipDivProjectNameBlock.val()
      if (saveRequestName == '') {
        return;
      }
      // saveRequestName = encodeURI(saveRequestName);
      // saveRequestName = saveRequestName.replace(/#/g, "%23");
      // saveRequestName = saveRequestName.replace(/\+/g, "%2B");

      newVacancyTooltipDivFooterBlockLoaderDiv.append(createSearchRequestsButtonLoaderAnimationDiv());
      searchRequests = [];
      if (authorizationInfo.searchRequests) {
        searchRequests = authorizationInfo.searchRequests;
      }
      selectedFilterObject.date = new Date();
      selectedFilterObject.name = saveRequestName;
      var newLength = searchRequests.unshift(selectedFilterObject);
      if (newLength > 5) {searchRequests.pop()}

      var requestString = getUpdateUserInfoSearchRequestsString(JSON.stringify(searchRequests));
      requestString = encodeURI(requestString);
      requestString = requestString.replace(/#/g, "%23");
      requestString = requestString.replace(/\+/g, "%2B");
      $.ajax({
           type: 'GET',
           url: requestString,
           success: function(response) {
             $(".saveSearchRequestsButtonLoaderAnimationDiv").remove();
             if (authorizationInfo != 0) {
               authorizationInfo.searchRequests = response.searchRequests;
               updateSavedRequests(authorizationInfo.searchRequests);
             };
             parentDiv.tooltipster('hide');
           },
           error: function() {
             $(".saveSearchRequestsButtonLoaderAnimationDiv").remove();
             $('.searchButtonBlockText').remove();
             createSearchButtonBlockText(parentDiv, 'something wrong :( please try later');
             parentDiv.tooltipster('hide');
           }
      });




      // $.ajax({
      //      type: 'GET',
      //      url: 'https://candyjar.io/api/createMyAtsVacancy?vacancyName=' + vacancyName,
      //      success: function(response) {
      //        generateAtsTableRow($('#atsTableBody'), response[0])
      //        newVacancyTooltipDivFooterBlockLoaderDiv.empty();
      //        parentDiv.tooltipster('hide');
      //      },
      //      error: function(response) {console.log('error');}
      // });
    },
  });
  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockCreateButton);

  newVacancyTooltipDivFooterBlock.append(newVacancyTooltipDivFooterBlockLoaderDiv);

  return newVacancyTooltipDiv;
}

function createSearchButtonBlockText(parentDiv, text) {
  var searchButtonBlockText = $('<div>',{
    class: 'searchButtonBlockText',
    id: 'searchButtonBlockText',
    text: text,
  });
  parentDiv.append(searchButtonBlockText);
}

function updateSavedRequests(searchingRequests) {
    if (!$('.saveButton').length) {
      return;
    }
    if (!searchingRequests) {
      return;
    }
    if (!searchingRequests.length) {
      return;
    }

    $('#savedRequestsDiv').empty();
    var cardButtonsBlockContactsButton = $('<button>',{
      type: "button",
      class: "savedRequestsButton",
      id: "savedRequestsButton",
      text: 'saved requests',
      click: function () {
        if ($('#savedSearchingRequestsUl').length) {
          $('#savedRequestsDiv').empty();
          updateSavedRequests(searchingRequests);
        } else {
          createSavedRequestsUlDiv($('#savedRequestsDiv'), searchingRequests);
        }
      },
      mouseleave: function () {
      },
    });
    $('#savedRequestsDiv').append(cardButtonsBlockContactsButton);
}

function createSavedRequestsUlDiv(parentDiv, searchingRequests) {
  var savedSearchingRequestsUl = $('<ul>',{
    class: 'savedSearchingRequestsUl',
    id: 'savedSearchingRequestsUl',
  });
  parentDiv.append(savedSearchingRequestsUl);

  for (var i = 0; i < searchingRequests.length; i++) {
    var request = searchingRequests[i];
    var savedRequestLi = $('<li>',{class: "savedSearchingRequestsLi"});
    savedSearchingRequestsUl.append(savedRequestLi);
    createSavedSearchingRequestsLiButton(savedRequestLi, request);
  }
}

function createSavedSearchingRequestsLiButton(parentDiv, request) {

  var requestName = request.name;
  if (!requestName || requestName == '') {
    requestName = getSearchingRequestString(request);
  }
  var savedSearchingRequestsLiButton = $('<button>',{
    type: "button",
    class: "savedSearchingRequestsLiButton",
    id: "savedSearchingRequestsLiButton",
    text: requestName,
    click: function () {
      $('.searchButtonBlock').remove();
      request.version = request.version + 1;
      regenerateCurrentFilterBlockWithSearchingButtonBlock(request);
      for (var i = 0; i < searchButtonBlockSubscribedFunctions.length; i++) {
        searchButtonBlockSubscribedFunctions[i](request);
      }
    },
    mouseleave: function () {},
  });
  parentDiv.append(savedSearchingRequestsLiButton);

  createSaveSearchRemoveSvgDiv(parentDiv, request);

}

function createSaveSearchRemoveSvgDiv(parentDiv, request) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('width', '18');
  svg.setAttribute('height', '18');
  svg.setAttribute('id', 'saveSearchRemoveSvg');
  svg.setAttribute('class', 'saveSearchRemoveSvg');

  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "fill-rule", "clip-rule");
  path1.setAttributeNS(null, "d", "M 16.394531 7.394531 L 10.929688 7.394531 C 10.75 7.394531 10.605469 7.25 10.605469 7.070312 L 10.605469 1.605469 C 10.605469 0.71875 9.886719 0 9 0 C 8.113281 0 7.394531 0.71875 7.394531 1.605469 L 7.394531 7.070312 C 7.394531 7.25 7.25 7.394531 7.070312 7.394531 L 1.605469 7.394531 C 0.71875 7.394531 0 8.113281 0 9 C 0 9.886719 0.71875 10.605469 1.605469 10.605469 L 7.070312 10.605469 C 7.25 10.605469 7.394531 10.75 7.394531 10.929688 L 7.394531 16.394531 C 7.394531 17.28125 8.113281 18 9 18 C 9.886719 18 10.605469 17.28125 10.605469 16.394531 L 10.605469 10.929688 C 10.605469 10.75 10.75 10.605469 10.929688 10.605469 L 16.394531 10.605469 C 17.28125 10.605469 18 9.886719 18 9 C 18 8.113281 17.28125 7.394531 16.394531 7.394531 Z M 16.394531 7.394531 ");
  path1.setAttributeNS(null, "fill", "#6492af");

  svg.appendChild(path1);

  var saveSearchRemoveSvgDiv = $('<div/>',{
    class: "saveSearchRemoveSvgDiv",
  });

   saveSearchRemoveSvgDiv.append(svg);
   saveSearchRemoveSvgDiv.click(function() {
     $('.saveSearchRemoveSvgDiv').tooltipster('hide');
     $(this).tooltipster('show');
     $(this).tooltipster('content', getSaveSearchRemoveButtonTooltipDiv($(this), request));
   });
   parentDiv.append(saveSearchRemoveSvgDiv);
   createSaveSearchRemoveButtonTooltip(saveSearchRemoveSvgDiv);
}

function createSaveSearchRemoveButtonTooltip(parentDiv) {
  parentDiv.tooltipster({
    content: '',
    animation: "swing",
    interactive: true,
    arrow: true,
    theme: 'tooltipster-shadow',
    minWidth: 200,
    minHeight: 500,
    trigger: 'custom',
    position: 'bottom'
  });
}

function getSaveSearchRemoveButtonTooltipDiv(parentDiv, request) {

  var searchRequestRemoveTooltipDiv = $('<div/>', {
    class: 'searchRequestRemoveTooltipDiv'
  });

  var searchRequestRemoveTooltipDivAreYouSure = $('<div/>', {
    class: 'searchRequestRemoveTooltipDivAreYouSure',
    text: 'Are you sure?'
  });
  searchRequestRemoveTooltipDiv.append(searchRequestRemoveTooltipDivAreYouSure);

  var searchRequestRemoveTooltipDivFooterBlock = $('<div/>', {
    class: 'searchRequestRemoveTooltipDivFooterBlock'
  });
  searchRequestRemoveTooltipDiv.append(searchRequestRemoveTooltipDivFooterBlock);

  var searchRequestRemoveTooltipDivNoButton = $('<button>',{
    class: 'searchRequestRemoveTooltipDivNoButton',
    text: 'No',
    click: function () {
      parentDiv.tooltipster('hide');
    },
  });
  searchRequestRemoveTooltipDivFooterBlock.append(searchRequestRemoveTooltipDivNoButton);

  var searchRequestRemoveTooltipLoaderDiv = $('<div/>', {
    class: 'searchRequestRemoveTooltipLoaderDiv',
    id: 'searchRequestRemoveTooltipLoaderDiv'
  });

  var searchRequestRemoveTooltipYesButton = $('<button>',{
    class: 'searchRequestRemoveTooltipYesButton',
    text: 'Yes, delete',
    click: function () {
      searchRequests = [];
      if (authorizationInfo.searchRequests) {
        searchRequests = authorizationInfo.searchRequests;
      }
      for (var k = 0; k < searchRequests.length; k++) {
        if (request.date == searchRequests[k].date) {
         searchRequests.splice(k, 1);
        }
      }
      searchRequestRemoveTooltipLoaderDiv.append(createSearchRequestsButtonLoaderAnimationDiv());
      var requestString = getUpdateUserInfoSearchRequestsString(JSON.stringify(searchRequests));
      requestString = encodeURI(requestString);
      requestString = requestString.replace(/#/g, "%23");
      requestString = requestString.replace(/\+/g, "%2B");
      $.ajax({
           type: 'GET',
           url: requestString,
           success: function(response) {
             $(".searchRequestRemoveTooltipLoaderDiv").remove();
             if (authorizationInfo != 0) {
               authorizationInfo.searchRequests = response.searchRequests;
               updateSavedRequests(authorizationInfo.searchRequests);
             }
           },
           error: function() {
             $(".searchRequestRemoveTooltipLoaderDiv").remove();
             $('.searchButtonBlockText').remove();
             createSearchButtonBlockText(parentDiv, 'something wrong :( please try later');
           }
      });
    },
  });
  searchRequestRemoveTooltipDivFooterBlock.append(searchRequestRemoveTooltipYesButton);

  searchRequestRemoveTooltipDivFooterBlock.append(searchRequestRemoveTooltipLoaderDiv);

  return searchRequestRemoveTooltipDiv;
}

function getSearchingRequestString(request) {
  var result = '';
  if (request.countries) {
      for (var j = 0; j < request.countries.length; j++) {
        result += request.countries[j] + ', ';
      }
  }
  if (request.languages) {
      for (var j = 0; j < request.languages.length; j++) {
        result += request.languages[j] + ', ';
      }
  }
  if (request.specializations) {
      for (var j = 0; j < request.specializations.length; j++) {
        result += request.specializations[j] + ', ';
      }
  }
  if (request.experiences) {
      for (var j = 0; j < request.experiences.length; j++) {
        result += request.experiences[j] + ', ';
      }
  }
  if (request.skills) {
      for (var j = 0; j < request.skills.length; j++) {
        result += request.skills[j] + ', ';
      }
  }
  if (request.topics) {
      for (var j = 0; j < request.topics.length; j++) {
        result += request.topics[j] + ', ';
      }
  }
  if (request.page) {
      result += 'page ' + request.page + ".";
  }
  return result;
}



var searchButtonBlockSubscribedFunctions = [];
function initializeSearchButtonBlock() {
  searchButtonBlockSubscribedFunctions = [];
}

function subscribeToSearchButtonBlockSelectedFilterObjectChange(functionName) {
  searchButtonBlockSubscribedFunctions.push(functionName);
}

function createSearchRequestsButtonLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "saveSearchRequestsButtonLoaderAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}
