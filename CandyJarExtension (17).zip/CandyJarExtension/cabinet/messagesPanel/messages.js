function createMessagesPanel(parentDiv) {

  $(".cabinet-main").css("background-color","#edf2f5");

  var messagesPanel = $('<div>',{
    class: "cabinetMessagesMainPart",
  });
  parentDiv.append(messagesPanel);

  var cabinetMessagesPanelDiv = $('<div>',{
    class: "cabinetMessagesPanelDiv",
  });
  messagesPanel.append(cabinetMessagesPanelDiv);


  var messagesPanelSelectionAside = $('<aside>',{
    class: "messagesPanelSelectionAside",
  });
  cabinetMessagesPanelDiv.append(messagesPanelSelectionAside);

  var messagesPanelSelectionDiv = $('<div>',{
    class: "messagesPanelSelectionDiv",
  });
  messagesPanelSelectionAside.append(messagesPanelSelectionDiv);

  var messagesPanelContentDiv = $('<div>',{
    class: "messagesPanelContentDiv",
    id: "messagesPanelContentDivId",
  });
  cabinetMessagesPanelDiv.append(messagesPanelContentDiv);

  var messagePanelSignInButton = $('<button>',{
    class: "messagePanelSignInButton",
    id: "messagePanelSignInButton",
    text: "Sign in with google",
    click: function () {
      $("#messagePanelSignInButton").remove();
      getAllMessages(true, getMessagesResult)}
  });
  messagePanelSignInButton.prepend(createGoogleSvg());
  messagesPanelContentDiv.append(messagePanelSignInButton);

  var messagesPanelProgressBarSection = $('<div>',{
    class: "messagesPanelProgressBarSection",
    id: "messagesPanelProgressBarSectionId",
  });
  messagesPanelContentDiv.append(messagesPanelProgressBarSection);

  var messagesPanelFoundCandidatesDiv = $('<div>',{
    class: "messagesPanelFoundCandidatesDiv",
    id: "messagesPanelFoundCandidatesDivId",
    text: ""
  });
  messagesPanelContentDiv.append(messagesPanelFoundCandidatesDiv);


  if (foundCandidates.length) {
      $("#messagesPanelFoundCandidatesDivId").text("found candidates: " + foundCandidates.length);
      for (var i = 0; i < foundCandidates.length; i++) {
        var candidate = foundCandidates[i];
        var parentDiv = $("#messagesPanelContentDivId");
        createCandidateCard(parentDiv, candidate);
      }
  }

  if (isSignInAndHaveDays()) {
    //getMessages(emailsSet, false, getMessagesResult);
  } else {

  }
}

function vizualizeDownloadProgressBar(text, percent) {
  if ($("#messagesProgressBarPercentTextId").length) {
    $("#messagesProgressBarPercentTextId").text(text);
    $("#messagesProgressBarId").css('width', percent+"%");
    return;
  }


  var messagesProgressBarNamePrcent = $('<div>',{
    class: "messagesProgressBarNamePrcent",
  });
  $("#messagesPanelProgressBarSectionId").append(messagesProgressBarNamePrcent);

  var messagesProgressBarNameText = $('<div>',{
    text: "cheking emails...",
  });
  messagesProgressBarNamePrcent.append(messagesProgressBarNameText);

  var messagesProgressBarPercentText = $('<div>',{
    id: "messagesProgressBarPercentTextId",
    text: text,
  });
  messagesProgressBarNamePrcent.append(messagesProgressBarPercentText);

  var messagesProgressDiv = $('<div>',{
    class: "messagesProgressDiv",
  });
  $("#messagesPanelProgressBarSectionId").append(messagesProgressDiv);

  var messagesProgressBar = $('<div>',{
    class: "messagesProgressBar",
    id: "messagesProgressBarId"
  }).css('width', percent+"%");
  messagesProgressDiv.append(messagesProgressBar);
}

function getMessagesResult(error, status, response) {
  var responseJson = JSON.parse(response);

  var messages = responseJson.messages;
  for (var i = 0; i < messages.length; i++) {
    var messageId = messages[i].id;
    getSingleMessage(messageId, getSingleMessageResult);
  }
}

var candidatesEmails = [];

function getSingleMessageResult(error, status, response) {

  var message = getSingleMessageJsonFromResponse(response);

  var currentEmails = [];
  for (var i = 0; i < message.fromList.length; i++) {
    currentEmails.push(message.fromList[i]);
  }
  for (var i = 0; i < message.toList.length; i++) {
    currentEmails.push(message.toList[i]);
  }

  currentEmails.push("andrey.tarashevskiy@jetbrains.com");

  for (var i = 0; i < currentEmails.length; i++) {
    var email = currentEmails[i];
    if (email.includes("noreply") || email.includes("no-reply") || email.includes("not-reply")) {
      continue;
    }
    if (!candidatesEmails.includes(email)) {
      candidatesEmails.push(email);
      vizualizeDownloadProgressBar("0/"+candidatesEmails.length, 0)
      if (candidatesEmails.length == 1) {
        addMessagesCandidate();
      }
    }
  }

  // console.log("from / " + message.from + " / " + message.fromList);
  // console.log("to / " + message.to + " / " + message.toList);
   // console.log("list = " + candidatesEmails.length);

}

var index = 0;

var foundCandidates = [];
function addMessagesCandidate() {
  if (candidatesEmails.length > index) {
    email = candidatesEmails[index++]
  } else {
    return;
  }
  var requestString = getSearchByTagFullRequestString(email, false);

  $.ajax({
      type: "get", url: requestString,
      success: function (candidate, text) {
        if (candidate.type == "User") {
          vizualizeDownloadProgressBar(index + "/"+candidatesEmails.length, (index*100)/candidatesEmails.length);
          foundCandidates.push(candidate);
          $("#messagesPanelFoundCandidatesDivId").text("found candidates: " + foundCandidates.length);
          vizualizeDownloadProgressBar(index + "/"+candidatesEmails.length, (index*100)/candidatesEmails.length);
          var parentDiv = $("#messagesPanelContentDivId");
          createCandidateCard(parentDiv, candidate);

          if (index >= candidatesEmails.length) {
            $("#messagesPanelProgressBarSectionId").remove();
          }
        }
      },
      error: function (request, status, error) {
        vizualizeDownloadProgressBar(index + "/"+candidatesEmails.length, (index*100)/candidatesEmails.length);
        if (index >= candidatesEmails.length) {
          $("#messagesPanelProgressBarSectionId").remove();
        }
      }
  });
    setTimeout(addMessagesCandidate, 1000);

  // $.get(requestString, function(response, status) {
  //   console.log(status);
  //   console.log(response);
  //   var candidate = getCandidateFromShortResponse(response);
  //   if (candidate && candidate.login) {
  //     var parentDiv = $("#messagesPanelContentDivId");
  //     console.log(candidate);
  //     if (parentDiv) {
  //       createCandidateCard(parentDiv, candidate);
  //     }
  //   }
  //   addMessagesCandidate();
  // });
}

function createGoogleSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 18 18');
  svg.setAttribute('width', '18');
  svg.setAttribute('height', '18');
  svg.setAttribute('class', 'messagePanelGoogleSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M17.64 9.204c0-.638-.057-1.251-.164-1.84H9v3.48h4.844a4.14 4.14 0 0 1-1.796 2.717v2.258h2.908c1.702-1.566 2.684-3.874 2.684-6.615z");
  path1.setAttributeNS(null, "fill", "#4285F4");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z");
  path2.setAttributeNS(null, "fill", "#34A853");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path2);

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "d", "M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z");
  path3.setAttributeNS(null, "fill", "#FBBC05");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path3);

  path4 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path4.setAttributeNS(null, "d", "M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z");
  path4.setAttributeNS(null, "fill", "#EA4335");
  path4.setAttributeNS(null, "fill-rule", "evenodd");
  path4.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path4);

  return svg;
}
