function createSkillsBlock(parentDiv, filterObject, selectedFilterObject) {
  var skillsInputDiv = $('<div>',{
    class: "filterBlockSkillsInputDiv",
  });
  parentDiv.append(skillsInputDiv);

  var skillsSearchText = $('<div>',{
    class: "filterBlockSkillsSearchText",
    text: "Skills: "
  });
  skillsInputDiv.append(skillsSearchText);

  var skillsSearchBox = $('<div>',{
    class: "filterBlockSkillsSearchBox",
  });
  skillsInputDiv.append(skillsSearchBox);

   var skillsList = [];
   var skillsSelectedValues = [];

  for (var i = 0; i < filterObject.skills.length; i++) {
    var skill = filterObject.skills[i];
    skillsList.push({label: skill, value: skill});

    if (selectedFilterObject.skills) {
      for (var k = 0; k < selectedFilterObject.skills.length; k++) {
        var selectedSkill = selectedFilterObject.skills[k];
        if (selectedSkill == skill) {
          skillsSelectedValues.push(selectedSkill);
        }
      }
    }

  }

   createSkillsSearchBox(skillsList, skillsSelectedValues, selectedFilterObject) ;
}

function createSkillsSearchBox(skillsList, skillsSelectedValues, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockSkillsSearchBox", {
      options: skillsList,
      multiple: true,
      autocomplete: true,
      value: skillsSelectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onSkillsSearchBoxValueChanged(value, selectedFilterObject)},
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}

function onSkillsSearchBoxValueChanged(skillsList, selectedFilterObject) {
  selectedFilterObject.skills = skillsList;
  onSelectedFilterObjectChange(selectedFilterObject);
  $(".select-pure__autocomplete").val('');
}
