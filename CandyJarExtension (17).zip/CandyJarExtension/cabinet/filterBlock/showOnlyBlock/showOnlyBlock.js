function createFilterBlockShowOnlyDiv(parentDiv, filterObject, selectedFilterObject) {

  var filterBlockShowOnlyDiv = $('<div>',{
    class: "filterBlockShowOnlyDiv",
  });
  parentDiv.append(filterBlockShowOnlyDiv);

  var filterBlockShowOnlyText = $('<div>',{
    class: "filterBlockShowOnlyText",
    text: "Show only:"
  });
  filterBlockShowOnlyDiv.append(filterBlockShowOnlyText);

  var filterBlockShowOnlyCheckboxDiv = $('<div>',{
    class: "filterBlockShowOnlyCheckboxDiv"
  });
  filterBlockShowOnlyDiv.append(filterBlockShowOnlyCheckboxDiv);

  isChecked = false;
  if (selectedFilterObject.hireableOnly) {
      isChecked = true;
  }
  filterBlockShowOnlyCheckboxDiv.append(getCheckboxItem('Hireable Only', 'hireableOnly', 'hireableOnly', isChecked, selectedFilterObject, 'Show candidates with the tag Hirable'));

  isChecked = false;
  if (selectedFilterObject.hideViewed) {
      isChecked = true;
  }
  filterBlockShowOnlyCheckboxDiv.append(getCheckboxItem('Hide Viewed', 'hideViewed', 'hideViewed', isChecked, selectedFilterObject, 'Hide viewed candidates seen less that 6 months'));

  isChecked = false;
  if (selectedFilterObject.emptyWork) {
      isChecked = true;
  }
  filterBlockShowOnlyCheckboxDiv.append(getCheckboxItem('No LinkedIn', 'noLinkedin', 'noLinkedin', isChecked, selectedFilterObject, 'Hide candidates with LinkedIn profile'));

  isChecked = false;
  if (selectedFilterObject.fullMatch) {
      isChecked = true;
  }
  filterBlockShowOnlyCheckboxDiv.append(getCheckboxItem('100% Match', 'fullMatch', 'fullMatch', isChecked, selectedFilterObject, 'Show candidates with the full matching of my request'));

  isChecked = false;
  if (selectedFilterObject.hasEmail) {
      isChecked = true;
  }
  filterBlockShowOnlyCheckboxDiv.append(getCheckboxItem('With Emails', 'hasEmail', 'hasEmail', isChecked, selectedFilterObject, 'Show candidates with emails'));


  // for (var i = 0; i < filterObject.languages.length; i++) {
  //   var languageName = filterObject.languages[i];
  //   if (languageName == "JavaScript/TypeScript") {
  //     languageName = "JS/TypeScript";
  //   }
  //   if (languageName == "SharePoint developer") {
  //     languageName = "SharePoint";
  //   }
  //   if (languageName == "Embedded Engineers") {
  //     languageName = "Embedded";
  //   }
  //   var languageId = filterObject.languages[i];
  //
  //   isChecked = false;
  //   if (selectedFilterObject.languages) {
  //     for (var k = 0; k < selectedFilterObject.languages.length; k++) {
  //       var selectedLanguage = selectedFilterObject.languages[k];
  //       if (selectedLanguage == languageId) {
  //         isChecked = true;
  //       }
  //     }
  //   }
  //
  //
  //   filterBlockLanguagesCheckboxDiv.append(getCheckboxItem(languageName, languageId, "language", isChecked, selectedFilterObject));
  // }

}
