function createExperienceBlock(parentDiv, filterObject, selectedFilterObject) {
  var experienceInputDiv = $('<div>',{
    class: "filterBlockExperienceInputDiv",
  });
  parentDiv.append(experienceInputDiv);

  var experienceSearchText = $('<div>',{
    class: "filterBlockExperienceSearchText",
    text: "Experience: "
  });
  experienceInputDiv.append(experienceSearchText);

  var experienceSearchBox = $('<div>',{
    class: "filterBlockExperienceSearchBox",
  });
  experienceInputDiv.append(experienceSearchBox);

  var experienceList = [];
  var experienceSelectedValues = [];

  for (var i = 0; i < filterObject.experiences.length; i++) {
    var experience = filterObject.experiences[i];
    experienceList.push({label: experience, value: experience});

    if (selectedFilterObject.experiences) {
      for (var k = 0; k < selectedFilterObject.experiences.length; k++) {
        var selectedExperience = selectedFilterObject.experiences[k];
        if (selectedExperience == experience) {
          experienceSelectedValues.push(selectedExperience);
        }
      }
    }

  }

  createExperienceSearchBox(experienceList, experienceSelectedValues, selectedFilterObject) ;
}

function createExperienceSearchBox(experienceList, experienceSelectedValues, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockExperienceSearchBox", {
      options: experienceList,
      multiple: true,
      autocomplete: true,
      value: experienceSelectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onExperienceSearchBoxValueChanged(value, selectedFilterObject) },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}

function onExperienceSearchBoxValueChanged(experienceList, selectedFilterObject) {
   selectedFilterObject.experiences = experienceList;
   onSelectedFilterObjectChange(selectedFilterObject);
}
