function createTopicsBlock(parentDiv, filterObject, selectedFilterObject) {
  var topicsInputDiv = $('<div>',{
    class: "filterBlockTopicsInputDiv",
  });
  parentDiv.append(topicsInputDiv);

  var topicsSearchText = $('<div>',{
    class: "filterBlockTopicsSearchText",
    text: "Topics: "
  });
  topicsInputDiv.append(topicsSearchText);

  var topicsSearchBox = $('<div>',{
    class: "filterBlockTopicsSearchBox",
  });
  topicsInputDiv.append(topicsSearchBox);

   var topicsList = [];
   var topicsSelectedValues = [];

  for (var i = 0; i < filterObject.topics.length; i++) {
    var topic = filterObject.topics[i];
    topicsList.push({label: topic, value: topic});

    if (selectedFilterObject.topics) {
      for (var k = 0; k < selectedFilterObject.topics.length; k++) {
        var selectedTopic = selectedFilterObject.topics[k];
        if (selectedTopic == topic) {
          topicsSelectedValues.push(selectedTopic);
        }
      }
    }

  }

   createTopicsSearchBox(topicsList, topicsSelectedValues, selectedFilterObject) ;
}

function createTopicsSearchBox(topicsList, topicsSelectedValues, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockTopicsSearchBox", {
      options: topicsList,
      multiple: true,
      autocomplete: true,
      value: topicsSelectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onTopicsSearchBoxValueChanged(value, selectedFilterObject) },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}

function onTopicsSearchBoxValueChanged(topicsList, selectedFilterObject) {
  selectedFilterObject.topics = topicsList;
  onSelectedFilterObjectChange(selectedFilterObject);
  $(".select-pure__autocomplete").val('');
}
