function createFilterBlockSpecializationaDiv(parentDiv, filterObject, selectedFilterObject) {
  if (!filterObject.specializations.length) {
    return;
  }
  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "IT specializations:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (specializationName == "All Software Engineers") {
      continue;
    }
    if (isDesignSpecializations(specializationName)) {
      continue;
    }
    if (isMaintenanceSpecializations(specializationName)) {
      continue;
    }
    if (isGameDevSpecializations(specializationName)) {
      continue;
    }
    if (isSalesSpecializations(specializationName)) {
      continue;
    }
    if (isHRSpecializations(specializationName)) {
      continue;
    }
    if (isDataScienceSpecializations(specializationName)) {
      continue;
    }
    if (isDataBaseSpecializations(specializationName)) {
      continue;
    }
    if (isEducationSpecializations(specializationName)) {
      continue;
    }
    if (isSAPSpecializations(specializationName)) {
      continue;
    }
    if (isHardwareSpecializations(specializationName)) {
      continue;
    }
    if (specializationName == "Others") {
      continue;
    }
    if (specializationName == "Backend") {
      continue;
    }
    if (specializationName == "Software / System Architect") {
      continue;
    }
    if (specializationName == "Fullstack") {
      continue;
    }
    if (specializationName == "Frontend") {
      continue;
    }
    if (specializationName == "Web developers") {
      continue;
    }
    if (specializationName == "NodeJS developers") {
      continue;
    }
    if (specializationName == "Gamedev / Game Design") {
      specializationName = "Gamedev";
    }
    if (specializationName == "Professor / Researcher") {
      specializationName = "Researcher";
    }
    if (specializationName == "Network / System Administration") {
      specializationName = "Network";
    }
    if (specializationName == "SAP engineer") {
      specializationName = "SAP";
    }
    if (specializationName == "Technical Support") {
      specializationName = "Support";
    }
    if (specializationName == "Teamlead/Techlead") {
      specializationName = "Techlead";
    }
    if (specializationName == "Robotics engineers") {
      specializationName = "Robotics";
    }
    if (specializationName == "Unity developers") {
      specializationName = "Unity";
    }
    if (specializationName == "UI / UX design") {
      specializationName = "UI / UX";
    }
    if (specializationName == "Datascience / ML / AI / Bigdata") {
      specializationName = "Datascience / ML";
    }

    var specializationId = filterObject.specializations[i];



    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }

}



function createFilterBlockDesignSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  designSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isDesignSpecializations(specializationName)) {
      designSpecializations.push(specializationName);
    }
  }

  if (!designSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Design:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < designSpecializations.length; i++) {
    var specializationName = designSpecializations[i];
    var specializationId = designSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockDataBaseSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  databaseSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isDataBaseSpecializations(specializationName)) {
      databaseSpecializations.push(specializationName);
    }
  }

  if (!databaseSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Database:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < databaseSpecializations.length; i++) {
    var specializationName = databaseSpecializations[i];
    var specializationId = databaseSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}


function createFilterBlockHardwareSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  hardwareSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isHardwareSpecializations(specializationName)) {
      hardwareSpecializations.push(specializationName);
    }
  }

  if (!hardwareSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Hardware:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < hardwareSpecializations.length; i++) {
    var specializationName = hardwareSpecializations[i];
    var specializationId = hardwareSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockDataScienceSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  dataScienceSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isDataScienceSpecializations(specializationName)) {
      dataScienceSpecializations.push(specializationName);
    }
  }

  if (!dataScienceSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Data Science:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < dataScienceSpecializations.length; i++) {
    var specializationName = dataScienceSpecializations[i];
    var specializationId = dataScienceSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockSalesSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  salesSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isSalesSpecializations(specializationName)) {
      salesSpecializations.push(specializationName);
    }
  }

  if (!salesSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Sales:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < salesSpecializations.length; i++) {
    var specializationName = salesSpecializations[i];
    var specializationId = salesSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockSAPSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  sapSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isSAPSpecializations(specializationName)) {
      sapSpecializations.push(specializationName);
    }
  }

  if (!sapSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "SAP:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < sapSpecializations.length; i++) {
    var specializationName = sapSpecializations[i];
    var specializationId = sapSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }
    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}


function createFilterBlockHRSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  hrSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isHRSpecializations(specializationName)) {
      hrSpecializations.push(specializationName);
    }
  }

  if (!hrSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Human Resources:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < hrSpecializations.length; i++) {
    var specializationName = hrSpecializations[i];
    var specializationId = hrSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockGameDevSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  gamedevSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isGameDevSpecializations(specializationName)) {
      gamedevSpecializations.push(specializationName);
    }
  }

  if (!gamedevSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Game Development:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < gamedevSpecializations.length; i++) {
    var specializationName = gamedevSpecializations[i];
    var specializationId = gamedevSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockMaintenanceSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  maintenanceSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isMaintenanceSpecializations(specializationName)) {
      maintenanceSpecializations.push(specializationName);
    }
  }

  if (!maintenanceSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Maintenance:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < maintenanceSpecializations.length; i++) {
    var specializationName = maintenanceSpecializations[i];
    var specializationId = maintenanceSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function createFilterBlockEducationSpecializationsDiv(parentDiv, filterObject, selectedFilterObject) {
  educationSpecializations = [];
  for (var i = 0; i < filterObject.specializations.length; i++) {
    var specializationName = filterObject.specializations[i];
    if (isEducationSpecializations(specializationName)) {
      educationSpecializations.push(specializationName);
    }
  }

  if (!educationSpecializations.length) {
    return;
  }

  var filterBlockSpecializtionDiv = $('<div>',{
    class: "filterBlockSpecializtionDiv",
  });
  parentDiv.append(filterBlockSpecializtionDiv);

  var filterBlockSpecializtionText = $('<div>',{
    class: "filterBlockSpecializtionText",
    text: "Education:"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializtionText);

  var filterBlockSpecializationCheckboxDiv = $('<div>',{
    class: "filterBlockSpecializationCheckboxDiv"
  });
  filterBlockSpecializtionDiv.append(filterBlockSpecializationCheckboxDiv);

  for (var i = 0; i < educationSpecializations.length; i++) {
    var specializationName = educationSpecializations[i];
    var specializationId = educationSpecializations[i];

    isChecked = false;
    if (selectedFilterObject.specializations) {
      for (var k = 0; k < selectedFilterObject.specializations.length; k++) {
        var selectedSpecialization = selectedFilterObject.specializations[k];
        if (selectedSpecialization == specializationId) {
          isChecked = true;
        }
      }
    }

    filterBlockSpecializationCheckboxDiv.append(getCheckboxItem(specializationName, specializationId, "specialization", isChecked, selectedFilterObject));
  }
}

function isDesignSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'graphic designer / illustrator') {
      return true;
    }
    if (name == 'ui / ux design') {
      return true;
    }
    if (name == 'ux analyst') {
      return true;
    }
    if (name == 'animator') {
      return true;
    }
    if (name == 'vfx artist') {
      return true;
    }
    if (name == 'photographer') {
      return true;
    }
    if (name == 'artist') {
      return true;
    }
    if (name == 'designer') {
      return true;
    }
    if (name == 'editor') {
      return true;
    }
    if (name == 'technical writer') {
      return true;
    }
    if (name == 'technical artist') {
      return true;
    }
    if (name == '3d generalist') {
      return true;
    }


}

function isDataScienceSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'bigdata engineer') {
      return true;
    }
    if (name == 'data scientist') {
      return true;
    }
    if (name == 'ml engineer') {
      return true;
    }
}

function isHardwareSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'iot developer') {
      return true;
    }
    if (name == 'embedded engineers') {
      return true;
    }
    if (name == 'mechatronic engineer') {
      return true;
    }
    if (name == 'robotics engineer') {
      return true;
    }
    if (name == 'voip engineer') {
      return true;
    }
    if (name == 'audio engineer') {
      return true;
    }
}

function isEducationSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'researcher') {
      return true;
    }
    if (name == 'scientist') {
      return true;
    }
    if (name == 'lecturer') {
      return true;
    }
    if (name == 'professor') {
      return true;
    }
}

function isSAPSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'sap engineer') {
      return true;
    }
    if (name == 'sap consultant') {
      return true;
    }
    if (name == 'abap developer') {
      return true;
    }
}

function isDataBaseSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'cloud engineer') {
      return true;
    }
    if (name == 'database engineer') {
      return true;
    }
    if (name == 'database administrator') {
      return true;
    }
    if (name == 'dwh architect') {
      return true;
    }
    if (name == 'dwbi developer') {
      return true;
    }
    if (name == 'etl developer') {
      return true;
    }
    if (name == 'plsql developer') {
      return true;
    }
    if (name == 'oracle developer') {
      return true;
    }
}

function isGameDevSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'game developer') {
      return true;
    }
    if (name == 'game designer') {
      return true;
    }
    if (name == 'unity developer') {
      return true;
    }
    if (name == 'unity3d developer') {
      return true;
    }
}

function isHRSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'hr manager') {
      return true;
    }
    if (name == 'hr director') {
      return true;
    }
    if (name == 'hr generalist') {
      return true;
    }
    if (name == 'hr recruiter') {
      return true;
    }
}

function isMaintenanceSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'qa automation') {
      return true;
    }
    if (name == 'qa manual') {
      return true;
    }
    if (name == 'qa engineer') {
      return true;
    }
    if (name == 'qa tester') {
      return true;
    }
    if (name == 'qa lead') {
      return true;
    }
    if (name == 'qc engineer') {
      return true;
    }
    if (name == 'customer support') {
      return true;
    }
    if (name == 'site reliability engineer') {
      return true;
    }
    if (name == 'reliability engineer') {
      return true;
    }
    if (name == 'infrastructure engineer') {
      return true;
    }
    if (name == 'deployment manager') {
      return true;
    }
    if (name == 'devops') {
      return true;
    }
    if (name == 'helpdesk engineer') {
      return true;
    }
    if (name == 'technical support') {
      return true;
    }
    if (name == 'process automation') {
      return true;
    }
    if (name == 'system administrator') {
      return true;
    }
    if (name == 'network engineer') {
      return true;
    }
    if (name == 'system engineer') {
      return true;
    }
}


function isSalesSpecializations(name) {
    name = name.toLowerCase();
    if (name == 'sales assistent') {
      return true;
    }
    if (name == 'sales manager') {
      return true;
    }
    if (name == 'sales director') {
      return true;
    }
    if (name == 'sales consultant') {
      return true;
    }
}
