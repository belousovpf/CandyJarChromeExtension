function createCountriesBlock(parentDiv, filterObject, selectedFilterObject) {
  var countriesInputDiv = $('<div>',{
    class: "filterBlockCountriesInputDiv",
  });
  parentDiv.append(countriesInputDiv);

  var countriesSearchText = $('<div>',{
    class: "filterBlockCountriesSearchText",
    text: "Countries: "
  });
  countriesInputDiv.append(countriesSearchText);

  var countriesSearchBox = $('<div>',{
    class: "filterBlockCountriesSearchBox",
  });
  countriesInputDiv.append(countriesSearchBox);

  var countriesList = [];
  var selectedValues = [];

  for (var i = 0; i < filterObject.countries.length; i++) {
    var country = filterObject.countries[i];
    countriesList.push({label: country, value: country});

    if (selectedFilterObject.countries) {
      for (var k = 0; k < selectedFilterObject.countries.length; k++) {
        var selectedCountry = selectedFilterObject.countries[k];
        if (selectedCountry == country) {
          selectedValues.push(selectedCountry);
        }
      }
    }

  }

  createCountriesSearchBox(countriesList, selectedValues, filterObject, selectedFilterObject) ;
}

function createCountriesSearchBox(countriesList, selectedValues, filterObject, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockCountriesSearchBox", {
      options: countriesList,
      multiple: true,
      autocomplete: true,
      value: selectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onCountriesSearchBoxValueChanged(value, filterObject, selectedFilterObject) },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}

function onCountriesSearchBoxValueChanged(countriesList, filterObject, selectedFilterObject) {
  selectedFilterObject.countries = countriesList;


  filterObject.regions = calcualteRegions(countriesList, filterObject.countryRegions);
  selectedFilterObject.regions = [];

  $('#filterBlockRegionsDiv').empty();
  if ( filterObject.regions.length) {
    createRegionsBlock($("#filterBlockRegionsDiv"), filterObject, selectedFilterObject);
  }

$('#filterBlockCompaniesDiv').empty();
selectedFilterObject.companies = [];
// if (isSignInAndHaveDays()) {
//   decodedCountries = JSON.stringify(countriesList);
//   decodedCountries = window.btoa(decodedCountries);
//   var query = [];
//   query.push(decodedCountries);
//     $.ajax({
//         url: 'https://candyjar.io/api/selectionCompaniesByCountry',
//         type: 'POST',
//         data: JSON.stringify(query),
//         contentType: 'application/json; charset=utf-8',
//         dataType: 'json',
//         success: function(response) {
//           filterObject.companies = response;
//           if (filterObject.companies.length) {
//             createCompaniesBlock($("#filterBlockCompaniesDiv"), filterObject, selectedFilterObject);
//           }
//         },
//     });
// }

  onSelectedFilterObjectChange(selectedFilterObject);
}
