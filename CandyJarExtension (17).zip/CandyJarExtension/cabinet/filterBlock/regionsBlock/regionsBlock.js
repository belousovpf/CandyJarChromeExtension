function createRegionsBlock(parentDiv, filterObject, selectedFilterObject) {
  var regionsInputDiv = $('<div>',{
    class: "filterBlockRegionsInputDiv",
  });
  parentDiv.append(regionsInputDiv);

  var regionsSearchText = $('<div>',{
    class: "filterBlockRegionsSearchText",
    text: "Regions: "
  });
  regionsInputDiv.append(regionsSearchText);

  var regionsSearchBox = $('<div>',{
    class: "filterBlockRegionsSearchBox",
  });
  regionsInputDiv.append(regionsSearchBox);

  regionsInputDiv.append(getRegionsExcludeCheckboxItem("regionsExclude", "exclude regions", selectedFilterObject.isRegionsExclude, selectedFilterObject) );



  var regionsList = [];
  var regionsSelectedValues = [];
  for (var i = 0; i < filterObject.regions.length; i++) {
    var regionElement = filterObject.regions[i];
    regionsList.push({label: regionElement.name, value: regionElement.id});

    if (selectedFilterObject.regions) {
      for (var k = 0; k < selectedFilterObject.regions.length; k++) {
        var selectedRegionId = selectedFilterObject.regions[k];
        if (selectedRegionId == regionElement.id) {
          regionsSelectedValues.push(selectedRegionId);
        }
      }
    }

  }

  createRegionsSearchBox(regionsList, regionsSelectedValues, selectedFilterObject) ;
}

function createRegionsSearchBox(regionsList, regionsSelectedValues, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockRegionsSearchBox", {
      options: regionsList,
      multiple: true,
      autocomplete: true,
      value: regionsSelectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onRegionsSearchBoxValueChanged(value, selectedFilterObject) },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}

function onRegionsSearchBoxValueChanged(regionsList, selectedFilterObject) {
  selectedFilterObject.regions = regionsList;
  onSelectedFilterObjectChange(selectedFilterObject);
}

function calcualteRegions(countries, countryRegions) {
  var regions = [];
  for (var k = 0; k < countries.length; k++) {
    var currentCountry = countries[k];
    for (var i = 0; i < countryRegions.length; i++) {
      var countryRegionElement = countryRegions[i];
      if (currentCountry == countryRegionElement.country) {
        regions = regions.concat(countryRegionElement.regions);
      }
    }
  }
  return regions;
}

function getRegionsExcludeCheckboxItem(id, name, isChecked, selectedFilterObject) {
  var filterBlockCheckboxItemDiv = $('<div>',{
    class: "filterBlockCheckboxItemDiv"
  });


  var filterBlockCheckboxItemInput = $('<input>',{
    type: "checkbox",
    class: "filterBlockCheckboxItemInput",
    id: id,
    checked: isChecked,
    value: name,
  }).change(function() {
    onRegionsExcludeCheckBoxItemChange(this, id, selectedFilterObject);
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemInput);


  var filterBlockCheckboxItemLabel = $('<label>',{
    class: "filterBlockRegionsExcludeCheckboxItemLabel",
    for: id,
    text: name
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemLabel);

   return filterBlockCheckboxItemDiv;
}

function onRegionsExcludeCheckBoxItemChange(checkBoxElement, id, selectedFilterObject) {
  selectedFilterObject.isRegionsExclude = checkBoxElement.checked;
  onSelectedFilterObjectChange(selectedFilterObject);
}
