 function createCompaniesBlock(parentDiv, filterObject, selectedFilterObject) {
  var companiesInputDiv = $('<div>',{
    class: "filterBlockCompaniesInputDiv",
  });
  parentDiv.append(companiesInputDiv);

  var companiesSearchText = $('<div>',{
    class: "filterBlockCompaniesSearchText",
    text: "Companies: "
  });
  companiesInputDiv.append(companiesSearchText);

  var companiesSearchBox = $('<div>',{
    class: "filterBlockCompaniesSearchBox",
  });
  companiesInputDiv.append(companiesSearchBox);

  companiesInputDiv.append(getCompaniesExcludeCheckboxItem("companiesExclude", "exclude companies", selectedFilterObject.isCompaniesExclude, selectedFilterObject) );



  var companiesList = [];
  var companiesSelectedValues = [];

  for (var i = 0; i < filterObject.companies.length; i++) {
    var company = filterObject.companies[i];
    companiesList.push({label: company, value: 'company_'+company});

    if (selectedFilterObject.companies) {
      for (var k = 0; k < selectedFilterObject.companies.length; k++) {
        var selectedCompany = selectedFilterObject.companies[k];
        if (selectedCompany == 'company_'+company) {
          companiesSelectedValues.push(selectedCompany);
        }
      }
    }

  }


  createCompaniesSearchBox(companiesList, companiesSelectedValues, selectedFilterObject) ;
}

function createCompaniesSearchBox(companiesList, companiesSelectedValues, selectedFilterObject) {
  var instance = new SelectPure(".filterBlockCompaniesSearchBox", {
      options: companiesList,
      multiple: true,
      autocomplete: true,
      value: companiesSelectedValues,
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { onCompaniesSearchBoxValueChanged(value, selectedFilterObject) },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
 }

function onCompaniesSearchBoxValueChanged(companiesList, selectedFilterObject) {
  selectedFilterObject.companies = companiesList;
  onSelectedFilterObjectChange(selectedFilterObject);
}

 function getCompaniesExcludeCheckboxItem(id, name, isChecked, selectedFilterObject) {
  var filterBlockCheckboxItemDiv = $('<div>',{
    class: "filterBlockCheckboxItemDiv"
  });


  var filterBlockCheckboxItemInput = $('<input>',{
    type: "checkbox",
    class: "filterBlockCheckboxItemInput",
    id: id,
    checked: isChecked,
    value: name,
  }).change(function() {
    onCompaniesExcludeCheckBoxItemChange(this, id, selectedFilterObject);
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemInput);


  var filterBlockCheckboxItemLabel = $('<label>',{
    class: "filterBlockCompaniesExcludeCheckboxItemLabel",
    for: id,
    text: name
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemLabel);

   return filterBlockCheckboxItemDiv;
 }

function onCompaniesExcludeCheckBoxItemChange(checkBoxElement, id, selectedFilterObject) {
  selectedFilterObject.isCompaniesExclude = checkBoxElement.checked;
  onSelectedFilterObjectChange(selectedFilterObject);
}
