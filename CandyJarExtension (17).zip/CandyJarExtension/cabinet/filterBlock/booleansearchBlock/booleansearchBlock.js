function createBooleanSearchBlock(parentDiv, filterObject, selectedFilterObject) {
  var booleansearchBlockSkillsInputDiv = $('<div>',{
    class: "booleansearchBlockSkillsInputDiv",
    click: function () {
        if (!isSignInAndHaveDays()) {
          $('.booleansearchBlockSkillsInputDiv').tooltipster('hide');
          $(this).tooltipster('show');
          $(this).tooltipster('content', createNeedToUpgradeBlockDiv(booleansearchBlockSkillsInputDiv));
        }
    }
  });
  parentDiv.append(booleansearchBlockSkillsInputDiv);

  var booleansearchBlockSkillsSearchText = $('<div>',{
    class: "booleansearchBlockSkillsSearchText",
    text: "Boolean Search: "
  });
  booleansearchBlockSkillsInputDiv.append(booleansearchBlockSkillsSearchText);

  var filterBlockCheckboxTipDiv = createFilterBlockCheckboxTipDiv('booleanSearchTip');
  booleansearchBlockSkillsSearchText.append(filterBlockCheckboxTipDiv);

  var filterBlockCheckboxDitalizationDiv = createFilterBlockCheckboxDitalizationDiv('booleanSearchTip');
  booleansearchBlockSkillsSearchText.append(filterBlockCheckboxDitalizationDiv);
  filterBlockCheckboxDitalizationDiv.append(createBooleanSearchHTMLTip());

  filterBlockCheckboxTipDiv.tooltipster({
    content: filterBlockCheckboxDitalizationDiv,
    animation: "swing",
    interactive: true,
    theme: 'tooltipster-shadow',
    maxWidth: 300,
    arrow: true
  });
  filterBlockCheckboxDitalizationDiv.remove();

  var booleansearchBlockInputBox = $('<input/>', {
    class: 'booleansearchBlockInputBox',
    type: 'text',
    placeholder: '',
    value: selectedFilterObject.booleanSearchString,
    change: function(){
      value = $(this).val();
      $('.booleanSearchWrongParsingTextDiv').remove();
      if (value == '') {
        selectedFilterObject.booleanSearch = [];
        selectedFilterObject.booleanSearchString = '';
        onSelectedFilterObjectChange(selectedFilterObject);
        return;
      }
      try {
        var result = parseBooleanQuery(value);
        selectedFilterObject.booleanSearch = result;
        selectedFilterObject.booleanSearchString = value;
        onSelectedFilterObjectChange(selectedFilterObject);
      } catch (exception) {
        console.log('parsing exception');
        selectedFilterObject.booleanSearch = [];
        selectedFilterObject.booleanSearchString = '';
        onSelectedFilterObjectChange(selectedFilterObject);
        createBooleanSearchWrongParsingTextDiv(booleansearchBlockSkillsInputDiv);
      }
    }
  });
  booleansearchBlockSkillsInputDiv.append(booleansearchBlockInputBox);

  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(booleansearchBlockSkillsInputDiv);
    booleansearchBlockInputBox.prop('disabled', true);
  }

}


function createBooleanSearchHTMLTip() {
  var tooltipBlock = $('<div/>', {
    class: "tagsBlockTooltipHTML"
  });

  var tooltipBlockDescription = $('<div/>', {
    class: "tooltipBooleanSearchBlockDescription",
    text: "You can use the most popular logical operators that cover recruiters' tasks:"
  });
  tooltipBlock.append(tooltipBlockDescription);

  var tooltipBlockDescriptionOR = $('<div/>', {
    class: "tooltipBooleanSearchANDBlockDescription",
    text: "OR: java OR kotlin"
  });
  tooltipBlock.append(tooltipBlockDescriptionOR);

  var tooltipBlockDescriptionAND = $('<div/>', {
    class: "tooltipBooleanSearchANDBlockDescription",
    text: "AND: (java OR kotlin) AND (spring OR struts)"
  });
  tooltipBlock.append(tooltipBlockDescriptionAND);

  var tooltipBlockDescriptionNOT = $('<div/>', {
    class: "tooltipBooleanSearchANDBlockDescription",
    text: "NOT: javascript AND react AND NOT angular"
  });
  tooltipBlock.append(tooltipBlockDescriptionNOT);

  var tooltipBlockName = $('<a>',{
    class: "tooltipBooleanSearchBlockName",
    target: "_blank",
    href: 'https://product.candyjar.io/tpost/mbidofopn1-boolean-search',
    text: 'read more',
  });
  tooltipBlock.append(tooltipBlockName);

  return tooltipBlock;
}

function createBooleanSearchWrongParsingTextDiv(parentDiv) {
  var searchButtonBlockText = $('<div>',{
    class: 'booleanSearchWrongParsingTextDiv',
    id: 'booleanSearchWrongParsingTextDiv',
    text: 'Wrong boolean request :(',
  });
  parentDiv.append(searchButtonBlockText);
}
