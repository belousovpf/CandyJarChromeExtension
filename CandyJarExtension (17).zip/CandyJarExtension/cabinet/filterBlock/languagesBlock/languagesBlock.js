function createFilterBlockLanguagesDiv(parentDiv, filterObject, selectedFilterObject) {
  if (!filterObject.languages.length) {
    return;
  }

  var filterBlockLanguagesDiv = $('<div>',{
    class: "filterBlockLanguagesDiv",
  });
  parentDiv.append(filterBlockLanguagesDiv);

  var filterBlockLanguagesText = $('<div>',{
    class: "filterBlockLanguagesText",
    text: "Language:"
  });
  filterBlockLanguagesDiv.append(filterBlockLanguagesText);

  var filterBlockLanguagesCheckboxDiv = $('<div>',{
    class: "filterBlockLanguagesCheckboxDiv"
  });
  filterBlockLanguagesDiv.append(filterBlockLanguagesCheckboxDiv);

  for (var i = 0; i < filterObject.languages.length; i++) {
    var languageName = filterObject.languages[i];
    if (languageName == "JavaScript/TypeScript") {
      languageName = "JS/TypeScript";
    }
    if (languageName == "SharePoint developer") {
      languageName = "SharePoint";
    }
    var languageId = filterObject.languages[i];

    isChecked = false;
    if (selectedFilterObject.languages) {
      for (var k = 0; k < selectedFilterObject.languages.length; k++) {
        var selectedLanguage = selectedFilterObject.languages[k];
        if (selectedLanguage == languageId) {
          isChecked = true;
        }
      }
    }


    filterBlockLanguagesCheckboxDiv.append(getCheckboxItem(languageName, languageId, "language", isChecked, selectedFilterObject));
  }

}
