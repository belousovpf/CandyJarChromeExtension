// var selectedFilterObject = new Object();

function initializeFilterBlock() {
  filterBlockSubscribedFunctions = [];
}

var currentFilterBlockParentDiv;
var currentFilterBlockFilterObject;

function createOrUpdateFilterBlock(parentDiv, filterObject, selectedFilterObject) {

  if (!$('#filterBlock').length) {

    currentFilterBlockParentDiv = parentDiv;

    var filterBlock = $('<div>',{
      class: "filterBlock",
      id: "filterBlock",
    });
    parentDiv.append(filterBlock);

    // searchPanelSelectionAside.append(createSearchResetButtonsDiv());
    //
    var filterBlockSelectionDiv = $('<div>',{
      class: "filterBlockSelectionDiv",
      id: "filterBlockSelectionDiv",
    });
    filterBlock.append(filterBlockSelectionDiv);

    var filterBlockCountriesDiv = $('<div>',{
      class: "filterBlockCountriesDiv",
      id: "filterBlockCountriesDiv",
    });
    filterBlockSelectionDiv.append(filterBlockCountriesDiv);

    var filterBlockRegionsDiv = $('<div>',{
      class: "filterBlockRegionsDiv",
      id: "filterBlockRegionsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockRegionsDiv);

    var filterBlockCompaniesDiv = $('<div>',{
      class: "filterBlockCompaniesDiv",
      id: "filterBlockCompaniesDiv",
    });
    filterBlockSelectionDiv.append(filterBlockCompaniesDiv);

    var filterBlockLanguagesDiv = $('<div>',{
      class: "filterBlockLanguagesDiv",
      id: "filterBlockLanguagesDiv",
    });
    filterBlockSelectionDiv.append(filterBlockLanguagesDiv);

    var filterBlockMaintenanceSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockMaintenanceSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockMaintenanceSpecializationsDiv);

    var filterBlockDesignSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockDesignSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockDesignSpecializationsDiv);

    var filterBlockDGamedevSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockDGamedevSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockDGamedevSpecializationsDiv);

    var filterBlockSalesSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockSalesSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockSalesSpecializationsDiv);

    var filterBlockHRSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockHRSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockHRSpecializationsDiv);

    var filterBlockDataScienceSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockDataScienceSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockDataScienceSpecializationsDiv);

    var filterBlockDataBaseSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockDataBaseSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockDataBaseSpecializationsDiv);

    var filterBlockEducationSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockEducationSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockEducationSpecializationsDiv);

    var filterBlockSAPSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockSAPSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockSAPSpecializationsDiv);

    var filterBlockHardwareSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockHardwareSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockHardwareSpecializationsDiv);

    var filterBlockSpecializationsDiv = $('<div>',{
      class: "filterBlockSpecializationsDiv",
      id: "filterBlockSpecializationsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockSpecializationsDiv);

    var filterBlockExperienceDiv = $('<div>',{
      class: "filterBlockExperienceDiv",
      id: "filterBlockExperienceDiv",
    });
    filterBlockSelectionDiv.append(filterBlockExperienceDiv);

    var filterBlockSkillsDiv = $('<div>',{
      class: "filterBlockSkillsDiv",
      id: "filterBlockSkillsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockSkillsDiv);

    var filterBlockTopicsDiv = $('<div>',{
      class: "filterBlockTopicsDiv",
      id: "filterBlockTopicsDiv",
    });
    filterBlockSelectionDiv.append(filterBlockTopicsDiv);

    var filterBlockBooleanSearchDiv = $('<div>',{
      class: "filterBlockBooleanSearchDiv",
      id: "filterBlockBooleanSearchDiv",
    });
    filterBlockSelectionDiv.append(filterBlockBooleanSearchDiv);

    var filterBlockShowOnlyDiv = $('<div>',{
      class: "filterBlockShowOnlyDiv",
      id: "filterBlockShowOnlyDiv",
    });
    filterBlockSelectionDiv.append(filterBlockShowOnlyDiv);

    var filterBlockEmptyDiv = $('<div>',{
      class: "filterBlockEmptyDiv",
      id: "filterBlockEmptyDiv",
    });
    filterBlockSelectionDiv.append(filterBlockEmptyDiv);

  }

  currentFilterBlockFilterObject = filterObject;

  if (filterObject.countries.length) {
    $('#filterBlockCountriesDiv').empty();
    createCountriesBlock($("#filterBlockCountriesDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.regions.length) {
    $('#filterBlockRegionsDiv').empty();
    createRegionsBlock($("#filterBlockRegionsDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.companies.length) {
    $('#filterBlockCompaniesDiv').empty();
    createCompaniesBlock($("#filterBlockCompaniesDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.languages.length) {
    $('#filterBlockLanguagesDiv').empty();
    createFilterBlockLanguagesDiv($("#filterBlockLanguagesDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.specializations.length) {
    $('#filterBlockMaintenanceSpecializationsDiv').empty();
    createFilterBlockMaintenanceSpecializationsDiv($("#filterBlockMaintenanceSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockDesignSpecializationsDiv').empty();
    createFilterBlockDesignSpecializationsDiv($("#filterBlockDesignSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockDGamedevSpecializationsDiv').empty();
    createFilterBlockGameDevSpecializationsDiv($("#filterBlockDGamedevSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockSalesSpecializationsDiv').empty();
    createFilterBlockSalesSpecializationsDiv($("#filterBlockSalesSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockHRSpecializationsDiv').empty();
    createFilterBlockHRSpecializationsDiv($("#filterBlockHRSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockDataScienceSpecializationsDiv').empty();
    createFilterBlockDataScienceSpecializationsDiv($("#filterBlockDataScienceSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockDataBaseSpecializationsDiv').empty();
    createFilterBlockDataBaseSpecializationsDiv($("#filterBlockDataBaseSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockEducationSpecializationsDiv').empty();
    createFilterBlockEducationSpecializationsDiv($("#filterBlockEducationSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockSAPSpecializationsDiv').empty();
    createFilterBlockSAPSpecializationsDiv($("#filterBlockSAPSpecializationsDiv"), filterObject, selectedFilterObject);
    $('#filterBlockHardwareSpecializationsDiv').empty();
    createFilterBlockHardwareSpecializationsDiv($("#filterBlockHardwareSpecializationsDiv"), filterObject, selectedFilterObject);
  }



  if (filterObject.specializations.length) {
    $('#filterBlockSpecializationsDiv').empty();
    createFilterBlockSpecializationaDiv($("#filterBlockSpecializationsDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.experiences.length) {
    $('#filterBlockExperienceDiv').empty();
    createExperienceBlock($("#filterBlockExperienceDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.skills.length) {
    $('#filterBlockSkillsDiv').empty();
    createSkillsBlock($("#filterBlockSkillsDiv"), filterObject, selectedFilterObject);
  }

  if (filterObject.topics.length) {
    $('#filterBlockTopicsDiv').empty();
    createTopicsBlock($("#filterBlockTopicsDiv"), filterObject, selectedFilterObject);
  }

  $('#filterBlockBooleanSearchDiv').empty();
  createBooleanSearchBlock($("#filterBlockBooleanSearchDiv"), filterObject, selectedFilterObject);

  $('#filterBlockShowOnlyDiv').empty();
  createFilterBlockShowOnlyDiv($('#filterBlockShowOnlyDiv'), filterObject, selectedFilterObject)

}

function regenerateCurrentFilterBlockWithSearchingButtonBlock(selectedFilterObject2) {
  if (currentFilterBlockParentDiv && currentFilterBlockFilterObject && $('#filterBlock').length) {
    selectedFilterObject = JSON.parse(JSON.stringify(selectedFilterObject2));
    $('#filterBlock').remove();
    selectedFilterObject2 = JSON.parse(JSON.stringify(selectedFilterObject));
    createSearchButtonBlock(currentFilterBlockParentDiv, selectedFilterObject);
    createOrUpdateFilterBlock(currentFilterBlockParentDiv, currentFilterBlockFilterObject, selectedFilterObject);
    createSearchButtonBlock(currentFilterBlockParentDiv, selectedFilterObject);
  }
}


function getFilterObjectFromFilterBlock() {

}

function getFilterObjectTempalte() {
  var filterObjectTemplate = new Object();
  filterObjectTemplate.version = 1;
  filterObjectTemplate.page = 1;
  filterObjectTemplate.limit = 5;
  filterObjectTemplate.countries = [];
  filterObjectTemplate.regions = [];
  filterObjectTemplate.companies = [];
  filterObjectTemplate.isRegionsExclude = false;
  filterObjectTemplate.isCompaniesExclude = false;
  filterObjectTemplate.languages = [];
  filterObjectTemplate.specializations = [];
  filterObjectTemplate.skills = [];
  filterObjectTemplate.topics = [];
  filterObjectTemplate.tags = [];
  filterObjectTemplate.experiences = [];
  filterObjectTemplate.hireableOnly = false;
  filterObjectTemplate.hasEmail = false;
  filterObjectTemplate.hideViewed = false;
  filterObjectTemplate.emptyWork = false;
  filterObjectTemplate.fullMatch = false;
  filterObjectTemplate.name = '';
  filterObjectTemplate.date = '';
  filterObjectTemplate.booleanSearch = [];
  filterObjectTemplate.booleanSearchString = '';

  filterObjectTemplate.countryRegions = [];

  return filterObjectTemplate;
}

var filterBlockSubscribedFunctions = [];
function onSelectedFilterObjectChange(selectedFilterObject) {
  selectedFilterObject.version = selectedFilterObject.version + 1;
  selectedFilterObject.page = 1;
  for (var i = 0; i < filterBlockSubscribedFunctions.length; i++) {
    filterBlockSubscribedFunctions[i](selectedFilterObject);
  }
}


function subscribeToSelectedFilterObjectChange(functionName) {
  filterBlockSubscribedFunctions.push(functionName);
}


function getCheckboxItem(name, id, type, isChecked, selectedFilterObject, description = "") {
  var filterBlockCheckboxItemDiv = $('<div>',{
    class: "filterBlockCheckboxItemDiv"
  });


  var filterBlockCheckboxItemInput = $('<input>',{
    type: "checkbox",
    class: "filterBlockCheckboxItemInput",
    id: id,
    checked: isChecked,
    value: name,
  }).change(function() {
    onCheckBoxItemInputChange(this, id, type, selectedFilterObject);
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemInput);


  var filterBlockCheckboxItemLabel = $('<label>',{
    class: "filterBlockCheckboxItemLabel",
    for: id,
    text: name
  });
  filterBlockCheckboxItemDiv.append(filterBlockCheckboxItemLabel);

  if (description.length) {
    var filterBlockCheckboxTipDiv = createFilterBlockCheckboxTipDiv(id);
    filterBlockCheckboxItemDiv.append(filterBlockCheckboxTipDiv);

    var filterBlockCheckboxDitalizationDiv = createFilterBlockCheckboxDitalizationDiv(id);
    filterBlockCheckboxItemDiv.append(filterBlockCheckboxDitalizationDiv);
    filterBlockCheckboxDitalizationDiv.append(description);

    filterBlockCheckboxTipDiv.tooltipster({
      content: filterBlockCheckboxDitalizationDiv,
      animation: "swing",
      arrow: true
    });
     filterBlockCheckboxDitalizationDiv.remove();
  }

   return filterBlockCheckboxItemDiv;
}

function createFilterBlockCheckboxTipDiv(divId) {
  var filterBlockCheckboxTipDiv = $('<div/>', {
    class: "filterBlockCheckboxTipDiv" + " tooltip" + divId,
    id: 'filterBlockCheckboxTipDiv' + divId,
    text: "?",
  });
  return filterBlockCheckboxTipDiv;
}

function createFilterBlockCheckboxDitalizationDiv(divId) {
  var filterBlockCheckboxDitalizationDiv = $('<div/>', {
    class: "filterBlockCheckboxDitalizationDiv",
    id: 'filterBlockCheckboxDitalizationDiv' + divId,
  });
  return filterBlockCheckboxDitalizationDiv;
}

function onCheckBoxItemInputChange(checkBoxElement, id, type, selectedFilterObject) {
  if (type == "language") {
    if (checkBoxElement.checked) {
      if (!selectedFilterObject.languages.includes(id)) {
        selectedFilterObject.languages.push(id);
        onSelectedFilterObjectChange(selectedFilterObject);
      }
    } else {
      const index = selectedFilterObject.languages.indexOf(id);
      if (index > -1) {
        selectedFilterObject.languages.splice(index, 1);
        onSelectedFilterObjectChange(selectedFilterObject);
      }
    }
  }

  if (type == "specialization") {
    if (checkBoxElement.checked) {
      if (!selectedFilterObject.specializations.includes(id)) {
        selectedFilterObject.specializations.push(id);
        onSelectedFilterObjectChange(selectedFilterObject);
      }
    } else {
      const index = selectedFilterObject.specializations.indexOf(id);
      if (index > -1) {
        selectedFilterObject.specializations.splice(index, 1);
        onSelectedFilterObjectChange(selectedFilterObject);
      }
    }
  }

  if (type == "hireableOnly") {
    if (checkBoxElement.checked) {
        selectedFilterObject.hireableOnly = true;
        onSelectedFilterObjectChange(selectedFilterObject);
    } else {
      selectedFilterObject.hireableOnly = false;
      onSelectedFilterObjectChange(selectedFilterObject);
    }
  }

  if (type == "hideViewed") {
    if (checkBoxElement.checked) {
        selectedFilterObject.hideViewed = true;
        onSelectedFilterObjectChange(selectedFilterObject);
    } else {
      selectedFilterObject.hideViewed = false;
      onSelectedFilterObjectChange(selectedFilterObject);
    }
  }

  if (type == "noLinkedin") {
    if (checkBoxElement.checked) {
        selectedFilterObject.emptyWork = true;
        onSelectedFilterObjectChange(selectedFilterObject);
    } else {
      selectedFilterObject.emptyWork = false;
      onSelectedFilterObjectChange(selectedFilterObject);
    }
  }

  if (type == "fullMatch") {
    if (checkBoxElement.checked) {
        selectedFilterObject.fullMatch = true;
        onSelectedFilterObjectChange(selectedFilterObject);
    } else {
      selectedFilterObject.fullMatch = false;
      onSelectedFilterObjectChange(selectedFilterObject);
    }
  }

  if (type == "hasEmail") {
    if (checkBoxElement.checked) {
        selectedFilterObject.hasEmail = true;
        onSelectedFilterObjectChange(selectedFilterObject);
    } else {
      selectedFilterObject.hasEmail = false;
      onSelectedFilterObjectChange(selectedFilterObject);
    }
  }
}

function getFilterBlockTopics() {
  return [
    "frontend",
    "mobile",
    "fullstack",
    "devops",
    "ui-ux",
    "gamedev",
    "unity",
    "xamarin",
    "cloud",
    "embedded",
    "raspberry-pi",
    "virtualization",
    "payments",
    "design-patterns",
    "machine-learning",
    "arduino",
    "bitcoin",
    "blockchain",
    "functional-programming",
    "e-commerce",
    "iot",
    "deep-learning",
    "ethereum",
    "linux",
    "pl-sql",
    "prestashop",
    "magento",
    "algorithms",
    "api",
    "chatbot",
    "research",
    "robotics",
    "smart-contracts",
    "trading",
    "extensions",


  ];
}
