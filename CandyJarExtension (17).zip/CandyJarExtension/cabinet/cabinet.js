var currentPage = "cabinet";

document.addEventListener("DOMContentLoaded", function(){

  if (authorizationInfo == 0) {
    getAuthorization(cabinetAuthorizationOKfunction, authorizationFailFunction, 'cabinet');
    getUserInfo(false, getUserInfoCallback);
    getGmailInfo(false, getGmailInfoCallback);
  }

  // $('#cabinetNavigationMessagesId').fadeTo('fast',.5);
  // $('#cabinetNavigationMessagesId').append('<div id="FilterBlockFadeDiv" style="position: absolute;top:0;left:0;width: 100%;height:100%;z-index:2;opacity:0.4;filter: alpha(opacity = 50)"></div>');


  $('#cabinetNavigationDashboardId').click(function(e) {
    removeTextDecorationFromAllSearchPanelNavigationDivs();
    $('#cabinetNavigationDashboardTextId').css("text-decoration","underline");
    removeMainPartDivs();
    createAtsPanel($('.cabinet-main-part'));
  });
  // $('#cabinetNavigationDashboardId').fadeTo('fast',.5);

  initializeSearchPanelData();
  $('#cabinetNavigationSearchId').click(function(e) {
    removeTextDecorationFromAllSearchPanelNavigationDivs();
    $('#cabinetNavigationSearchTextId').css("text-decoration","underline");
    removeMainPartDivs();
    createSearchPanel($('.cabinet-main-part'));
  });
  $('#cabinetNavigationSearchTextId').css("text-decoration","underline");
  createSearchPanel($('.cabinet-main-part'));

  $('#cabinetNavigationMessagesId').click(function(e) {
    // removeTextDecorationFromAllSearchPanelNavigationDivs();
    // $('#cabinetNavigationMessagesTextId').css("text-decoration","underline");
    // removeMainPartDivs();
    // createMessagesPanel($('.cabinet-main-part'));
  });
  $('#cabinetNavigationMessagesId').fadeTo('fast',.5);

  $('#cabinetNavigationMyTalentsId').click(function(e) {
    removeTextDecorationFromAllSearchPanelNavigationDivs();
    $('#cabinetNavigationMyTalentsTextId').css("text-decoration","underline");
    removeMainPartDivs();
    createMyTalentsPanel($('.cabinet-main-part'));
  });
  // $('#cabinetNavigationMyTalentsId').fadeTo('fast',.5);

  $('#cabinetNavigationReportsId').click(function(e) {
    // removeTextDecorationFromAllSearchPanelNavigationDivs();
    // $('#cabinetNavigationReportsTextId').css("text-decoration","underline");
    // removeMainPartDivs();
    // createMessagesPanel($('.cabinet-main-part'));
  });
  $('#cabinetNavigationReportsId').fadeTo('fast',.5);

  $('#cabinetNavigationSettingsId').click(function(e) {
    // removeTextDecorationFromAllSearchPanelNavigationDivs();
    // $('#cabinetNavigationSettingsTextId').css("text-decoration","underline");
    // removeMainPartDivs();
    // createMessagesPanel($('.cabinet-main-part'));
  });
  $('#cabinetNavigationSettingsId').fadeTo('fast',.5);

  $('#cabinetNavigationHelpCenterId').click(function(e) {
    var win = window.open("https://product.candyjar.io/help-center", '_blank');
    if (win) {win.focus();}
  });

  $('#cabinetNavigationContactUsId').click(function(e) {
    var win = window.open("https://product.candyjar.io/en/tbd-message", '_blank');
    if (win) {win.focus();}
    // removeTextDecorationFromAllSearchPanelNavigationDivs();
    // $('#cabinetNavigationContactUsTextId').css("text-decoration","underline");
    // removeMainPartDivs();
    // createMessagesPanel($('.cabinet-main-part'));
  });


});

function removeTextDecorationFromAllSearchPanelNavigationDivs() {
  $('#cabinetNavigationDashboardTextId').css("text-decoration","");
  $('#cabinetNavigationSearchTextId').css("text-decoration","");
  $('#cabinetNavigationMessagesTextId').css("text-decoration","");
  $('#cabinetNavigationMyTalentsTextId').css("text-decoration","");
  $('#cabinetNavigationReportsTextId').css("text-decoration","");
  $('#cabinetNavigationSettingsTextId').css("text-decoration","");
  $('#cabinetNavigationContactUsTextId').css("text-decoration","");
  $('#cabinetNavigationAdminTextId').css("text-decoration","");
}


function getUserInfoCallback(error, status, response) {
  onUserInfoFetched(response);
  if (gmailUserInfo.picture) {
    var userAvatar = document.getElementById("cabinet-sidebar-header-photo-id");
    userAvatar.src = gmailUserInfo.picture;
  }
  if (gmailUserInfo.name) {
    var userName = document.getElementById("cabinet-sidebar-header-name-id");
    userName.textContent = gmailUserInfo.name;
  }

}

function getGmailInfoCallback(error, status, response) {
  onGmailInfoFetched(response);
}



function removeMainPartDivs() {
  $('.cabinetSearchMainPart').remove();
  $('.cabinetMessagesMainPart').remove();
  $('.cabinetMyTalentsMainPart').remove();
  $('.cabinetAdminMainPart').remove();
  $('.cabinetAtsMainPart').remove();
}

function cabinetAuthorizationOKfunction(result) {
  authorizationOKfunction(result);
  if (authorizationInfo && authorizationInfo.email == 'linsades@gmail.com') {
    var adminLi = $('<li>',{
      class: "cabinet-sidebar-navigation-li",
    });
    $('.cabinet-sidebar-navigation-ul').append(adminLi);

    var adminDiv = $('<div>',{
      class: "cabinet-sidebar-navigation-dashboardDiv",
      click: function () {
        removeTextDecorationFromAllSearchPanelNavigationDivs();
        $('#cabinetNavigationAdminTextId').css("text-decoration","underline");
        removeMainPartDivs();
        createAdminPanel($('.cabinet-main-part'));
      }
    });
    adminLi.append(adminDiv);

    var adminSpan = $('<div>',{
      class: "cabinet-sidebar-navigation-dashboardText",
      id: "cabinetNavigationAdminTextId",
      text: 'Admin Panel'
    });
    adminDiv.append(adminSpan);
  }
}









function createSkillsInputDiv(parentDiv) {
  var skillsInputDiv = $('<div>',{
    class: "skillsInputDiv",
  });
    parentDiv.append(skillsInputDiv);

  var skillsSearchText = $('<div>',{
    class: "skillsSearchText",
    text: "Skills: "
  });
  skillsInputDiv.append(skillsSearchText);

  var skillsSearchBox = $('<div>',{
    class: "skillsSearchBox",
  });
  skillsInputDiv.append(skillsSearchBox);

  createSkillsSearchBox() ;
}

function createCandySearchPageLastViewDiv(parentDiv, date) {
  var candySearchPageLastViewDiv = $('<div>',{
    class: "candySearchPageLastViewDiv",
  });
  parentDiv.append(candySearchPageLastViewDiv);

  var candySearchPageLastViewDiv1 = $('<div>',{
    class: "candySearchPageLastViewDiv1",
    text: "last view:",
  });
  candySearchPageLastViewDiv.append(candySearchPageLastViewDiv1);

  var candySearchPageLastViewDiv2 = $('<div>',{
    class: "candySearchPageLastViewDiv2",
    text: date,
  });
  candySearchPageLastViewDiv.append(candySearchPageLastViewDiv2);
}




function createSkillsSearchBox() {
  var instance = new SelectPure(".skillsSearchBox", {
      options: skillsList,
      multiple: true,
      autocomplete: true,
      //value: ["NY", "CA"],
      icon: "fa fa-times", // uses Font Awesome
      inlineIcon: false, // custom cross icon for multiple select.
      onChange: value => { console.log(value); },
      placeholder: false,
      classNames: {
        select: "select-pure__select",
        dropdownShown: "select-pure__select--opened",
        multiselect: "select-pure__select--multiple",
        label: "select-pure__label",
        placeholder: "select-pure__placeholder",
        dropdown: "select-pure__options",
        option: "select-pure__option",
        autocompleteInput: "select-pure__autocomplete",
        selectedLabel: "select-pure__selected-label",
        selectedOption: "select-pure__option--selected",
        placeholderHidden: "select-pure__placeholder--hidden",
        optionHidden: "select-pure__option--hidden",
      }
  });
}
