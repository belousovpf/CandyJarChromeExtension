function addToSelectedCandidates(newCandidates, existCandidates) {
  for (var i = 0; i < newCandidates.length; i++) {
    var newCandidate = newCandidates[i];
    var isExist = false;
    for (var k = 0; k < existCandidates.length; k++) {
      var existCandidate = existCandidates[k];
      if (existCandidate.login == newCandidate.login) {
        isExist = true;
      }
    }
    if (!isExist) {
      existCandidates.push(newCandidate);
    }
  }
  return existCandidates;
}

function addSelectedCandidatesToPanel(parentDiv, candidates, selectedFilterObject, globalTags) {
  for (var i = 0; i < candidates.length; i++) {
    var candidate = candidates[i];
    if (!candidate.login) {continue;}

    if (candidate.about.avatar_url === undefined) {candidate.about.avatar_url = candidate.about.avatarUrl;}
    if (candidate.about.current_position === undefined) {candidate.about.current_position = candidate.about.currentPosition;}
    if (candidate.about.current_company === undefined) {candidate.about.current_company = candidate.about.currentCompany;}

    if (candidate.developer_id && !candidate.github_id) {
      candidate.github_id = candidate.developer_id;
    }

    if (candidate.tags_count) {
      for (index = 0; index < candidate.tags_count.length; index++ ) {
        tagElement = candidate.tags_count[index];
        tagElement.github_activity = tagElement.githubActivity;
      }
    }

    if (candidate.github_metrics) {
      candidate.github_metrics.total_activity = candidate.github_metrics.totalActivity;
      candidate.github_metrics.total_github_activity = candidate.github_metrics.totalGithubActivity;
      candidate.github_metrics.total_linkedin_activity = candidate.github_metrics.totalLinkedinActivity;
    }

    for (var k = 0; k < selectedFilterObject.skills.length; k++) {
      var currentSkill = selectedFilterObject.skills[k];
      if (!candidate.top_tags.includes(currentSkill) && candidate.tags.includes(currentSkill) ) {
        candidate.top_tags.push(currentSkill);
      }
    }

    for (var m = 0; m < selectedFilterObject.booleanSearch.length; m++) {
      var andElements = selectedFilterObject.booleanSearch[m];
      for (var n = 0; n < andElements.length; n++) {
        var andElement = andElements[n];
        var elements = andElement.split(" ");
        for (var k = 0; k < elements.length; k++) {
          var element = elements[k];
          if (!candidate.top_tags.includes(element) && candidate.tags.includes(element) ) {
            candidate.top_tags.push(element);
          }
        }
      }
    }

    for (var k = 0; k < selectedFilterObject.topics.length; k++) {
      var currentTopic = selectedFilterObject.topics[k];
      if (!candidate.top_tags.includes(currentTopic) && candidate.tags.includes(currentTopic) ) {
        candidate.top_tags.push(currentTopic);
      }
    }

    if (candidate.login && candidate.login.includes('%')) {
      continue;
    }
    createCandidateCard(parentDiv, candidate, selectedFilterObject, globalTags);
  }
}

function createSearchPanelNeedSubscriptionDiv(parentDiv) {
  var searchPanelRenewSubscriptionDiv = $('<div>',{
    class: "panelApiRenewSubscriptionDiv",
    text: "it seems you need to renew your subscription."
  });
  parentDiv.append(searchPanelRenewSubscriptionDiv);

  var searchPanelRenewSubscriptionContactUsDiv = $('<button>',{
    type: "button",
    class: "panelApiRenewSubscriptionContactUsDiv",
    text: "upgrade",
    click: function () {
      var win = window.open("https://product.candyjar.io/search-engine-pricing", '_blank');
      if (win) {win.focus();}
    }
   });
  parentDiv.append(searchPanelRenewSubscriptionContactUsDiv);
}

function createLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "lds-ring"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function createLoaderSmallAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "lds-ring-small"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}
