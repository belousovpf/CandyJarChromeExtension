

execute();

function execute() {
  // getAuthorization(authorizationOKfunction, authorizationFailFunction);
  var githubLogin = getGithubLoginFromUrl();

  if (githubLogin.length <= 0) {
    return;
  }

  var requestString = getSearchByTagRequestString(getGithubLoginFromUrl(), true, "github_profile");
  chrome.runtime.sendMessage({from: "github_profile", type: "execute_get_request", requestString: requestString}, function(response) {});


  chrome.runtime.onMessage.addListener(listenerFunction);
}

function listenerFunction(request, sender, sendResponse) {
  if (request.from == "popup_script") {
    sendResponse({'developerTag': getGithubLoginFromUrl(), 'website_name': 'github_profile'});
  }

  if (request.from == "background" && request.type == "execute_get_request") {
    sendResponse("ok");
  };
};


function visualizeCandyjarElements(response, url) {

  var candyjarLogin = response.data.search[0].login;
  var topTags = response.data.search[0].top_tags;
  var accounts = response.data.search[0].accounts;
  var about = response.data.search[0].about;
  var languages = response.data.search[0].languages;
  var githubMetrics = response.data.search[0].github_metrics;
  var tagsCount = response.data.search[0].tags_count;

  $(".user-following-container").append(createCandyjarButton('https://candyjar.io/p/' + candyjarLogin));
  $(".user-following-container").append(createCandyPdfButton(getGithubLoginFromUrl()));
  $(".user-following-container").append(createCandyjarSectionDiv(""));
  addCandyjarCardRankDiv($(".user-following-container"), candyjarLogin, tagsCount, githubMetrics);

  if (topTags && topTags.length > 0) {
    $(".candyjarSectionDiv").prepend(createListOfCandyjarDeveloperTags(""));
    topTags.forEach(function(item, index, array) {
      var candyjarDeveloperTag = $('<span/>',{
        class: "candyjarDeveloperTag",
        id: "candyjarDeveloperTag" + index,
        text: item,
      });
      $("#listOfCandyjarDeveloperTags").append(candyjarDeveloperTag);
    });
  }

  $("#candyjarSectionDiv").append(createCandyjarSocialsDiv(""));
  $("#candyjarSocialsDiv").append(createCandyjarSocialsDiv2(""));





  if (languages && languages.length > 0) {
    var datasets = getCommitsByYear(languages);
    if (datasets && datasets.length > 0) {
    //  vizualizeChart(datasets);
    }
  }

}

function createCandyPdfButton(login) {
  var candyPdfButton = $('<button/>', {
    class: "candyPdfButton",
    id: "candyPdfButton",
    text: 'PDF',
    click: function () {
      var requestString = getSearchByTagFullRequestString(login, false);
      $.get(requestString, function(candidate) {
        createPDF(candidate);
      });
      sendTagTypeWebsiteData(login, "pdf-button-pressed", "github");
    }
  });
  return candyPdfButton;
}

function getCommitsByYear(languages) {

  var datasets = [];

  var backgroundColors = [
    'rgba(30, 137, 40, 0.2)',
    'rgba(138, 84, 78, 0.2)',
    'rgba(75, 192, 192, 0.2)',
    'rgba(75, 100, 100, 0.2)',
    'rgba(180, 229, 115, 0.2)'
  ];

  var borderColors = [
    'rgba(30, 137, 40, 1)',
    'rgba(138, 84, 78, 1)',
    'rgba(75, 192, 192, 1)',
    'rgba(75, 100, 100, 1)',
    'rgba(180, 229, 115, 1)'
  ];


  var maxNumberOfLanguages = 5;
  for (index = 0; index < languages.length; index++) {
  //languages.forEach(function(item, index, array) {
    if (index >= maxNumberOfLanguages) {
      continue;
    }
    var item = languages[index];
    var languageName = item.language_name;
    var getCommitsByYear = item.commits_by_year;

    var y2020 = 0;
    var y2019 = 0;
    var y2018 = 0;
    var y2017 = 0;
    var y2016 = 0;
    var y2015 = 0;
    var y2014 = 0;
    var atLeastOneYearSet = false;

    getCommitsByYear.forEach(function(item, i, array) {
      if (item.year == 2020) {y2020 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2019) {y2019 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2018) {y2018 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2017) {y2017 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2016) {y2016 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2015) {y2015 = item.commits_number; atLeastOneYearSet = true;};
      if (item.year == 2014) {y2014 = item.commits_number; atLeastOneYearSet = true;};
    });

    if (atLeastOneYearSet) {
      var dataset = {
        label: languageName,
        data: [y2014, y2015, y2016, y2017, y2018, y2019, y2020],
        backgroundColor: backgroundColors[index],
        borderColor: borderColors[index],
        pointBackgroundColor: borderColors[index],
        borderWidth: 1
      }
      datasets.push(dataset);
    }
  };
  return datasets;
}

function vizualizeChart(datasets) {

  var candyjarGraphicDiv = $('<div/>',{
    id: "candyjarGraphicDiv",
    class: "candyjarGraphicDiv",
  });

  var candyjarChartTitleDiv = $('<div/>',{
    id: "candyjarChartTitleDiv",
    class: "candyjarChartTitleDiv",
    text: "Opensource contributions",
  });

  var candyjarCanvas = $('<canvas/>',{
    id: "myChart",
  });
  //ctx0.height(200);
  //ctx0.width(200);
  $(".js-yearly-contributions").append(candyjarChartTitleDiv);
  $(".js-yearly-contributions").append(candyjarGraphicDiv);
  $("#candyjarGraphicDiv").append(candyjarCanvas);

  var candyjarCanvasCtx = candyjarCanvas[0].getContext('2d');
  var myChart = new Chart(candyjarCanvasCtx, {
    type: 'line',
    data: {
        labels: ['2014', '2015', '2016', '2017', '2018', '2019', '2020'],
        datasets: datasets
    },
    options: {
      legend: {
        labels: {
          usePointStyle: true,
          boxWidth: 5,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      title: {
            display: true,
            text: 'Commits number',
            position: 'left'
        },
    scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function createCandyjarButton(url) {
  var candyjarButton = $('<button/>', {
    class: "candyjarButton",
    id: "candyjarButton",
    text: 'CandyJar',
    click: function () {
      var win = window.open(url, '_blank');
      if (win) {win.focus();}
      sendTagTypeWebsiteData(getGithubLoginFromUrl(), "candyjar-button-pressed", "github");
    }
  });
  return candyjarButton;
}

function getGithubLoginFromUrl() {
  var url = document.location.href;
  url = url.replace("https://www.github.com/","");
  url = url.replace("http://www.github.com/","");
  url = url.replace("https://github.com/","");
  url = url.replace("http://github.com/","");
  url = url.replace("/","");
  url += "github";
  url = url.toLowerCase();
  if (url.includes("?") || url.includes("%")) {
    return "";
  }
  return url;
}
