execute();

function execute() {

  var url = getXingLoginFromUrl();
  if (url.includes("?")) {
    return;
  }
  // getAuthorization(authorizationOKfunction, authorizationFailFunction);


  var requestString = getSearchByTagRequestString(getXingLoginFromUrl(), true, "xing_profile");
  chrome.runtime.sendMessage({from: "xing_profile", type: "execute_get_request", requestString: requestString}, function(response) {});

  chrome.runtime.onMessage.addListener(listenerFunction);

}


function listenerFunction(request, sender, sendResponse) {
  if (request.from == "popup_script") {
    sendResponse({'developerTag': getXingLoginFromUrl(), 'website_name': 'xing_profile'});
  }

  if (request.from == "background" && request.type == "execute_get_request") {
    sendResponse("ok");
  };
};


function getXingLoginFromUrl() {
  var url = document.location.href;
  url = url.replace("https://www.xing.com/profile/","");
  url = url.replace("http://www.xing.com/profile/","");
  url = url.replace("https://xing.com/profile/","");
  url = url.replace("http://xing.com/profile/","");
  url = url.replace("/cv","");
  url = url.replace("/","");
  url += "xing";
  url = url.toLowerCase();
  return url;
}
