

execute();

function execute() {
  // getAuthorization(authorizationOKfunction, authorizationFailFunction);
  if (!$('.sections').length) {
    return;
  }
  var url = getMoikkrugLoginFromUrl();
  if (url.includes("?")) {
    return;
  }
  var requestString = getSearchByTagRequestString(url, true, "moikrug_profile");
  chrome.runtime.sendMessage({from: "moikrug_profile", type: "execute_get_request", requestString: requestString}, function(response) {});

  chrome.runtime.onMessage.addListener(listenerFunction);
}

function visualizeCandyjarElements(candidate) {
  var candyjarLogin = candidate.login;
  var topTags = candidate.top_tags;
  var accounts = candidate.accounts;
  var about = candidate.about;
  var githubMetrics = candidate.github_metrics;
  var tagsCount = candidate.tags_count;

  $(".salary").append(createCandyjarButton('https://candyjar.io/p/' + candyjarLogin));
  $(".sections").prepend(createCandyjarSectionDiv(""));

  var candyjarHead = $('<div/>',{
    class: "candyjarHead",
    id: "candyjarHead"
  });

  var candyjarTitle = $('<div/>',{
    class: "candyjarTitle",
    id: "candyjarTitle",
    text: "CandyJar"
  });

  $("#candyjarSectionDiv").append(candyjarHead);
  $("#candyjarHead").append(candyjarTitle);

  if (topTags && topTags.length > 0) {
    $("#candyjarSectionDiv").append(createListOfCandyjarDeveloperTags(""));
    topTags.forEach(function(item, index, array) {
      var candyjarDeveloperTag = $('<span/>',{
        class: "candyjarDeveloperTag",
        id: "candyjarDeveloperTag" + index,
        text: item,
      });
      $("#listOfCandyjarDeveloperTags").append(candyjarDeveloperTag);
    });
  }

  $("#candyjarSectionDiv").append(createCandyjarSocialsDiv(""));
  $("#candyjarSocialsDiv").append(createCandyjarSocialsDiv2(""));
  addCandyjarCardRankDiv($("#candyjarSectionDiv"), candyjarLogin, tagsCount, githubMetrics);


}

function createCandyjarButton(url) {
  var candyjarButton = $('<button/>', {
    class: "candyjarButton",
    text: 'CandyJar profile',
    click: function () {
      var win = window.open(url, '_blank');
      if (win) {win.focus();}
      sendTagTypeWebsiteData(getMoikkrugLoginFromUrl(), "candyjar-button-pressed", "moikrug");
    }
  });
  return candyjarButton;
}

function getMoikkrugLoginFromUrl() {
  var url = document.location.href;
  url = url.replace("https://www.moikrug.ru/","");
  url = url.replace("https://moikrug.ru/","");
  url = url.replace("https://www.career.habr.com/","");
  url = url.replace("https://career.habr.com/","");
  url = url.replace("/","");
  url += "moikrug";
  url = url.toLowerCase();
  return url;
}

function listenerFunction(request, sender, sendResponse) {
  if (request.from == "popup_script") {
    sendResponse({'developerTag': getMoikkrugLoginFromUrl(), 'website_name': 'moikrug_profile'});
  }

  if (request.from == "background" && request.type == "execute_get_request") {
    if (request.response.data.search.length > 0) {
      var candidate = request.response.data.search[0];
      candidate.profileLastView  = request.response.data.profileLastView;
      visualizeCandyjarElements(candidate);
      sendTagTypeWebsiteData(getMoikkrugLoginFromUrl(), "update", "moikrug");
    }
    sendResponse("ok");
  };
};
