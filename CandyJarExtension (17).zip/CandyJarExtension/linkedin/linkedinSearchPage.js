function startLinkedinSearchPage(currentUrl) {
  if (currentUrl.includes("linkedin.com/search/results/people/")) {
    if ($('.search-result__info').length) {
      if (countrySpecializationsIds.length == 0) {
        getCountrySpecializationIds(getCountrySpecializationOKfunction, getCountrySpecializationFailFunction);
      }
      chrome.runtime.onMessage.addListener(linkedinSearchPageBackgroundListener);
      addInformationToLinkedinCards();
    }
  }
}

function linkedinSearchPageBackgroundListener(request, sender, sendResponse) {
  if (request.from == "background" && request.type == "execute_get_request") {
    if (request.response && request.response.data && request.response.data.search.length > 0) {
      candidate = request.response.data.search[0]
      var candyjarLogin = candidate.login;
      var topTags = candidate.top_tags;
      var accounts = candidate.accounts;
      var about = candidate.about;
      var githubMetrics = candidate.github_metrics;
      var tagsCount = candidate.tags_count;
      var lastViewsDate = candidate.lastViewDate;
      var description = candidate.description;
      var linkedinLogin = getLinkedinLoginFromUrl(candidate.accounts.linkedinHTML);
      vizualizeSocialsSectiion(candyjarLogin, about, accounts, topTags, linkedinLogin);
      $(".candyjarDeveloperTag").css("font-size", "10px");
      $(".candyjarSocialsDiv2").css("padding", "0px");
      $(".candyjarSocialsDiv2").css("padding-top", "5px");
      $(".candyjarSocialsDiv2").css("padding-bottom", "5px");
      $(".candyjarSocialsDiv").css("background-color", "white");
      $(".listOfCandyjarDeveloperTags").css("padding", "0px");

      addCandyjarCardRankDiv($("#candyjarSectionDiv"+linkedinLogin), candyjarLogin, tagsCount, githubMetrics);
      $('.candyjarCardRankDiv').css("margin-top", "0px");
      $('.rate-base-layer').css("color", "#8136FC");
      $('.rate-select-layer').css("color", "#8136FC");

      createCandyStarredBlock($("#candyjarSectionDiv" + linkedinLogin), candidate);

      if (lastViewsDate && lastViewsDate.length) {
        $("#candyjarSectionDiv" + linkedinLogin).append(createLastViewDiv(lastViewsDate));
      }
      if (description && description.length) {
        $("#candyjarSectionDiv" + linkedinLogin).append(createCommentDiv(description));
      }
    }
    sendResponse("ok");
  };

  if (request.type == "add_star_to_candidate") {
    $(".linkedinStarDeveloperLoadAnimationDiv").remove();
    sendResponse("ok");
  };

};

var countrySpecializationsIds = [];
var countriesList = [];
var specializationsList = [];

function textAlreadyExistsInList(text, list) {
  for (indexT = 0; indexT < list.length; indexT++) {
    var item = list[indexT];
    if (text == item.text) {
      return true;
    }
  }
  if (text.toLowerCase() == "all software engineers") {return true;}
  if (text.toLowerCase() == "backend") {return true;}
  if (text.toLowerCase() == "frontend") {return true;}
  if (text.toLowerCase() == "fullstack") {return true;}
  if (text.toLowerCase() == "web developers") {return true;}
  if (text.toLowerCase() == "nodejs developers") {return true;}
  if (text.toLowerCase() == "iot engineers") {return true;}
  return false;
}


// OK and FAIL functions //
function getCountrySpecializationOKfunction(ids) {
  countrySpecializationsIds = ids;

  var countryIndex = 1;
  var specializationIndex = 1;
  countriesList = [];
  specializationsList = [];

  for (index = 0; index < ids.length; index++) {
    var item = ids[index];
    if (!textAlreadyExistsInList(item.country, countriesList)) {
      countriesList.push({"val":countryIndex++, "text":item.country});
    }
    if (!textAlreadyExistsInList(item.position, specializationsList)) {
      specializationsList.push({"val":specializationIndex++, "text":item.position});
    }
  }
}

function getCountrySpecializationFailFunction() {}
/////////////////////////////

// LINKEDIN CARDS //
function addInformationToLinkedinCards() {
  var searchElements = $('.search-result__info');
  for (index = 0; index < searchElements.length; index++) {
    var searchElement = $('.search-result__info').eq(index);
    var link = getLinkFromLinkedinCard(searchElement);

    link = link.replace("/in/", "");
    link = link.replace("/", "");
    link += "ldn";
    link = link.toLowerCase();
    var linkedinLogin = decodeUtf8(link);
    if (linkedinLogin.includes("%")) {
      continue;
    }

    if ($('#candyjarSectionDiv' + linkedinLogin).length == 0) {
      addSocialsSectionForLinkedinCards(linkedinLogin, searchElement);
    }
  }
}

function getLinkFromLinkedinCard(element) {
  var result = "";
  element.find('a').each(function() {
    var className = $(this).attr('class');
    if (className.includes('search-result__result-link')) {
       var href = $(this).attr('href');
       if (href.includes("/in/") && result.length == 0) {
         result = href;
       }
    }
  });
  return result;
}

function addSocialsSectionForLinkedinCards(linkedinLogin, searchElement) {
  var candyjarSectionDiv = createCandyjarSectionDiv(linkedinLogin);
  searchElement.append(candyjarSectionDiv);
  $("#candyjarSectionDiv" + linkedinLogin).css("border-width", "0px");
  $(".candyjarSectionDiv").css("margin-top", "5px");

  var requestString = getSearchByTagRequestString(linkedinLogin, false);
  chrome.runtime.sendMessage({from: "linkedin_search_page", type: "execute_get_request", requestString: requestString}, function(response) {});
}

function createLastViewDiv(date) {
  var candyProfileUserActivitiesDiv = $('<div>',{
    class: "candySearchPageLastViewDiv",
    text: "last view: " + date,
  });
  return candyProfileUserActivitiesDiv;
}

function createCommentDiv(comment) {
  var candySearchPageCommentDiv = $('<div>',{
    class: "candySearchPageCommentDiv",
    text: "comment: " + comment,
  });
  return candySearchPageCommentDiv;
}

function addLinkedCardRankDiv(searchElement, linkedinLogin, rankValue) {
  var linkedinCardImageElement = searchElement.parent().children(".search-result__image-wrapper");
  if (linkedinCardImageElement) {
    var candyjarRankDiv = createLinkedinCardRankDiv("linkedinCardRankDiv" + linkedinLogin);
    linkedinCardImageElement.append(candyjarRankDiv);

    var candyjarRankValueDiv = createLinkedinCardRankValueDiv("linkedinCardRankDiv" + linkedinLogin, rankValue);
    candyjarRankDiv.append(candyjarRankValueDiv);

    var candyjarRankTextDiv = createLinkedinCardRankTextDiv("linkedinCardRankDiv" + linkedinLogin);
    candyjarRankDiv.append(candyjarRankTextDiv);
  }
}

function addLinkedCardFindSimilarButton(searchElement, linkedinLogin) {
  var linkedinCardConnectElement = searchElement.parent().children(".search-result__actions");
  if (linkedinCardConnectElement) {
    var linkedinCardFindSimilarButton = createLinkedinCardFindSimilarButton("linkedinCardFindSimilarButton" + linkedinLogin);
    linkedinCardConnectElement.append(linkedinCardFindSimilarButton);


    linkedinCardFindSimilarButton.click(function() {
      $(".linkedinCardFindSimilarButton").off();
      $(".linkedinSearchPageFindButton").off();
      $("#linkedinCardFindSimilarButton" + linkedinLogin).text("Searching...");
      candyGetSimilarCandidatesByLoginTag(linkedinLogin, linkedinCardSimilarCandidatesOk, linkedinCardSimilarCandidatesFail);
      sendTagTypeWebsiteData(linkedinLogin, "similar-button-pressed", "linkedin");
    });
  }
}

function linkedinCardSimilarCandidatesOk(relevantCandidates, relevantCandidatesTotalSize, currentCandidate, loginTag) {
  if (relevantCandidates.length == 0) {
    $("#linkedinCardFindSimilarButton" + linkedinLogin).text("Not found...");
    return;
  }

  var relevantCandidatesContent = candyLinkedinSearchVizualizeRelevantCandidates(relevantCandidates);
  candyLinkedinSearchAddPaginator(".search-results-page", relevantCandidatesContent, relevantCandidatesTotalSize);
  $(".search-results-page").remove();
  $(".nav-search-bar").remove();
  $(".search-filters-bar").remove();
  $("#candySearchPageFindSection").remove();


}

function linkedinCardSimilarCandidatesFail(login, candidate) {
  candyGetSimilarCandidatesByLoginTag(login, linkedinCardSimilarCandidatesOk, linkedinCardSimilarCandidatesFail);
}

function createLinkedinCardFindSimilarButton(buttonId) {
  var linkedinCardFindSimilarButton = $('<button/>', {
    class: "linkedinCardFindSimilarButton",
    id: buttonId,
    text: 'find similar',
  });
  return linkedinCardFindSimilarButton;
}

function createLinkedinCardRankDiv(divId) {
  var linkedinCardRankDiv = $('<div/>', {
    class: "linkedinCardRankDiv",
    id: divId,
  });
  return linkedinCardRankDiv;
}

function createLinkedinCardRankValueDiv(divId, value) {
  var linkedinCardRankValueDiv = $('<div/>', {
    class: "linkedinCardRankValueDiv",
    id: divId,
    text: value,
  });
  return linkedinCardRankValueDiv;
}

function createLinkedinCardRankTextDiv(divId) {
  var linkedinCardRankTextDiv = $('<div/>', {
    class: "linkedinCardRankTextDiv",
    id: divId,
    text: "RANK",
  });
  return linkedinCardRankTextDiv;
}
///////////////////


// FIND SECTION //
// function addSearchPageFindSection(linkedinLoginTag) {
//
//   if ($('#candySearchPageFindSection').length) {
//     console.log("section already exists");
//     return;
//   }
//
//   var requestString = getSearchByTagFullRequestString(linkedinLoginTag, false);
//   $.get(requestString, function( candidate ) {
//
//     candidate = checkCandidateCountryRegionSpecialization(candidate);
//     if (candidate.about.country.length == 0) {
//       console.log("empty country");
//       return;
//     }
//     if ($('#candySearchPageFindSection').length) {
//       console.log("section already exists");
//       return;
//     }
//     if (countrySpecializationsIds.length == 0) {
//       console.log("empty ids");
//       return;
//     }
//     $('.search-s-rail').prepend(createSearchPageFindSection());
//
//     var candySearchPageFindSectionTitle = $('<p/>',{
//       class: "candySearchPageFindSectionTitle",
//       id: "candySearchPageFindSectionTitle",
//       text: "Search via CandyJar",
//     });
//
//
//     $("#candySearchPageFindSection").append(candySearchPageFindSectionTitle);
//
//     var searchPageFindSectionCountrySelectTitle = createSearchPageFindSectionCountrySelectTitle();
//     $("#candySearchPageFindSection").append(searchPageFindSectionCountrySelectTitle);
//
//     var searchPageFindSectionCountrySelectDiv = createSearchPageFindSectionCountrySelectDiv();
//     $("#candySearchPageFindSection").append(searchPageFindSectionCountrySelectDiv);
//
//     var searchPageFindSectionSpecializationSelectTitle = createSearchPageFindSectionSpecializationSelectTitle();
//     $("#candySearchPageFindSection").append(searchPageFindSectionSpecializationSelectTitle);
//
//     var searchPageFindSectionSpecializationSelectDiv = createSearchPageFindSectionSpecializationSelectDiv();
//     $("#candySearchPageFindSection").append(searchPageFindSectionSpecializationSelectDiv);
//
//     //$("#candySearchPageFindSection").append(createSearchPageListOfCandyjarDeveloperTags());
//     var linkedinSearchPageFindButton = createLinkedinSearchPageFindButton();
//     $("#candySearchPageFindSection").append(linkedinSearchPageFindButton);
//
//
//
//   var currentCountry = candidate.about.country;
//   if (candySearchPageIsSelectNameExist(currentCountry, countriesList)) {
//     var countrySelectValue = candySearchPageGetSelectValueByName(currentCountry, countriesList);
//     $("div.searchPageFindSectionCountrySelectDiv select").val(countrySelectValue);
//   } else {
//     $("div.searchPageFindSectionCountrySelectDiv select").val("1");
//   }
//
//   var currentSpecialization = candidate.about.specialization;
//   if (currentSpecialization == "software-development") {
//     currentSpecialization = candidate.about.language;
//   };
//
//   if (candySearchPageIsSelectNameExist(currentSpecialization, specializationsList)) {
//     var specializationSelectValue = candySearchPageGetSelectValueByName(currentSpecialization, specializationsList);
//     $("div.searchPageFindSectionSpecializationSelectDiv select").val(specializationSelectValue);
//   } else {
//     $("div.searchPageFindSectionSpecializationSelectDiv select").val("1");
//   };
//
//     linkedinSearchPageFindButton.click(function() {
//       $(".linkedinCardFindSimilarButton").off();
//       $(".linkedinSearchPageFindButton").off();
//       $("#linkedinSearchPageFindButton").text("Searching...");
//
//       var countryValue = $("div.searchPageFindSectionCountrySelectDiv select").val();
//       var countryName = candySearchPageGetSelectNameByValue(countryValue, countriesList);
//
//       var specializationValue = $("div.searchPageFindSectionSpecializationSelectDiv select").val();
//       var specializationName = candySearchPageGetSelectNameByValue(specializationValue, specializationsList);
//
//       candyMakeSelectionRequest(countryName, specializationName, 500, 1, "", linkedinFindSectionSimilarCandidatesOk, linkedinFindSectionSimilarCandidatesFail);
//       sendTagTypeWebsiteData(linkedinLoginTag, "search-button-pressed", "linkedin");
//     });
//
//
//   });
// }

// function linkedinFindSectionSimilarCandidatesOk(response) {
//   var relevantCandidatesTotalSize = response[0];
//   var relevantCandidates = response[1];
//
//     if (relevantCandidates.length == 0) {
//       $("#linkedinSearchPageFindButton").text("Not found...");
//       return;
//     }
//
//     var relevantCandidatesContent = candyLinkedinSearchVizualizeRelevantCandidates(relevantCandidates);
//     candyLinkedinSearchAddPaginator(".search-results-page", relevantCandidatesContent, relevantCandidatesTotalSize);
//     $(".search-results-page").remove();
//     $(".nav-search-bar").remove();
//     $(".search-filters-bar").remove();
//     $("#candySearchPageFindSection").remove();
//
//
// }

function isSpecializationIsLanguage(specializationName) {
  var result = false;
  switch (specializationName) {
    case 'android':     result = true; break;
    case 'c++':         result = true; break;
    case 'c#':          result = true; break;
    case 'go':          result = true; break;
    case 'ios':         result = true; break;
    case 'java':        result = true; break;
    case 'javascript':  result = true; break;
    case 'php':         result = true; break;
    case 'python':      result = true; break;
    default: break;
  }
  return result;
}

// function linkedinFindSectionSimilarCandidatesFail(country, specialization, limit, page, filter, resultOkFunction, resultFailFunction)  {
//   candyMakeSelectionRequest(country, specialization, limit, page, filter, resultOkFunction, resultFailFunction);
// }

function createSearchPageFindSectionCountrySelectDiv() {
  var searchPageFindSectionCountrySelectDiv = $('<div/>', {
    class: "searchPageFindSectionCountrySelectDiv",
    id: "searchPageFindSectionCountrySelectDiv",
  });


  var sel = $('<select>').appendTo(searchPageFindSectionCountrySelectDiv);
  $(countriesList).each(function() {
    sel.append($("<option>").attr('value',this.val).text(this.text));
  });

  return searchPageFindSectionCountrySelectDiv;
}

function createSearchPageFindSectionSpecializationSelectDiv() {
  var searchPageFindSectionSpecializationSelectDiv = $('<div/>', {
    class: "searchPageFindSectionSpecializationSelectDiv",
    id: "searchPageFindSectionSpecializationSelectDiv",
  });


  var sel = $('<select>').appendTo(searchPageFindSectionSpecializationSelectDiv);
  $(specializationsList).each(function() {
    sel.append($("<option>").attr('value',this.val).text(this.text));
  });

  return searchPageFindSectionSpecializationSelectDiv;
}

function createSearchPageFindSectionCountrySelectTitle() {
  var searchPageFindSectionCountrySelectTitle = $('<p/>', {
    class: "searchPageFindSectionCountrySelectTitle",
    id: "searchPageFindSectionCountrySelectTitle",
    text: "choose the country",
  });
  return searchPageFindSectionCountrySelectTitle;
}

function createSearchPageFindSectionSpecializationSelectTitle() {
  var searchPageFindSectionSpecializationSelectTitle = $('<p/>', {
    class: "searchPageFindSectionSpecializationSelectTitle",
    id: "searchPageFindSectionSpecializationSelectTitle",
    text: "choose the specialization",
  });
  return searchPageFindSectionSpecializationSelectTitle;
}

function candySearchPageGetSelectNameByValue(selectValue, selectList) {
  for (index = 0; index < selectList.length; index++) {
    var selectItem = selectList[index];
    if (selectItem.val == selectValue) {
      return selectItem.text;
    }
  }
}

function candySearchPageGetSelectValueByName(selectName, selectList) {
  for (index = 0; index < selectList.length; index++) {
    var selectItem = selectList[index];
    if (selectItem.text == selectName) {
      return selectItem.val;
    }
  }
}

function candySearchPageIsSelectNameExist(selectName, selectList) {
  for (index = 0; index < selectList.length; index++) {
    var selectItem = selectList[index];
    if (selectItem.text == selectName) {
      return true;
    }
  }
  return false;
}
//////////////////





function createLinkedinSearchPageFindButton(buttonId) {
  var linkedinSearchPageFindButton = $('<button/>', {
    class: "linkedinSearchPageFindButton",
    id: "linkedinSearchPageFindButton",
    text: 'Search',
  });
  return linkedinSearchPageFindButton;
}

function createSearchPageFindSection() {
  var searchPageFindSection = $('<div/>', {
    class: "candySearchPageFindSection",
    id: "candySearchPageFindSection",
  });
  return searchPageFindSection;
}




function createSearchPageListOfCandyjarDeveloperTags() {
  var listOfCandyjarDeveloperTags = $('<div/>',{
    class: "searchPageListOfCandyjarDeveloperTags",
    id: "searchPageListOfCandyjarDeveloperTags",
  });
  return listOfCandyjarDeveloperTags;
}

function createCandySearchSectionDeveloperTag(id, text) {
  var candyjarSearchSectionDeveloperTag = $('<span/>',{
    class: "candyjarSearchSectionDeveloperTag",
    id: id,
    text: text,
  });
  return candyjarSearchSectionDeveloperTag;
}


function candyLinkedinSearchAddPaginator(rootDivClas, candidates, candidatesSize) {
  var candyLinkedinSearchSimilarCandidatesResultsDiv = $('<div/>',{
    class: "candyLinkedinSearchSimilarCandidatesResultsDiv",
    id: "candyLinkedinSearchSimilarCandidatesResultsDiv",
  });
  $(rootDivClas).parent().prepend(candyLinkedinSearchSimilarCandidatesResultsDiv);

  var candyLinkedinSearchSimilarCandidatesData = $('<div/>',{
    class: "candyLinkedinSearchSimilarCandidatesData",
    id: "candyLinkedinSearchSimilarCandidatesData",
  });
  $("#candyLinkedinSearchSimilarCandidatesResultsDiv").prepend(candyLinkedinSearchSimilarCandidatesData);

  var candyLinkedinSearchSimilarCandidatesSize = $('<div/>',{
    class: "candyLinkedinSearchSimilarCandidatesSize",
    id: "candyLinkedinSearchSimilarCandidatesSize",
    text: "Showing " + candidatesSize + " results",
  });
  $("#candyLinkedinSearchSimilarCandidatesResultsDiv").prepend(candyLinkedinSearchSimilarCandidatesSize);


  var candyLinkedinSearchSimilarCandidatesPaginatorDiv = $('<div/>',{
    class: "candyLinkedinSearchSimilarCandidatesPaginatorDiv",
    id: "candyLinkedinSearchSimilarCandidatesPaginatorDiv",
  });
  $("#candyLinkedinSearchSimilarCandidatesResultsDiv").append(candyLinkedinSearchSimilarCandidatesPaginatorDiv);

  candyAddPaginator("#candyLinkedinSearchSimilarCandidatesData", "#candyLinkedinSearchSimilarCandidatesPaginatorDiv", candidates, 20);
  $( '.paginationjs' ).css( "display", "inline-block");
}


function candyLinkedinSearchVizualizeRelevantCandidates(relevantCandidates) {
  var elements = new Array();

  var addedAmount = 0;
  for (indexViz = 0; indexViz < relevantCandidates.length; indexViz++) {

    var relevantCandidate = relevantCandidates[indexViz];


    var url = "";
    if (relevantCandidate.accounts.linkedinHTML && relevantCandidate.accounts.linkedinHTML.length > 0) {
      url = relevantCandidate.accounts.linkedinHTML;
    } else {
      url = "https://candyjar.io/p/" + relevantCandidate.login;
    }

    var candyLinkedinSearchSimilarCandidateContainerDiv = $("<div />", {
      class: "candyLinkedinSearchSimilarCandidateContainerDiv",
      id: "candyLinkedinSearchSimilarCandidateContainerDiv" + indexViz,
    });
    $(".search-results-page").parent().append(candyLinkedinSearchSimilarCandidateContainerDiv);

    var candyLinkedinSearchSimilarCandidateDiv = $('<div/>',{
      class: "candyLinkedinSearchSimilarCandidateDiv",
      id: "candyLinkedinSearchSimilarCandidateDiv" + indexViz,
    });
    candyLinkedinSearchSimilarCandidateContainerDiv.append(candyLinkedinSearchSimilarCandidateDiv);


    var candyLinkedinSearchSimilarCandidateImgDiv = $('<img/>',{
      class: "candyLinkedinSearchSimilarCandidateImgDiv",
      id: "candyLinkedinSearchSimilarCandidateImgDiv" + indexViz,
      src: relevantCandidate.about.avatarUrl
    });
    candyLinkedinSearchSimilarCandidateDiv.append(candyLinkedinSearchSimilarCandidateImgDiv);

    var candyLinkedinSearchSimilarCandidateNamePositionDiv = $('<div/>',{
      class: "candyLinkedinSearchSimilarCandidateNamePositionDiv",
      id: "candyLinkedinSearchSimilarCandidateNamePositionDiv" + indexViz,
    });
    candyLinkedinSearchSimilarCandidateDiv.append(candyLinkedinSearchSimilarCandidateNamePositionDiv);

    var candyLinkedinSearchSimilarCandidateOpenButtonLink = $("<a />", {
      class: "candyLinkedinSearchSimilarCandidateOpenButtonLink",
      id: "candyLinkedinSearchSimilarCandidateOpenButtonLink" + indexViz,
      href: url,
      target: "_blank",
    });
    candyLinkedinSearchSimilarCandidateOpenButtonLink.css('text-decoration', 'none');
    candyLinkedinSearchSimilarCandidateDiv.append(candyLinkedinSearchSimilarCandidateOpenButtonLink);


    var candyLinkedinSearchSimilarCandidateOpenButtonDiv = $('<div/>',{
      class: "candyLinkedinSearchSimilarCandidateOpenButtonDiv",
      id: "candyLinkedinSearchSimilarCandidateOpenButtonDiv" + indexViz,
    });
    candyLinkedinSearchSimilarCandidateOpenButtonLink.append(candyLinkedinSearchSimilarCandidateOpenButtonDiv);


    var candyLinkedinSearchSimilarCandidateOpenButton = $('<button/>',{
      class: "candyLinkedinSearchSimilarCandidateOpenButton",
      id: "candyLinkedinSearchSimilarCandidateOpenButton" + indexViz,
      text: "Open",
      click: function () {
        var win = window.open(url, '_blank');
        if (win) {win.focus();}
      }
    });
    candyLinkedinSearchSimilarCandidateOpenButtonDiv.append(candyLinkedinSearchSimilarCandidateOpenButton);



    var candyLinkedinSearchSimilarCandidateLinkDiv = $("<a />", {
      class: "candyLinkedinSearchSimilarCandidateLinkDiv",
      id: "candyLinkedinSearchSimilarCandidateLinkDiv" + indexViz,
      href: url,
      target: "_blank",
    });
    candyLinkedinSearchSimilarCandidateNamePositionDiv.append(candyLinkedinSearchSimilarCandidateLinkDiv);


    var name = "...";
    if (relevantCandidate.about.name && relevantCandidate.about.name.length > 0) {
      name = relevantCandidate.about.name;
    }
    var candyLinkedinSearchSimilarCandidateNameDiv = $('<div/>',{
      class: "candyLinkedinSearchSimilarCandidateNameDiv",
      id: "candyLinkedinSearchSimilarCandidateNameDiv" + indexViz,
      text: name
    });
    candyLinkedinSearchSimilarCandidateLinkDiv.append(candyLinkedinSearchSimilarCandidateNameDiv);


    var currentCompany = relevantCandidate.about.currentCompany;
    var currentPosition = relevantCandidate.about.currentPosition;
    var currentPositionCompany = currentPosition;
    if (currentCompany.length) {
      currentPositionCompany = currentPosition + " at " + currentCompany;
    }

    var candyLinkedinSearchSimilarCandidatePositionDiv = $('<p/>',{
      class: "candyLinkedinSearchSimilarCandidatePositionDiv",
      id: "candyLinkedinSearchSimilarCandidatePositionDiv" + indexViz,
      text: currentPositionCompany,
    });
    candyLinkedinSearchSimilarCandidateNamePositionDiv.append(candyLinkedinSearchSimilarCandidatePositionDiv);



    var location = relevantCandidate.about.location;
    var candyLinkedinSearchSimilarCandidateLocationDiv = $('<p/>',{
      class: "candyLinkedinSearchSimilarCandidateLocationDiv",
      id: "candyLinkedinSearchSimilarCandidateLocationDiv" + indexViz,
      text: location,
    });
    candyLinkedinSearchSimilarCandidateNamePositionDiv.append(candyLinkedinSearchSimilarCandidateLocationDiv);




    var candyLinkedinSearchSectionDiv = $('<div/>',{
      class: "candyLinkedinSearchSectionDiv",
      id: "candyjarSectionDiv" + indexViz,
    });
    candyLinkedinSearchSimilarCandidateNamePositionDiv.append(candyLinkedinSearchSectionDiv);

    $("#candyjarSectionDiv" + indexViz).css("border-width", "0px");
    $(".candyLinkedinSearchSectionDiv").css("margin-top", "20px");

    var candyjarLogin = relevantCandidate.login;
    var topTags = relevantCandidate.top_tags;
    var accounts = relevantCandidate.accounts;
    var about = relevantCandidate.about;
    vizualizeSocialsSectiion(candyjarLogin, about, accounts, topTags, indexViz);
    $(".candyjarDeveloperTag").css("font-size", "10px");
    $(".candyjarSocialsDiv2").css("padding", "0px");
    $(".candyjarSocialsDiv2").css("padding-top", "5px");
    $(".candyjarSocialsDiv2").css("padding-bottom", "5px");
    $(".candyjarSocialsDiv").css("background-color", "white");
    $(".listOfCandyjarDeveloperTags").css("padding", "0px");


    addedAmount++;

    elements.push(candyLinkedinSearchSimilarCandidateContainerDiv.html());
    $("#candyLinkedinSearchSimilarCandidateContainerDiv" + indexViz).remove();

  }
  return elements;
}
