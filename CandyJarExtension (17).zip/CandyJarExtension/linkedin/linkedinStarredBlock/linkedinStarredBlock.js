document.getElementsByTagName("head")[0].insertAdjacentHTML("beforeend", "<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\" />");

function createCandyStarredBlock(parentDiv, candidate) {
  var linkedinStarredBlock = $('<div>',{
    class: "linkedinStarredBlock",
    id: "linkedinStarredBlock" + candidate.login
  });
  parentDiv.append(linkedinStarredBlock);

  //chrome.runtime.onMessage.addListener(backgroundPageMessagesListener);

  var linkedinStarredBlockSpan = $('<span>',{
    class: "linkedinStarredBlockSpan fa fa-star",
    id: "linkedinStarredBlockSpan" + candidate.login,
    click: function () {
      if ($(".linkedinStarDeveloperLoadAnimationDiv").length) {
        return;
      }
      linkedinStarredBlock.append(createLinkedinStarToDeveloperLoaderAnimationDiv());
      if($(this).css("color") == "rgb(221, 221, 221)") {
        chrome.runtime.sendMessage({from: "linkedin_profile", type: "add_star_to_candidate", github_id: candidate.github_id, is_star: true}, function(response) {});
        //addStarToCandidate(candidate.github_id, true, linkedinStarredBlockCallbackFunction);
        $(this).css("color", "orange");
        candidate.is_starred = 1;
      } else {
        chrome.runtime.sendMessage({from: "linkedin_profile", type: "add_star_to_candidate", github_id: candidate.github_id, is_star: false}, function(response) {});
        //addStarToCandidate(candidate.github_id, false, linkedinStarredBlockCallbackFunction);
        $(this).css("color", "rgb(221, 221, 221)");
        candidate.is_starred = 0;
      }

    }
  });
  linkedinStarredBlock.append(linkedinStarredBlockSpan);
  if (candidate.is_starred && candidate.is_starred == 1) {
    $('#linkedinStarredBlockSpan' + candidate.login).css("color", "orange");
  }

}

function createLinkedinStarToDeveloperLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "linkedinStarDeveloperLoadAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

// function linkedinStarredBlockCallbackFunction() {
//     $(".linkedinStarDeveloperLoadAnimationDiv").remove();
// }
