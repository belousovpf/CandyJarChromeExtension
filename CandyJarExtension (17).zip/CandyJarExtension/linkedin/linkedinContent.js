// GLOBAL VARIABLES //
var currentUrl = "";
var currentPage = "linkedin";
//var pagesCount = 0;
//////////////////////

// START EXECUTION //
execute();
/////////////////////


function execute(){
  if (authorizationInfo == 0) {
    chrome.runtime.sendMessage({from: "linkedin_content", type: "authorization_request"}, function(response) {
      authorizationInfo = response;
    });
  }
  if (currentUrl != document.location.href || $('.candyjarSectionDiv').length == 0) {
    //pagesCount++;
    currentUrl = document.location.href;
    removeCandyjarElements();
    startLinkedinProfilePage(currentUrl);
  }
  //startLinkedinSearchPage(currentUrl);


  setTimeout(execute, 2000);
}

function responseCallback(responseObject) {
}



function removeCandyjarElements() {
  $("#candyjarButton").remove();
  $("#candyjarSectionDiv").remove();
  $("#candyLinkedinProfileCreateButton").remove();
  $("#candyLinkedinProfilePdfButton").remove();
  $("#candyjarSimilarCandidatesDiv").remove();
  $("#candySearchPageFindSection").remove();
  $("#linkedinProfileCandidateCard").remove();
  $(".candyjarCardRankDiv").remove();
  $('.candyjarEmailsButton').remove();
  $('.linkedinStarredBlock').remove();
  messagesCount = 0;
}

// var currentCandidate = "";
// function listenerFunction(request, sender, sendResponse) {
//   if (request.from == "popup_script") {
//     if (currentCandidate != "") {
//       sendResponse(currentCandidate);
//     }
//   }
// };
// chrome.runtime.onMessage.addListener(listenerFunction);
