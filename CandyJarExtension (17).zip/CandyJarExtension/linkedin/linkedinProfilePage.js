var messagesCount = 0;
var requestSended = false;

function startLinkedinProfilePage(currentUrl) {
  if ($('.justify-flex-end > div').length == 0 || $("#experience-section").length == 0) {
    return;
  };
  if ($('.candyjarSectionDiv').length) {
    return;
  };
  if (requestSended) {
    return;
  }

  chrome.runtime.onMessage.addListener(backgroundPageMessagesListener);


  requestSended = true;
  var requestString = getSearchByTagRequestString(getLinkedinLoginTagFromProfilePage(), true, "linkedin_profile");
  chrome.runtime.sendMessage({from: "linkedin_profile", type: "execute_get_request", requestString: requestString}, function(response) {});

}


function sendMessageToGoogleApi(developerAboutSection) {
  emailsSet = getEmailsSet(developerAboutSection);
  emails = [];
  for ( mail of emailsSet) {
      emails.push(mail);
  }
  chrome.runtime.sendMessage({from: "linkedin_profile", type: "get_messages_request", emails: emails}, function(response) {});
}

function backgroundPageMessagesListener(request, sender, sendResponse) {
  if (request.from == "popup_script") {
    sendResponse({'developerTag': getLinkedinLoginTagFromProfilePage(), 'website_name': 'linkedin_profile'});
  }

  if (request.from == "background" && request.type == "get_messages_request") {
    messagesCount += request.response.resultSizeEstimate;
    if (messagesCount > 0) {
      $('.candyjarEmailsButton').text("gmail (" + messagesCount + ")");
      $('.candyjarEmailsButton').css("display","");
    };
    sendResponse("ok");
  };

  if (request.type == "add_star_to_candidate") {
    $(".linkedinStarDeveloperLoadAnimationDiv").remove();
    sendResponse("ok");
  };

  if (request.type == "get_similar_candidates") {
    similarCandidatesCallbackOk(request.response);
    sendResponse("ok");
  };
  if (request.type == "execute_get_request_pdf") {
    createPDF(request.response);
    sendResponse("ok");
  };

  if (request.type == "generateLetterRequest") {
    generateLetterRequestSuccess(request.response, request.candidate);
    sendResponse("ok");
  };

  if (request.type == "updateUserInfoRequest") {
    updateUserInfoRequestSuccess(request.response, request.candidate, $('#'+request.parentDivId+''), request.letterText),
    sendResponse("ok");
  };

  if (request.type == "moveDeveloperToMyAtsVacancyRequest") {
    moveDeveloperToMyAtsVacancySuccess(request.response, request.candidate, $('#'+request.parentDivId+''), $('#'+request.tooltipLoaderDivId+''));
    sendResponse("ok");
  };
  if (request.type == "createAndMoveDeveloperMyAtsVacancyRequest") {
    createAndMoveDeveloperMyAtsVacancySuccess(request.response, request.candidate, $('#'+request.parentDivId+''), $('#'+request.newVacancyTooltipDivFooterBlockLoaderDivId+''));
    sendResponse("ok");
  };
  if (request.type == "deleteDeveloperFromMyAtsVacancyRequest") {
    deleteDeveloperFromMyAtsVacancySuceess(request.response, request.candidate, request.vacancyStep, $('#'+request.parentDivId+''), $('#'+request.cardCandidateVacancyTooltipLoaderDivId+''));
    sendResponse("ok");
  };
  if (request.type == "moveDeveloperToMyAtsVacancyStepRequest") {
    moveDeveloperToMyAtsVacancyStepSuccess(request.response, request.candidate, request.vacancyStep, $('#'+request.loaderDivId+''), $('#'+request.tooltipParentDivId+''));
    sendResponse("ok");
  };
  if (request.type == "addStarToCandidateRequest") {
    starredBlockCallbackFunction();
    sendResponse("ok");
  };

  if (request.from == "background" && request.type == "execute_get_request") {
    requestSended = false;
    if (request.response.data.search.length > 0) {
      var candidate = request.response.data.search[0];
        visualizeCandyjarElements(candidate);
        //if (pagesCount == 1) {
          result = parseLinkedin();
          result.tag = getLinkedinLoginTagFromProfilePage();
          result.type = "update";
          result.website = "linkedin";
          // console.log("result = ");
          // console.log(result);
          sendPostDataToServer(result);
          sendMessageToGoogleApi(candidate.about);
        //};
    } else {
        //if (pagesCount == 1) {
          $(".justify-flex-end > div").prepend(createCandyLinkedinProfileCreateButton(currentUrl));
          $("#candyLinkedinProfileCreateButton").click();
          setTimeout(getRequestAgain, 2000);
        //}
    }
    sendResponse("ok");
  };

};

function getEmailsSet(developerAboutSection) {
  const mails = new Set();
  if (developerAboutSection.email && developerAboutSection.email.length > 0) {
    if (isValidEmail(developerAboutSection.email)) {
      mails.add(developerAboutSection.email);
    }
  }
  if (developerAboutSection.emails && developerAboutSection.emails.length > 0) {
      for (index = 0; index < developerAboutSection.emails.length; index++) {
        if (isValidEmail(developerAboutSection.emails[index])) {
          mails.add(developerAboutSection.emails[index]);
        }
      }
  }
  return mails;
}



function getRequestAgain() {

  //chrome.runtime.onMessage.addListener(backgroundPageMessagesListener);

  var requestString = getSearchByTagRequestString(getLinkedinLoginTagFromProfilePage(), false, "linkedin_profile");
  chrome.runtime.sendMessage({from: "linkedin_profile", type: "execute_get_request", requestString: requestString}, function(response) {});
}

function getLinkedinLoginTagFromProfilePage() {
  var url = document.location.href;
  return getLinkedinLoginFromUrl(url);
}

function getLinkedinLoginFromUrl(pUrl) {
  var url = pUrl;
  url = removeWrongPartFromUrl(url);
  url = url.replace("https://www.ru.linkedin.com/in/","");
  url = url.replace("http://www.ru.linkedin.com/in/","");
  url = url.replace("https://www.linkedin.com/in/","");
  url = url.replace("http://www.linkedin.com/in/","");
  url = url.replace("/","");
  url += "ldn";
  url = url.toLowerCase();
  return url;
}

function removeWrongPartFromUrl(url) {
  var result = "";
  var slashCounts = 0;
  for (var i = 0; i < url.length; i++) {
    if (slashCounts == 5) {
      continue;
    }
    word = url.charAt(i);
    if (word == '/') {
      slashCounts++;
    };
    result += word;
  }
  return result;
}



function visualizeCandyjarElements(candidate) {

  var candyjarLogin = candidate.login;
  var topTags = candidate.top_tags;
  var accounts = candidate.accounts;
  var about = candidate.about;
  var githubMetrics = candidate.github_metrics;
  var tagsCount = candidate.tags_count;

  // if (!$('#candyLinkedinProfilePdfButton').length) {
  //   $(".justify-flex-end > div").prepend(createCandyLinkedinProfilePdfButton(getLinkedinLoginTagFromProfilePage()));
  // }

  if (!$('#candyLinkedinProfileSourcingButton').length) {
    $(".justify-flex-end > div").prepend(createCandyLinkedinProfileSourcingButton());
  }

  // if (!$('#candyjarButton').length) {
  //   $(".justify-flex-end > div").prepend(createCandyjarButton('https://candyjar.io/p/' + candyjarLogin));
  // }

  // if (!$('#candyjarEmailsButton').length) {
  //   $(".justify-flex-end > div").prepend(createEmailsButton());
  // }




  if (!$('#candyjarSectionDiv').length) {
    $(".profile-detail").prepend(createCandyjarSectionDiv(""));
    //vizualizeSocialsSectiion(candyjarLogin, about, accounts, topTags, "", 'linkedin_profile');
  }

// console.log("candidate = ");
// console.log(candidate);
  if (!$('#linkedinProfileCandidateCard').length) {
    var linkedinProfileCandidateCard = $('<div>',{
      class: "linkedinProfileCandidateCard",
      id: "linkedinProfileCandidateCard"
    });
    $(".profile-detail").prepend(linkedinProfileCandidateCard);
    createCandidateCard(linkedinProfileCandidateCard, candidate, [], [])
  }

  // if (!$('#candyjarSimilarCandidatesDiv').length) {
  //   addCandyLinkedinProfileSimilarCandidatesSection(".pv-content__right-rail");
  // }

  createLinkedinSimilarCandidatesBlockBlock($('.pv-content__right-rail'), candidate);


  // if (!$('#candyjarCardRankDiv').length) {
  //   var element = $(".justify-flex-end").parent().parent().parent();
  //   createCandyStarredBlock(element, candidate);
  //   addCandyjarCardRankDiv(element, candyjarLogin, tagsCount, githubMetrics);
  // }


}


// BUTTONS //
function createCandyLinkedinProfileCreateButton(currentUrl) {
  var candyLinkedinProfileCreateButton = $('<button/>', {
    class: "candyLinkedinProfileCreateButton",
    id: "candyLinkedinProfileCreateButton",
    text: 'Create profile',
    click: function () {
      var result = new Object();
      result.url = currentUrl;
      result.tag = getLinkedinLoginTagFromProfilePage();
      result.type = "create";
      result.website = "linkedin";
      sendPostDataToServer(result);
      $("#candyLinkedinProfileCreateButton").remove();
    }
  });
  return candyLinkedinProfileCreateButton;
}

function createCandyLinkedinProfilePdfButton(login) {
  var candyLinkedinProfilePdfButton = $('<button/>', {
    class: "candyLinkedinProfilePdfButton",
    id: "candyLinkedinProfilePdfButton",
    text: 'PDF',
    click: function () {
      if (checkSignInAndOpenWindow()) {
        var requestString = getSearchByTagFullRequestString(login, false, 'linkedin_profile', 'pdf_click');
        chrome.runtime.sendMessage({from: "linkedin_profile", type: "execute_get_request_pdf", requestString: requestString}, function(response) {});
      }
    }
  });
  return candyLinkedinProfilePdfButton;
}

function createCandyLinkedinProfileSourcingButton() {
  var candyLinkedinProfileSourcingButton = $('<button/>', {
    class: "candyLinkedinProfileSourcingButton",
    id: "candyLinkedinProfileSourcingButton",
    text: 'Sourcing',
    click: function () {
      chrome.runtime.sendMessage({from: "linkedin_profile", type: "goToCabinet"}, function(response) {});
    }
  });
  return candyLinkedinProfileSourcingButton;
}

function createCandyjarButton(url) {
  var candyjarButton = $('<button/>', {
    class: "candyjarButton",
    id: "candyjarButton",
    text: 'CandyJar',
    click: function () {
      if (checkSignInAndOpenWindow()) {
        var win = window.open(url, '_blank');
        if (win) {win.focus();}
        sendTagTypeWebsiteData(getLinkedinLoginTagFromProfilePage(), "candyjar-button-pressed", "linkedin");
      }
    }
  });
  return candyjarButton;
}

function createEmailsButton() {
  var emailsButton = $('<button/>', {
    class: "candyjarButton candyjarEmailsButton",
    id: "candyjarEmailsButton",
  }).css("display","none");


  return emailsButton;
}
//////////////

// SIMILAR CANDIDATES //
// function addCandyLinkedinProfileSimilarCandidatesSection(rootDivClass) {
//   var candySimilarCandidatesDiv = createCandyjarSimilarCandidatesDiv();
//   $(rootDivClass).prepend(candySimilarCandidatesDiv);
//
//   var findSimilarButton = createFindSimilarButton();
//   candySimilarCandidatesDiv.append(findSimilarButton);
//
//   findSimilarButton.click(function() {
//     if (checkSignInAndOpenWindow()) {
//       findSimilarButton.off();
//       findSimilarButton.text("Searching...");
//       var linkedinLoginTag = getLinkedinLoginTagFromProfilePage();
//       candyGetSimilarCandidatesByLoginTag(linkedinLoginTag, similarCandidatesOk, similarCandidatesFail);
//       sendTagTypeWebsiteData(linkedinLoginTag, "similar-button-pressed", "linkedin");
//     }
//   });
// }
//
// function similarCandidatesOk(relevantCandidates, relevantCandidatesTotalSize, currentCandidate, loginTag) {
//   if (relevantCandidates.length == 0) {
//     $('#candyjarFindSimilarButton').text("Not found...");
//     return;
//   }
//   $('#candyjarFindSimilarButton').text("Similar candidates (" + relevantCandidatesTotalSize + ")");
//   var relevantCandidatesContent = candyLinkedinProfileGetSimilarCandidatesContent("#candyjarSimilarCandidatesDiv", relevantCandidates);
//
//   var candyjarSimilarCandidatesResultsDiv = createCandyjarSimilarCandidatesResultsDiv();
//   $("#candyjarSimilarCandidatesDiv").append(candyjarSimilarCandidatesResultsDiv);
//
//   var candyjarSimilarCandidatesPaginatorDiv = createCandyjarSimilarCandidatesPaginatorDiv();
//   $("#candyjarSimilarCandidatesDiv").append(candyjarSimilarCandidatesPaginatorDiv);
//
//   candyAddPaginator("#candyjarSimilarCandidatesResultsDiv", "#candyjarSimilarCandidatesPaginatorDiv", relevantCandidatesContent, 5);
//   $('.paginationjs').css("display", "inline-block");
// }
//
// function similarCandidatesFail(login, candidate) {
//   var linkedinLoginTag = getLinkedinLoginTagFromProfilePage();
//   candyGetSimilarCandidatesByLoginTag(linkedinLoginTag, similarCandidatesOk, similarCandidatesFail);
// }
//
// function createCandyjarSimilarCandidatesDiv() {
//   var candySimilarCandidatesDiv = $('<div/>',{
//     class: "candyjarSimilarCandidatesDiv",
//     id: "candyjarSimilarCandidatesDiv",
//   });
//   return candySimilarCandidatesDiv;
// }
//
// function createCandyjarSimilarCandidatesResultsDiv() {
//   var candyjarSimilarCandidatesResultsDiv = $('<div/>',{
//     class: "candyjarSimilarCandidatesResultsDiv",
//     id: "candyjarSimilarCandidatesResultsDiv",
//   });
//   return candyjarSimilarCandidatesResultsDiv;
// }
//
// function createCandyjarSimilarCandidatesPaginatorDiv() {
//   var candyjarSimilarCandidatesPaginatorDiv = $('<div/>',{
//     class: "candyjarSimilarCandidatesPaginatorDiv",
//     id: "candyjarSimilarCandidatesPaginatorDiv",
//   });
//   return candyjarSimilarCandidatesPaginatorDiv;
// }
//
// function createFindSimilarButton() {
//   var candyjarFindSimilarButton = $('<button/>', {
//     class: "candyjarFindSimilarButton",
//     id: "candyjarFindSimilarButton",
//     text: "Similar candidates"
//   });
//   return candyjarFindSimilarButton;
// }
//
// function candyLinkedinProfileGetSimilarCandidatesContent(rootDivId, relevantCandidates) {
//   var elements = new Array();
//
//
//   var addedAmount = 0;
//   for (indexViz = 0; indexViz < relevantCandidates.length; indexViz++) {
//
//     var relevantCandidate = relevantCandidates[indexViz];
//
//
//     var url = "";
//     if (relevantCandidate.accounts.linkedinHTML && relevantCandidate.accounts.linkedinHTML.length > 0) {
//       url = relevantCandidate.accounts.linkedinHTML;
//     } else {
//       url = "https://candyjar.io/p/" + relevantCandidate.login;
//     }
//
//     var candyjarSimilarCandidateContainerDiv = $("<div />", {
//       class: "candyjarSimilarCandidateContainerDiv",
//       id: "candyjarSimilarCandidateContainerDiv" + indexViz,
//     });
//     $(rootDivId).append(candyjarSimilarCandidateContainerDiv);
//
//     var candyjarSimilarCandidateLinkDiv = $("<a />", {
//       class: "candyjarSimilarCandidateLinkDiv",
//       id: "candyjarSimilarCandidateLinkDiv" + indexViz,
//       href: url,
//       target: "_blank",
//     });
//     $("#candyjarSimilarCandidateContainerDiv" + indexViz).append(candyjarSimilarCandidateLinkDiv);
//
//     var candyjarSimilarCandidateDiv = $('<div/>',{
//       class: "candyjarSimilarCandidateDiv",
//       id: "candyjarSimilarCandidateDiv" + indexViz,
//     });
//     $("#candyjarSimilarCandidateLinkDiv" + indexViz).append(candyjarSimilarCandidateDiv);
//
//
//     var candyjarSimilarCandidateImgDiv = $('<img/>',{
//       class: "candyjarSimilarCandidateImgDiv",
//       id: "candyjarSimilarCandidateImgDiv" + indexViz,
//       src: relevantCandidate.about.avatarUrl
//     });
//     $("#candyjarSimilarCandidateDiv" + indexViz).append(candyjarSimilarCandidateImgDiv);
//
//     var candyjarSimilarCandidateNamePositionDiv = $('<div/>',{
//       class: "candyjarSimilarCandidateNamePositionDiv",
//       id: "candyjarSimilarCandidateNamePositionDiv" + indexViz,
//     });
//     $("#candyjarSimilarCandidateDiv" + indexViz).append(candyjarSimilarCandidateNamePositionDiv);
//
//     var name = "...";
//     if (relevantCandidate.about.name && relevantCandidate.about.name.length > 0) {
//       name = relevantCandidate.about.name;
//     }
//     var candyjarSimilarCandidateNameDiv = $('<div/>',{
//       class: "candyjarSimilarCandidateNameDiv",
//       id: "candyjarSimilarCandidateNameDiv" + indexViz,
//       text: name
//     });
//     $("#candyjarSimilarCandidateNamePositionDiv" + indexViz).append(candyjarSimilarCandidateNameDiv);
//
//     var currentPosition = relevantCandidate.about.currentPosition;
//     if (currentPosition && currentPosition.length > 28) {
//       currentPosition = currentPosition.substring(0,27) + "..";
//     }
//     var candyjarSimilarCandidatePositionDiv = $('<p/>',{
//       class: "candyjarSimilarCandidatePositionDiv",
//       id: "candyjarSimilarCandidatePositionDiv" + indexViz,
//       text: currentPosition,
//     });
//     $("#candyjarSimilarCandidateNamePositionDiv" + indexViz).append(candyjarSimilarCandidatePositionDiv);
//
//     var currentCompany = "";
//     if (relevantCandidate.about.currentCompany && relevantCandidate.about.currentCompany.length > 0) {
//       currentCompany = relevantCandidate.about.currentCompany;
//       if (currentCompany.length > 28) {
//         currentCompany = currentCompany.substring(0,27) + "..";
//       }
//     }
//
//     if (currentCompany.length > 0) {
//       var candyjarSimilarCandidateCompanyDiv = $('<p/>',{
//         class: "candyjarSimilarCandidateCompanyDiv",
//         id: "candyjarSimilarCandidateCompanyDiv" + indexViz,
//         text: currentCompany,
//       });
//       $("#candyjarSimilarCandidateNamePositionDiv" + indexViz).append(candyjarSimilarCandidateCompanyDiv);
//
//     }
//     addedAmount++;
//
//     elements.push(candyjarSimilarCandidateContainerDiv.html());
//     $("#candyjarSimilarCandidateContainerDiv" + indexViz).remove();
//
//   }
//   return elements;
// }

////////////////////////
