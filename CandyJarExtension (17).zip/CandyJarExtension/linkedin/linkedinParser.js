function parseLinkedin() {
  var elements = $("code:contains('data')");

  var result = new Object();

  var avatar = $("img.pv-top-card-section__photo").attr('src');
  if (!avatar || avatar.length == 0) {
    avatar = $("img.pv-top-card__photo").attr('src');
  }
  if (avatar && avatar.length > 0) {
    if (!avatar.includes("gif;base64")) {
      result.avatar = avatar;
    }
  }

  result.summary = getAboutFromPage();
  result.positions = getPositionsFromPage();
  result.educations = getEducationsFromPage();

  nameLocation = getNameLocationFromPage();
  result.location = nameLocation.location;
  result.firstName = nameLocation.firstName;
  result.lastName = nameLocation.lastName;


  // var positions = [];
  // var educations = [];
  //
  // var includedArray = [];
  // for (index = 0; index < elements.length; index++) {
  //   var obj = JSON.parse(elements[index].innerText);
  //   includedArray = obj.included;
  //   for (index2 = 0; index2 < includedArray.length; index2++) {
  //     analyzeAsSummaryObject(includedArray[index2], result);
  //     analyzeAsWorkExperienceObject(includedArray[index2], positions);
  //     analyzeAsEducationObject(includedArray[index2], educations);
  //   };
  //   result.positions = positions;
  //   result.educations = educations;
  //
  //   if (positions.length == 0 && educations.length == 0) {
  //     //result = new Object();
  //   } else {
  //     return result;
  //   }
  //
  // };

  return result;
}

function getNameLocationFromPage() {
  resultNameLocation = new Object();
  resultNameLocation.firstName = "";
  resultNameLocation.lastName = "";
  resultNameLocation.location = "";
  nameLocationDiv = $(".pv-top-card--list");
  if (!nameLocationDiv || nameLocationDiv.length != 2) {
    return result;
  }
  nameDiv = nameLocationDiv[0];
  locationDiv = nameLocationDiv[1];
  nameLines = $(nameDiv).find('li');
  if (nameLines.length) {
    nameString = deleteStartSpaces($(nameLines[0]).text());
    nameString = deleteEndSpaces(nameString);
    nameSurname = nameString.split(' ');
    if (nameSurname.length == 2) {
      resultNameLocation.firstName = nameSurname[0];
      resultNameLocation.lastName = nameSurname[1];
    }
  }

  locationLines = $(locationDiv).find('li');
  if (locationLines.length) {
    locationStr = deleteStartSpaces($(locationLines[0]).text());
    locationStr = deleteEndSpaces(locationStr);
    resultNameLocation.location = locationStr;
  }
  return resultNameLocation;
}

function getAboutFromPage() {
  about = '';
  var paragraph = $(".pv-about-section").text();
  arrayOfLines = paragraph.match(/[^\r\n]+/g);
  lines = [];
  for (index = 0; index < arrayOfLines.length; index++) {
    if (arrayOfLines[index].replace(/ /g, "") != "") {
      lines.push(arrayOfLines[index]);
    }
  }

  if (lines.length > 1 && lines[0].includes('About')) {
    for (index = 1; index < lines.length; index++) {
      if (lines[index].includes('see more')) {
        return about;
      }
      about += ' ' + deleteStartSpaces(lines[index]);
    }
  }
  return about;
}

function getEducationsFromPage() {
  educations = [];
  $("#education-section").find('ul > li').each(function () {
    var paragraph = $(this).text();
    arrayOfLines = paragraph.match(/[^\r\n]+/g);
    lines = [];
    for (index = 0; index < arrayOfLines.length; index++) {
      if (arrayOfLines[index].replace(/ /g, "") != "") {
        lines.push(arrayOfLines[index]);
        //console.log(index + ") " + arrayOfLines[index]);
      }
    }
    education = getEducationFromLine(lines);
    if (education.schoolName != "") {
      educations.push(education);
    }
  });
  educations = removeEducationsDuplicates(educations);
  return educations;
}

function getPositionsFromPage() {
  positions = [];
  previousCompanyName = "";
  $("#experience-section").find('ul > li').each(function () {
    var paragraph = $(this).text();
    arrayOfLines = paragraph.match(/[^\r\n]+/g);
    lines = [];
    for (index = 0; index < arrayOfLines.length; index++) {
      if (arrayOfLines[index].replace(/ /g, "") != "") {
        lines.push(arrayOfLines[index]);
        //console.log(index + ") " + arrayOfLines[index]);
      }
    }
    position = getPositionFromLine(lines);
    if (position.companyName == "") {
      position.companyName = previousCompanyName;
    } else {
      previousCompanyName = position.companyName;
    }
    positions.push(position);
    //console.log(position);
  });
  positions = removePositionsDuplicates(positions);
  return positions;
}

function getEducationFromLine(workLines) {
  education = new Object();
  education.degreeName = ""
  education.schoolName = ""
  education.fieldOfStudy = ""
  education.description = ""
  education.startYear = 0
  education.endYear = 0

  for (index = 0; index < workLines.length; index++) {
    workLine = workLines[index].replace(/ /g, "").toLowerCase();
    if (workLine == "degreename" && workLines[index-1] && workLines[index-1].length && education.schoolName == "" && workLines[index+1] && workLines[index+1].length) {
      education.schoolName = deleteStartSpaces(workLines[index-1]);
      education.degreeName =  deleteStartSpaces(workLines[index+1]);
    }
    if (workLine == "fieldofstudy" && education.fieldOfStudy == "" && workLines[index+1] && workLines[index+1].length) {
      education.fieldOfStudy = deleteStartSpaces(workLines[index+1]);
    }
    if (workLine == "datesattendedorexpectedgraduation" && workLines[index+1] && workLines[index+1].length && education.startYear == 0 && education.endYear == 0) {
      period = parsePeriod(workLines[index+1]);
      education.startYear = period.startYear;
      education.endYear = period.endYear;
    }

  }

  return education;
}

function removeEducationsDuplicates(educations) {
  uniqueEducations = [];
  for (index5 = 0; index5 < educations.length; index5++) {
    education = educations[index5];
    isExist = false;
    for (index6 = 0; index6 < uniqueEducations.length; index6++) {
      uniqueEducation = uniqueEducations[index6];
      if (education.degreeName == uniqueEducation.degreeName
          && education.schoolName == uniqueEducation.schoolName
          && education.startYear == uniqueEducation.startYear
          && education.endYear == uniqueEducation.endYear) {
            isExist = true;
          }
    }
    if (!isExist) {
      uniqueEducations.push(education);
    }
  }
  return uniqueEducations;
}

function removePositionsDuplicates(positions) {
  uniquePositions = [];
  for (index4 = 0; index4 < positions.length; index4++) {
    position = positions[index4];
    isExist = false;
    for (index5 = 0; index5 < uniquePositions.length; index5++) {
      uniquePosition = uniquePositions[index5];
      if (position.companyName == uniquePosition.companyName
          && position.title == uniquePosition.title
          && position.startYear == uniquePosition.startYear
          && position.endYear == uniquePosition.endYear) {
            isExist = true;
          }
    }
    if (!isExist) {
      uniquePositions.push(position);
    }
  }
  return uniquePositions;
}



function getPositionFromLine(workLines) {
  position = new Object();
  position.companyName = "";
  position.title = "";
  position.description = "";
  position.startYear = 0;
  position.endYear = 0;
  position.locationName = "";

  for (index = 0; index < workLines.length; index++) {
    workLine = workLines[index].replace(/ /g, "").toLowerCase();
    if (workLine == "companyname" && workLines[index+1] && workLines[index+1].length && position.companyName == "") {
      position.companyName = deleteStartSpaces(workLines[index+1]);
      if (index == 1 && position.title == "") {
        position.title = deleteStartSpaces(workLines[0]);
      }
    }
    if (workLine == "title" && workLines[index+1] && workLines[index+1].length && position.title == "") {
      position.title = deleteStartSpaces(workLines[index+1]);
    }
    if (workLine == "location" && workLines[index+1] && workLines[index+1].length && position.locationName == "") {
      position.locationName = deleteStartSpaces(workLines[index+1]);
      if (workLines[index+2] && workLines[index+2].length && position.description == "" && workLines[index+2].replace(/ /g, "").toLowerCase() != "title") {
        position.description = deleteStartSpaces(workLines[index+2]);
      }
    }
    if (workLine == "datesemployed" && workLines[index+1] && workLines[index+1].length && position.startYear == 0 && position.endYear == 0) {
      period = parsePeriod(workLines[index+1]);
      position.startYear = period.startYear;
      position.endYear = period.endYear;

    }
    if (workLine == "employmentduration" && workLines[index+2] && workLines[index+2].length && workLines[index+2].replace(/ /g, "").toLowerCase() != "location" && position.description == "") {
      position.description = deleteStartSpaces(workLines[index+2]);
    }
  }
  return position;
}

function deleteStartSpaces(str) {
  result = "";
  for (index2 = 0; index2 < str.length; index2++) {
    word = str[index2];
    if ((word == ' ' || word == '\n' || word == '\r') && result == '') {
      continue;
    }
    result += word;
  }
  return result;
}

function deleteEndSpaces(str) {
  result = "";
  for (index2 = str.length -1 ; index2 >= 0; index2--) {
    word = str[index2];
    if ((word == ' ' || word == '\n' || word == '\r') && result == '') {
      continue;
    }
    result = word + result;
  }
  return result;
}

function parsePeriod(period) {
  result = new Object;
  result.startYear = 0;
  result.endYear = 0;
  arrayOfStrings = period.split('–');
  if (arrayOfStrings.length != 2) {
    return result;
  }
  startPeriod = arrayOfStrings[0];
  endPeriod = arrayOfStrings[1];

  currentYear = new Date().getFullYear();

  for (index1 = 1990; index1 <= currentYear; index1++) {
    if (startPeriod.includes(index1)) {
      result.startYear = index1;
    }
    if (endPeriod.includes(index1)) {
      result.endYear = index1;
    }
  }
  if (endPeriod.toLowerCase().includes('present')) {
      result.endYear = currentYear;
  }
  return result;
}

function parseLinkedin2() {
  var elements = $("code:contains('data')");

  var result = new Object();
  var positions = [];
  var educations = [];

  var includedArray = [];
  var maxElementsInIncludedArray = 0;
  for (index = 0; index < elements.length; index++) {
    var obj = JSON.parse(elements[index].innerText);
    if (obj.included.length > maxElementsInIncludedArray) {
      includedArray = obj.included;
      maxElementsInIncludedArray = obj.included.length;
    }
  };
  for (index = 0; index < includedArray.length; index++) {
    analyzeAsSummaryObject(includedArray[index], result);
    analyzeAsWorkExperienceObject(includedArray[index], positions);
    analyzeAsEducationObject(includedArray[index], educations);
  };
  result.positions = positions;
  result.educations = educations;

  return result;
}

function analyzeAsSummaryObject(obj, result) {
  var count = 0
  var minCount = 5
  var localSummary = ""
  var localLocation = ""
  var localFirstName = ""
  var localLastName = ""
  var localHeadline = ""

  if (obj.summary) {      count++; localSummary = obj.summary;}
  if (obj.lastName) {     count++; localLastName = obj.lastName;}
  if (obj.locationName) { count++; localLocation = obj.locationName;}
  if (obj.firstName) {    count++; localFirstName = obj.firstName;}
  if (obj.headline) {     count++; localHeadline = obj.headline;}
  if (obj.location) {     count++;}
  if (obj.birthDateOn) {  count++;}
  if (obj.multiLocalePhoneticLastName) {count++;}

  if (count >= minCount) {
    result.summary = localHeadline + ". " + localSummary;
    result.location = localLocation;
    result.firstName = localFirstName;
    result.lastName = localLastName;
  }
}

function analyzeAsWorkExperienceObject(obj, positions) {
    var count = 0
    var minCount = 3
    var title = ""
    var companyName = ""
    var description = ""
    var startYear = 0
    var endYear = 0
    var locationName = ""

    if (obj.title) {count++; title = obj.title;}
    if (obj.companyName) {count++; companyName = obj.companyName;}
    if (obj.description) {count++; description = obj.description;}
    if (obj.locationName) {count++; locationName = obj.locationName;}
    if (obj.timePeriod) {
      count++;
      startYear = getStartYear(obj.timePeriod);
      endYear = getEndYear(obj.timePeriod);
    }
    if (obj.dateRange) {
      count++;
      startYear = getStartYearFromDateRange(obj.dateRange);
      endYear = getEndYearFromDateRange(obj.dateRange);
    }

    if (count >= minCount && companyName.length > 0) {
      positions.push({
        companyName: companyName,
        title: title,
        description: description,
        startYear: startYear,
        endYear: endYear,
        locationName: locationName,
      });
    }
}

function analyzeAsEducationObject(obj, educations) {
    var count = 0
    var minCount = 3
    var degreeName = ""
    var schoolName = ""
    var fieldOfStudy = ""
    var startYear = 0
    var endYear = 0

    if (obj.degreeName) {count++; degreeName = obj.degreeName;}
    if (obj.schoolName) {count++; schoolName = obj.schoolName;}
    if (obj.fieldOfStudy) {count++; fieldOfStudy = obj.fieldOfStudy;}
    if (obj.timePeriod) {
      count++;
      startYear = getStartYear(obj.timePeriod);
      endYear = getEndYear(obj.timePeriod);
    }
    if (obj.dateRange) {
      count++;
      startYear = getStartYearFromDateRange(obj.dateRange);
      endYear = getEndYearFromDateRange(obj.dateRange);
    }

    if (count >= minCount) {
      educations.push({
        schoolName: schoolName,
        fieldOfStudy: fieldOfStudy,
        degreeName: degreeName,
        description: "",
        startYear: startYear,
        endYear: endYear,
      });
    }
}

function getStartYear(obj) {
  if (obj && obj.startDate && obj.startDate.year) {
    return  obj.startDate.year;
  } else {
    return 0;
  }
}

function getStartYearFromDateRange(obj) {
  if (obj && obj.start && obj.start.year) {
    return  obj.start.year;
  } else {
    return 0;
  }
}

function getEndYear(obj) {
  if (obj && obj.endDate && obj.endDate.year) {
    return  obj.endDate.year;
  } else {
    return 0;
  }
}

function getEndYearFromDateRange(obj) {
  if (obj && obj.end && obj.end.year) {
    return  obj.end.year;
  } else {
    return 0;
  }
}
