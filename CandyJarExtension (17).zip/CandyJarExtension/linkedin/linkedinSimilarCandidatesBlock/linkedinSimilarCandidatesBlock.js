var currentCandidateInSimilars = {};

function createLinkedinSimilarCandidatesBlockBlock(parentDiv, candidate) {
  if (!candidate) {
    return;
  }
  if ($('#linkedinSimilarCandidatesBlock').length) {
    return;
  }
  if (!candidate.about || !candidate.about.country || candidate.about.country == "") {
    return;
  }
  if (!candidate.about || !candidate.about.specialization || candidate.about.specialization == "") {
    return;
  }

  currentCandidateInSimilars = candidate;

  var candySimilarCandidatesDiv = $('<div/>',{
    class: "linkedinSimilarCandidatesBlock",
    id: "linkedinSimilarCandidatesBlock",
  });
  parentDiv.prepend(candySimilarCandidatesDiv);

  var linkedinSimilarCandidatesButton = $('<button/>', {
    class: "linkedinSimilarCandidatesButton",
    id: "linkedinSimilarCandidatesButton",
    text: "Similar candidates",
    click: function () {
      if (isSignInAndHaveDays()) {
        $(this).off();
        $(this).text("Searching...");
        chrome.runtime.sendMessage({type: "get_similar_candidates", candidate: candidate, from: 'linkedin_profile'}, function(response) {});
      } else {
        $('.linkedinSimilarCandidatesButton').tooltipster('hide');
        $(this).tooltipster('show');
        $(this).tooltipster('content', createNeedToUpgradeBlockDiv(linkedinSimilarCandidatesButton));
      }
    }
  });
  candySimilarCandidatesDiv.append(linkedinSimilarCandidatesButton);
  if (!isSignInAndHaveDays()) {
    createNeedToUpgradeBlockTooltip(linkedinSimilarCandidatesButton);
  }
}

var linkedinSimilarCandidates = [];

function similarCandidatesCallbackOk(pSimilarCandidates) {
  if (pSimilarCandidates.length == 0 || !currentCandidateInSimilars.login) {
    $('#linkedinSimilarCandidatesButton').text("Not found...");
    return;
  }

  var similarCandidates = [];
  for (index = 0; index < pSimilarCandidates.length; index++) {
    if (currentCandidateInSimilars.login == pSimilarCandidates[index].login) {
      continue;
    }
    similarCandidates.push(pSimilarCandidates[index]);
  }

  $('#linkedinSimilarCandidatesButton').text("Similar candidates (" + similarCandidates.length + ")");
  //var relevantCandidatesContent = candyLinkedinProfileGetSimilarCandidatesContent("#candyjarSimilarCandidatesDiv", relevantCandidates);

  var linkedinSimilarCandidatesResultsDiv = $('<div/>',{
    class: "linkedinSimilarCandidatesResultsDiv",
    id: "linkedinSimilarCandidatesResultsDiv",
  });
  $("#linkedinSimilarCandidatesBlock").append(linkedinSimilarCandidatesResultsDiv);


    var filterObject = new Object();
    filterObject.page = 1;
    filterObject.version = 0;
    filterObject.allCandidates = similarCandidates;

    initializePaginatorBlock();
    subscribeToPaginatorBlockSelectedFilterObjectChange(onLinkedinProfilePaginatorChange);

    onLinkedinProfilePaginatorChange(filterObject);

}

function createSimilarCandidateDiv(parentDiv, relevantCandidate) {
    var url = "";
    if (relevantCandidate.accounts.linkedinHTML && relevantCandidate.accounts.linkedinHTML.length > 0) {
      url = relevantCandidate.accounts.linkedinHTML;
    } else {
      url = "https://candyjar.io/p/" + relevantCandidate.login;
    }

    var linkedinSimilarCandidateContainerDiv = $("<div />", {
      class: "linkedinSimilarCandidateContainerDiv",
      id: "linkedinSimilarCandidateContainerDiv" + relevantCandidate.login,
    });
    parentDiv.append(linkedinSimilarCandidateContainerDiv);


    var linkedinSimilarCandidateLinkDiv = $("<a />", {
      class: "linkedinSimilarCandidateLinkDiv",
      id: "linkedinSimilarCandidateLinkDiv" + relevantCandidate.login,
      href: url,
      target: "_blank",
    });
    linkedinSimilarCandidateContainerDiv.append(linkedinSimilarCandidateLinkDiv);

    var linkedinSimilarCandidateDiv = $('<div/>',{
      class: "linkedinSimilarCandidateDiv",
      id: "linkedinSimilarCandidateDiv" + relevantCandidate.login,
    });
    linkedinSimilarCandidateLinkDiv.append(linkedinSimilarCandidateDiv);


    var linkedinSimilarCandidateImgDiv = $('<img/>',{
      class: "linkedinSimilarCandidateImgDiv",
      id: "linkedinSimilarCandidateImgDiv" + relevantCandidate.login,
      src: relevantCandidate.about.avatarUrl
    });
     linkedinSimilarCandidateDiv.append(linkedinSimilarCandidateImgDiv);

    var linkedinSimilarCandidateNamePositionDiv = $('<div/>',{
      class: "linkedinSimilarCandidateNamePositionDiv",
      id: "linkedinSimilarCandidateNamePositionDiv" + relevantCandidate.login,
    });
     linkedinSimilarCandidateDiv.append(linkedinSimilarCandidateNamePositionDiv);

    var name = "...";
    if (relevantCandidate.about.name && relevantCandidate.about.name.length > 0) {
      name = relevantCandidate.about.name;
    }
    var linkedinSimilarCandidateNameDiv = $('<div/>',{
      class: "linkedinSimilarCandidateNameDiv",
      id: "linkedinSimilarCandidateNameDiv" + relevantCandidate.login,
      text: name
    });
     linkedinSimilarCandidateNamePositionDiv.append(linkedinSimilarCandidateNameDiv);

    var currentPosition = relevantCandidate.about.currentPosition;
    if (currentPosition && currentPosition.length > 28) {
      currentPosition = currentPosition.substring(0,27) + "..";
    }
    var linkedinSimilarCandidatePositionDiv = $('<p/>',{
      class: "linkedinSimilarCandidatePositionDiv",
      id: "linkedinSimilarCandidatePositionDiv" + relevantCandidate.login,
      text: currentPosition,
    });
     linkedinSimilarCandidateNamePositionDiv.append(linkedinSimilarCandidatePositionDiv);

    var currentCompany = "";
    if (relevantCandidate.about.currentCompany && relevantCandidate.about.currentCompany.length > 0) {
      currentCompany = relevantCandidate.about.currentCompany;
      if (currentCompany.length > 28) {
        currentCompany = currentCompany.substring(0,27) + "..";
      }
    }

    if (currentCompany.length > 0) {
      var linkedinSimilarCandidateCompanyDiv = $('<p/>',{
        class: "linkedinSimilarCandidateCompanyDiv",
        id: "linkedinSimilarCandidateCompanyDiv" + relevantCandidate.login,
        text: currentCompany,
      });
      linkedinSimilarCandidateNamePositionDiv.append(linkedinSimilarCandidateCompanyDiv);
    }

}

function onLinkedinProfilePaginatorChange(selectedFilterObject) {
  var authorizedDays = 0;
  if (authorizationInfo && authorizationInfo.days) {
    authorizedDays = authorizationInfo.days
  }
  if (authorizedDays <= 0 && selectedFilterObject.page > 1) {
    createSearchPanelNeedSubscriptionDiv($(".linkedinSimilarCandidatesResultsDiv"));
    return;
  }


  console.log("similar candidates request");
  console.log(selectedFilterObject);
  selectedFilterObject.limit = 10;

  $(".linkedinSimilarCandidatesResultsDiv").empty();

  developers = selectDevelopers(selectedFilterObject.allCandidates, selectedFilterObject);
  linkedinProfilePaginatorRequestOk(developers, selectedFilterObject)

}

function selectDevelopers(allStarredCandidates, selectedFilterObject) {
  var skipCandidates = (selectedFilterObject.page-1) * selectedFilterObject.limit;
  var skippedCandidates = 0;
  var developers = [];
  var limit = selectedFilterObject.limit;

  for (var i = 0; i < allStarredCandidates.length; i++) {
    developer = allStarredCandidates[i];

    if (skippedCandidates < skipCandidates) {
      skippedCandidates++;
      continue;
    }

    if (developers.length < limit) {
      developers.push(developer);
    }
  }
  return developers
}

function linkedinProfilePaginatorRequestOk(candidates, selectedFilterObject) {
  var newCandidates = candidates;
  //
  // if (myTalentsPanelHistoryObject.selectedFilterObjectVersion != selectedFilterObject.version) {
  //   myTalentsPanelHistoryObject.selectedFilterObjectVersion = selectedFilterObject.version;
  //   myTalentsPanelHistoryObject.selectedCandidates = [];
  //   myTalentsPanelHistoryObject.foundResultsValue = 0;
  // }
  //
  $(".linkedinSimilarCandidatesResultsDiv").empty();
  // myTalentsPanelHistoryObject.selectedCandidates = addToSelectedCandidates(newCandidates, myTalentsPanelHistoryObject.selectedCandidates);
  //addSelectedCandidatesToPanel($(".linkedinSimilarCandidatesResultsDiv"), candidates, selectedFilterObject);
  //
  for (index = 0; index < newCandidates.length; index++) {
    var candidate = newCandidates[index];
    if (candidate.login.includes('%')) {
      continue;
    }
    createSimilarCandidateDiv($(".linkedinSimilarCandidatesResultsDiv"), candidate);
  }
  //
  // myTalentsPanelHistoryObject.selectedFilterObject = selectedFilterObject;
  //
  var isLastPage = false;
  if (!newCandidates.length) {
    isLastPage = true;
  }
  createPaginatorBlock($(".linkedinSimilarCandidatesResultsDiv"), selectedFilterObject, isLastPage);
}

function createSearchPanelNeedSubscriptionDiv(parentDiv) {
  parentDiv.empty();
  var searchPanelRenewSubscriptionDiv = $('<div>',{
    class: "panelApiRenewSubscriptionDiv",
    text: "it seems you need to renew your subscription."
  });
  parentDiv.append(searchPanelRenewSubscriptionDiv);

  var searchPanelRenewSubscriptionContactUsDiv = $('<button>',{
    type: "button",
    class: "panelApiRenewSubscriptionContactUsDiv",
    text: "Contact us.",
    click: function () {
      var win = window.open("https://product.candyjar.io/en/tbd-message", '_blank');
      if (win) {win.focus();}
    }
   });
  parentDiv.append(searchPanelRenewSubscriptionContactUsDiv);
}
