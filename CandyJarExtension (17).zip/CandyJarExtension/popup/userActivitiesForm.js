var messagesCount = 0

function createCandyProfileUserActivitiesDiv (emailsSet, response) {

  var candyProfileUserActivitiesDiv = $('<div>',{
    class: "candyProfileUserActivitiesDiv",
  });

  var candyProfileUserActivitiesUlDiv = $('<ul>',{
    class: "candyProfileUserActivitiesUlDiv",
  }).css('position', "relative");
  candyProfileUserActivitiesDiv.append(candyProfileUserActivitiesUlDiv);


  var candyProfileUserActivitiesLiInfoDiv = $('<li>',{
    class: "candyProfileUserActivitiesLiDiv",
    id: "candyProfileUserActivitiesInfoLiId",
  }).on('click', function(){
      deleteCandyProfileUserActivitiesViewsCss();
      deleteCandyProfileUserActivitiesViewsDivs();
      $("#candyProfileUserActivitiesInfoLiId").css("border-bottom","1px solid #1f8ceb");
      candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesInfoDataDiv(response));
  }).css('border-bottom', "1px solid #1f8ceb").css('position', "relative");
  candyProfileUserActivitiesUlDiv.append(candyProfileUserActivitiesLiInfoDiv);
  candyProfileUserActivitiesLiInfoDiv.append(createCandyProfileUserActivitiesInfoDiv());

  var candyProfileUserActivitiesLiViewsDiv = $('<li>',{
    class: "candyProfileUserActivitiesLiDiv",
    id: "candyProfileUserActivitiesViewsLiId",
  }).on('click', function(){
      deleteCandyProfileUserActivitiesViewsCss();
      deleteCandyProfileUserActivitiesViewsDivs();
      $("#candyProfileUserActivitiesViewsLiId").css("border-bottom","1px solid #1f8ceb");
      candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesViewsDataDiv(response));
  }).css('position', "relative");
  candyProfileUserActivitiesUlDiv.append(candyProfileUserActivitiesLiViewsDiv);
  candyProfileUserActivitiesLiViewsDiv.append(createCandyProfileUserActivitiesViewDiv(getViewsList(response).length));



  // var candyProfileUserActivitiesLiNotesDiv = $('<li>',{
  //   class: "candyProfileUserActivitiesLiDiv",
  //   id: "candyProfileUserActivitiesNotesLiId",
  // }).on('click', function(){
  //     deleteCandyProfileUserActivitiesViewsCss();
  //     deleteCandyProfileUserActivitiesViewsDivs();
  //     $("#candyProfileUserActivitiesNotesLiId").css("border-bottom","1px solid #1f8ceb");
  //     candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesNotesDataDiv(response));
  // }).css('position', "relative");
  // candyProfileUserActivitiesUlDiv.append(candyProfileUserActivitiesLiNotesDiv);
  // candyProfileUserActivitiesLiNotesDiv.append(createCandyProfileUserActivitiesNotesDiv(getDescriptionsList(response)));

  var candyProfileUserActivitiesLiEmailsDiv = $('<li>',{
    class: "candyProfileUserActivitiesLiDiv",
    id: "candyProfileUserActivitiesEmailsLiId",
  }).on('click', function(){
      deleteCandyProfileUserActivitiesViewsCss();
      deleteCandyProfileUserActivitiesViewsDivs();
      $("#candyProfileUserActivitiesEmailsLiId").css("border-bottom","1px solid #1f8ceb");
      candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesGmailDiv(emailsSet));
      $('#candyProfileUserActivitiesViewSpanEmail').css("display", "none");
      messagesCount = 0;
  }).css('position', "relative");
  candyProfileUserActivitiesUlDiv.append(candyProfileUserActivitiesLiEmailsDiv);
  candyProfileUserActivitiesLiEmailsDiv.append(createCandyProfileUserActivitiesEmailsDiv());


  var candyProfileUserActivitiesLiDownloadsDiv = $('<li>',{
    class: "candyProfileUserActivitiesLiDiv",
    id: "candyProfileUserActivitiesDownloadsLiId",
  }).on('click', function(){
      deleteCandyProfileUserActivitiesViewsCss();
      deleteCandyProfileUserActivitiesViewsDivs();
      $("#candyProfileUserActivitiesDownloadsLiId").css("border-bottom","1px solid #1f8ceb");
      candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesDownloadDiv(response));
  }).css('position', "relative");
  candyProfileUserActivitiesUlDiv.append(candyProfileUserActivitiesLiDownloadsDiv);
  candyProfileUserActivitiesLiDownloadsDiv.append(createCandyProfileUserActivitiesDownloadsDiv());



  var candyProfileUserActivitiesDatasDiv = $('<ul>',{
    class: "candyProfileUserActivitiesDatasDiv",
  });
  candyProfileUserActivitiesDiv.append(candyProfileUserActivitiesDatasDiv);
  candyProfileUserActivitiesDatasDiv.append(createCandyProfileUserActivitiesInfoDataDiv(response));



  return candyProfileUserActivitiesDiv;
}

function getViewsList(response) {
  if (response.lastViewDate) {
    return [response.lastViewDate];
  } else {
    return [];
  }
}

function getDescriptionsList(response) {
  if (response.description) {
    return [response.description];
  } else {
    return [];
  }
}

function createCandyProfileUserActivitiesNoDataDiv() {
  var candyProfileUserActivitiesNoDataDiv = $('<div>',{
    class: "candyProfileUserActivitiesDataDiv",
    text: "no available yet",
  });
  return candyProfileUserActivitiesNoDataDiv;
}

function createCandyProfileUserActivitiesNotesDataDiv(response) {
  var candyProfileUserActivitiesNotesDataDiv = $('<div>',{
    class: "candyProfileUserActivitiesNotesDataDiv",
  });

  var descriptionsList = getDescriptionsList(response);

  var isCurrentUserNoteExist = false;
  var currentUserEmail = getCurrentUserEmail().toLowerCase();
  for (var i = 0; i < descriptionsList.length; i++) {
    var userComment = descriptionsList[i];


    // var viewUserEmail = viewElement.email.toLowerCase();;
    // var userComment = viewElement.comments;

    var emailText = "You (" + currentUserEmail + "):";
    if (userComment && userComment.length) {
      isCurrentUserNoteExist = true;
    }


    if (userComment && userComment.length) {
      var candyProfileUserActivitiesSingleNoteDiv = createCandyProfileUserActivitiesSingleNoteDiv();
      candyProfileUserActivitiesNotesDataDiv.append(candyProfileUserActivitiesSingleNoteDiv);

      candyProfileUserActivitiesSingleNoteDiv.append(createCandyProfileUserActivitiesSingleNoteEmailDateDiv(emailText, userComment, currentUserEmail));
      candyProfileUserActivitiesSingleNoteDiv.append(getCandyProfileAddNotesDivButton(candyProfileUserActivitiesSingleNoteDiv, response.github_id, userComment, currentUserEmail));


    }
  }

  if (!isCurrentUserNoteExist) {
    var candyProfileUserActivitiesSingleNoteDiv = createCandyProfileUserActivitiesSingleNoteDiv();
    candyProfileUserActivitiesNotesDataDiv.append(candyProfileUserActivitiesSingleNoteDiv);

    var emailText = "You (" + currentUserEmail + "):";
    var userComment = "you can add note here...";
    candyProfileUserActivitiesSingleNoteDiv.append(createCandyProfileUserActivitiesSingleNoteEmailDateDiv(emailText, userComment, currentUserEmail));

    candyProfileUserActivitiesSingleNoteDiv.append(getCandyProfileAddNotesDivButton(candyProfileUserActivitiesSingleNoteDiv, response.github_id, "", currentUserEmail));

  }

  return candyProfileUserActivitiesNotesDataDiv
}

function getCandyProfileAddNotesDivButton(parentDiv, developerId, existNotes, corporateUserEmail) {
  var candyProfileAddNotesDiv = $('<li>',{
    class: "candyProfileAddNotesDiv"
  });

  var candyProfileAddNotesDivButton = $('<button>',{
    type: "button",
    class: "candyProfileAddNotesDivButton",
    text: "add note",
    click: function () {
      $(".candyProfileAddNotesDiv").remove();
      parentDiv.append(getCandyProfileInputNotesDiv(parentDiv, developerId, existNotes, corporateUserEmail));
    }
   });
  candyProfileAddNotesDiv.append(candyProfileAddNotesDivButton);

  return candyProfileAddNotesDiv;
}

function getCandyProfileInputNotesDiv(parentDiv, developerId, existNotes, corporateUserEmail) {
  var candyProfileInputNotesDiv = $('<li>',{
    class: "candyProfileInputNotesDiv"
  });

  var candyProfileInputNotesDivinput = $('<textarea>',{
    rows: "5",
    class: "candyProfileInputNotesDivinput",
    text: existNotes,
   });
  candyProfileInputNotesDiv.append(candyProfileInputNotesDivinput);


  var candyProfileInputNotesDivOkButton = $('<button>',{
    type: "button",
    class: "candyProfileInputNotesDivOkButton",
    text: "OK",
    click: function () {
       $(".candyProfileInputNotesDiv").remove();
       var value = candyProfileInputNotesDivinput.val();
       if (value.length > 0) {
         existNotes = value;
         var noteElement = document.getElementById("candyProfileUserActivitiesSingleNoteDateDiv"+corporateUserEmail);
         noteElement.innerHTML = existNotes;
         var formData = new FormData();
         formData.append("login_id", developerId);
         formData.append("description", existNotes);

         var data = {
           login_id: developerId,
           description: existNotes
         };

         var body = 'login=' + encodeURIComponent(developerId) + '&description=' + encodeURIComponent(existNotes) + '&website_name=popup_profile';

         sendUserComment(body);
       }
       parentDiv.append(getCandyProfileAddNotesDivButton(parentDiv, developerId, existNotes, corporateUserEmail));
    }
   });
  candyProfileInputNotesDiv.append(candyProfileInputNotesDivOkButton);

  return candyProfileInputNotesDiv;
}

function createCandyProfileUserActivitiesViewsDataDiv(response) {
  var candyProfileUserActivitiesViewsDataDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewsDataDiv",
  });

  var viewsList = getViewsList(response);

  for (var i = 0; i < viewsList.length; i++) {
    var viewUserDate = viewsList[i];

    var currentUserEmail = getCurrentUserEmail().toLowerCase();
    // var viewUserEmail = viewElement.email.toLowerCase();;
    // var viewUserDate = viewElement.last_view;

    var emailText = "You (" + currentUserEmail + ") viewed this profile  ";

    var candyProfileUserActivitiesSingleViewDiv = createCandyProfileUserActivitiesSingleViewDiv();
    candyProfileUserActivitiesViewsDataDiv.append(candyProfileUserActivitiesSingleViewDiv);

    candyProfileUserActivitiesSingleViewDiv.append(createSingleViewSvg());
    candyProfileUserActivitiesSingleViewDiv.append(createCandyProfileUserActivitiesSingleViewEmailDateDiv(emailText, viewUserDate));

  }




  return candyProfileUserActivitiesViewsDataDiv;
}

function createCandyProfileUserActivitiesSingleNoteEmailDateDiv(emailText, userComment, userEmail) {
  var candyProfileUserActivitiesSingleNoteEmailDateDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleNoteEmailDateDiv",
  });

  var candyProfileUserActivitiesSingleNoteEmailDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleNoteEmailDiv",
    text: emailText,
  });
  candyProfileUserActivitiesSingleNoteEmailDateDiv.append(candyProfileUserActivitiesSingleNoteEmailDiv);

  var candyProfileUserActivitiesSingleNoteDateDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleNoteDateDiv",
    id: "candyProfileUserActivitiesSingleNoteDateDiv" + userEmail,
    text: userComment,
  });
  candyProfileUserActivitiesSingleNoteEmailDateDiv.append(candyProfileUserActivitiesSingleNoteDateDiv);


  return candyProfileUserActivitiesSingleNoteEmailDateDiv;
}

function createCandyProfileUserActivitiesSingleViewEmailDateDiv(emailText, viewUserDate) {
  var candyProfileUserActivitiesSingleViewEmailDateDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleViewEmailDateDiv",
  });

  var candyProfileUserActivitiesSingleViewEmailDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleViewEmailDiv",
    text: emailText,
  });
  candyProfileUserActivitiesSingleViewEmailDateDiv.append(candyProfileUserActivitiesSingleViewEmailDiv);


  var candyProfileUserActivitiesSingleViewDateDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleViewDateDiv",
    text: viewUserDate,
  });
  candyProfileUserActivitiesSingleViewEmailDateDiv.append(candyProfileUserActivitiesSingleViewDateDiv);






  return candyProfileUserActivitiesSingleViewEmailDateDiv;
}

function createCandyProfileUserActivitiesSingleViewDiv() {
  var candyProfileUserActivitiesSingleViewDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleViewDiv",
  });
  return candyProfileUserActivitiesSingleViewDiv;
}

function createCandyProfileUserActivitiesSingleNoteDiv() {
  var candyProfileUserActivitiesSingleNoteDiv = $('<div>',{
    class: "candyProfileUserActivitiesSingleNoteDiv",
  });
  return candyProfileUserActivitiesSingleNoteDiv;
}



function createCandyProfileUserActivitiesInfoDataDiv(response) {
  var candyProfileUserActivitiesInfoDataDiv = $('<div>',{
    class: "candyProfileUserActivitiesInfoDataDiv",
  });


  candyProfileUserActivitiesInfoDataDiv.append(createCandyProfileGithubPerfomanceDiv(response.github_metrics.total_github_activity, response.tags_count, response.languages));
  candyProfileUserActivitiesInfoDataDiv.append(createCandyProfileTagsDiv(response.top_tags));


  const workExperienceList = [];
  const educationList = [];
  getWorkExperienceAndEducation(response, workExperienceList, educationList);
  if (workExperienceList.length > 0 ) {
    candyProfileUserActivitiesInfoDataDiv.append(createCandyProfileWorkExperienceDiv(workExperienceList, "Work Experience", "candyProfileWorkExperienceSecondBlockId", "candyProfileWorkExperienceViewMoreButton", "WorkExperience"));
  }
  if (educationList.length > 0 ) {
    candyProfileUserActivitiesInfoDataDiv.append(createCandyProfileWorkExperienceDiv(educationList, "Education", "candyProfileEducationSecondBlockId", "candyProfileEducationViewMoreButton", "Education"));
  }


  return candyProfileUserActivitiesInfoDataDiv;
}

function deleteCandyProfileUserActivitiesViewsCss() {
  $("#candyProfileUserActivitiesInfoLiId").css("border-bottom","");
  $("#candyProfileUserActivitiesViewsLiId").css("border-bottom","");
  $("#candyProfileUserActivitiesNotesLiId").css("border-bottom","");
  $("#candyProfileUserActivitiesEmailsLiId").css("border-bottom","");
  $("#candyProfileUserActivitiesDownloadsLiId").css("border-bottom","");
}

function deleteCandyProfileUserActivitiesViewsDivs() {
  $(".candyProfileUserActivitiesDataDiv").remove();
  $(".candyProfileUserActivitiesInfoDataDiv").remove();
  $(".candyProfileUserActivitiesViewsDataDiv").remove();
  $(".candyProfileUserActivitiesNotesDataDiv").remove();
  $(".candyProfileUserActivitiesGmailDiv").remove();
  $(".candyProfileUserActivitiesDownloadDiv").remove();
}


function createCandyProfileUserActivitiesGmailDiv(emailsSet) {
  var candyProfileUserActivitiesGmailDiv = $('<div>',{
    class: "candyProfileUserActivitiesGmailDiv",
    id: "candyProfileUserActivitiesGmailDivId",
  });

  var candyProfileUserActivitiesGmailSignInButton = $('<button>',{
    class: "candyProfileUserActivitiesGmailSignInButton",
    id: "candyProfileUserActivitiesGmailSignInButton",
    text: "Sign in with google",
    click: function () {getMessages(emailsSet, true, getMessagesResult)}
  });
  candyProfileUserActivitiesGmailSignInButton.prepend(createGoogleSvg());
  candyProfileUserActivitiesGmailDiv.append(candyProfileUserActivitiesGmailSignInButton);

  if (isSignInAndHaveDays()) {
    getMessages(emailsSet, false, getMessagesResult);
  } else {

  }

  return candyProfileUserActivitiesGmailDiv;
}

function createCandyProfileUserActivitiesDownloadDiv(response) {
  var candyProfileUserActivitiesDownloadDiv = $('<div>',{
    class: "candyProfileUserActivitiesDownloadDiv",
    id: "candyProfileUserActivitiesDownloadDivId",
  });

  candyProfileUserActivitiesDownloadDiv.append(createCandyProfileDownloadsCreatePdfDiv(response));
  candyProfileUserActivitiesDownloadDiv.append(createCandyProfileDownloadsCopyToClipboardDiv(response));



  // var candyProfileUserActivitiesGmailSignInButton = $('<button>',{
  //   class: "candyProfileUserActivitiesGmailSignInButton",
  //   id: "candyProfileUserActivitiesGmailSignInButton",
  //   text: "Sign in with google",
  //   click: function () {getMessages(emailsSet, true, getMessagesResult)}
  // });
  // candyProfileUserActivitiesGmailSignInButton.prepend(createGoogleSvg());
  // candyProfileUserActivitiesGmailDiv.append(candyProfileUserActivitiesGmailSignInButton);
  //
  // if (isSignInAndHaveDays()) {
  //   getMessages(emailsSet, false, getMessagesResult);
  // } else {
  //
  // }

  return candyProfileUserActivitiesDownloadDiv;
}

function getMessagesResult(error, status, response) {
  var responseJson = JSON.parse(response);
  if (responseJson.resultSizeEstimate == 0) {
    if ($('.candyProfileUserActivitiesNoEmailsDiv').length == 0 && $('.createCandyProfileUserActivitiesEmailHref').length == 0) {
      $('.candyProfileUserActivitiesGmailDiv').append(createCandyProfileUserActivitiesNoEmailsDiv());
    }
    return;
  }

  var messages = responseJson.messages;
  for (var i = 0; i < messages.length; i++) {
    var messageId = messages[i].id;
    getSingleMessage(messageId, getSingleMessageResult);
  }
}

function getSingleMessageResult(error, status, response) {


  var message = getSingleMessageJsonFromResponse(response);



  $('.candyProfileUserActivitiesNoEmailsDiv').remove();
  $('.candyProfileUserActivitiesGmailDiv').append(createCandyProfileUserActivitiesEmailDiv(message.emailHref, message.to, message.subject, message.date, message.msec, message.inOut));

  // SORT EMAIL DIVS //
  if ($('#candyProfileUserActivitiesGmailDivId').length > 0) {
    var toSort = $('#candyProfileUserActivitiesGmailDivId')[0].children;
    toSort = Array.prototype.slice.call(toSort, 0);
    toSort.sort(function(a, b) {
      var aord = +a.id;
      var bord = +b.id;
      return (aord < bord) ? 1 : -1;
    });
    var parent = $('#candyProfileUserActivitiesGmailDivId')[0];

    parent.innerHTML = "";
    for (var i = 0; i < toSort.length;  i++) {
      parent.appendChild(toSort[i]);
    }
  }
  // SORT EMAIL DIVS //

  //// if ($('.createCandyProfileUserActivitiesEmailHref').length > 0) {
  ////   $('#candyProfileUserActivitiesViewSpanEmail').css("display", "inline-block");
  ////   $('#candyProfileUserActivitiesViewSpanEmail').text($('.createCandyProfileUserActivitiesEmailHref').length);
  //// }

  $('#candyProfileUserActivitiesViewSpanEmail').css("display", "inline-block");
  $('#candyProfileUserActivitiesViewSpanEmail').text(++messagesCount);


}

function createGoogleSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 18 18');
  svg.setAttribute('width', '18');
  svg.setAttribute('height', '18');
  svg.setAttribute('class', 'candyProfileUserActivitiesGoogleSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M17.64 9.204c0-.638-.057-1.251-.164-1.84H9v3.48h4.844a4.14 4.14 0 0 1-1.796 2.717v2.258h2.908c1.702-1.566 2.684-3.874 2.684-6.615z");
  path1.setAttributeNS(null, "fill", "#4285F4");
  path1.setAttributeNS(null, "fill-rule", "evenodd");
  path1.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z");
  path2.setAttributeNS(null, "fill", "#34A853");
  path2.setAttributeNS(null, "fill-rule", "evenodd");
  path2.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path2);

  path3 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path3.setAttributeNS(null, "d", "M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z");
  path3.setAttributeNS(null, "fill", "#FBBC05");
  path3.setAttributeNS(null, "fill-rule", "evenodd");
  path3.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path3);

  path4 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path4.setAttributeNS(null, "d", "M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z");
  path4.setAttributeNS(null, "fill", "#EA4335");
  path4.setAttributeNS(null, "fill-rule", "evenodd");
  path4.setAttributeNS(null, "clip-rule", "evenodd");
  svg.appendChild(path4);

  return svg;
}


function createCandyProfileUserActivitiesEmailDiv(emailHref, emailText, subjectText, dateText, msec, inOut) {
  var createCandyProfileUserActivitiesEmailHref = $('<a>',{
    href: emailHref,
    class: "createCandyProfileUserActivitiesEmailHref",
    id: msec,
    target: "_blank",
    rel: "noreferrer",
  });

  var createCandyProfileUserActivitiesEmailImage= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailImage",
  });
  createCandyProfileUserActivitiesEmailHref.append(createCandyProfileUserActivitiesEmailImage);

  var createCandyProfileUserActivitiesEmailMainPart= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPart",
  });
  createCandyProfileUserActivitiesEmailHref.append(createCandyProfileUserActivitiesEmailMainPart);

  var createCandyProfileUserActivitiesEmailMainPartEmailTextAndInOut= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPartEmailTextAndInOut",
  });
  createCandyProfileUserActivitiesEmailMainPart.append(createCandyProfileUserActivitiesEmailMainPartEmailTextAndInOut);

  var createCandyProfileUserActivitiesEmailMainPartDateText= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPartSubjectText",
    text: dateText,
  });
  createCandyProfileUserActivitiesEmailMainPart.append(createCandyProfileUserActivitiesEmailMainPartDateText);

  var createCandyProfileUserActivitiesEmailMainPartEmailText= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPartEmailText",
    text: emailText,
  });
  createCandyProfileUserActivitiesEmailMainPartEmailTextAndInOut.append(createCandyProfileUserActivitiesEmailMainPartEmailText);

  var createCandyProfileUserActivitiesEmailMainPartInOutText= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPartInOutText",
    text: inOut,
  });
  createCandyProfileUserActivitiesEmailMainPartEmailTextAndInOut.append(createCandyProfileUserActivitiesEmailMainPartInOutText);


  var createCandyProfileUserActivitiesEmailMainPartSubjectText= $('<div>',{
    class: "createCandyProfileUserActivitiesEmailMainPartSubjectText",
    text: subjectText,
  });
  createCandyProfileUserActivitiesEmailMainPart.append(createCandyProfileUserActivitiesEmailMainPartSubjectText);



  return createCandyProfileUserActivitiesEmailHref;
}

function createCandyProfileUserActivitiesNoEmailsDiv() {
  var candyProfileUserActivitiesNoEmailsDiv = $('<div>',{
    class: "candyProfileUserActivitiesNoEmailsDiv",
  });

  var candyProfileUserActivitiesNoEmailsText = $('<p>',{
    class: "candyProfileUserActivitiesNoEmailsText",
    text: "no emails yet",
  });
  candyProfileUserActivitiesNoEmailsDiv.append(candyProfileUserActivitiesNoEmailsText);


    var candyProfileUserActivitiesNoEmailsHref = $('<a>',{
      text: 'create new',
      href: 'https://mail.google.com/mail/u/0/?tab=wm#inbox?compose=new',
      class: "candyProfileUserActivitiesNoEmailsHref",
      target: "_blank",
      rel: "noreferrer"
    });
    candyProfileUserActivitiesNoEmailsDiv.append(candyProfileUserActivitiesNoEmailsHref);

    var candyProfileUserActivitiesGmailSignOut = $('<button>',{
      type: "button",
      class: "candyProfileUserActivitiesGmailSignOut",
      id: "candyProfileUserActivitiesGmailSignOut",
      text: "Sign out",
      click: function () {
        revokeToken();
      },
      mouseleave: function () {
      },
    });
    candyProfileUserActivitiesNoEmailsDiv.append(candyProfileUserActivitiesGmailSignOut);

  return candyProfileUserActivitiesNoEmailsDiv;
}

function createCandyProfileUserActivitiesViewDiv(viewsNumber) {
  var candyProfileUserActivitiesViewDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewDiv tooltipInfo",
  });

  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M288 288a64 64 0 0 0 0-128c-1 0-1.88.24-2.85.29a47.5 47.5 0 0 1-60.86 60.86c0 1-.29 1.88-.29 2.85a64 64 0 0 0 64 64zm284.52-46.6C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 96a128 128 0 1 1-128 128A128.14 128.14 0 0 1 288 96zm0 320c-107.36 0-205.46-61.31-256-160a294.78 294.78 0 0 1 129.78-129.33C140.91 153.69 128 187.17 128 224a160 160 0 0 0 320 0c0-36.83-12.91-70.31-33.78-97.33A294.78 294.78 0 0 1 544 256c-50.53 98.69-148.64 160-256 160z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  candyProfileUserActivitiesViewDiv.append(svg);

  if (viewsNumber > 0) {
    var candyProfileUserActivitiesViewSpan = $('<span>',{
      class: "candyProfileUserActivitiesViewSpan",
      text: viewsNumber,
    });
    candyProfileUserActivitiesViewDiv.append(candyProfileUserActivitiesViewSpan);
  }

  var tooltipText = $('<span>',{
    class: "tooltiptextInfo",
    text: "views history",
  });
  candyProfileUserActivitiesViewDiv.append(tooltipText);

  return candyProfileUserActivitiesViewDiv;
}

function createCandyProfileUserActivitiesInfoDiv() {
  var candyProfileUserActivitiesInfoDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewDiv tooltipInfo",
  });

  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "m256 512c-44.112 0-80-35.888-80-80v-160c0-44.112 35.888-80 80-80s80 35.888 80 80v160c0 44.112-35.888 80-80 80zm0-288c-26.467 0-48 21.533-48 48v160c0 26.467 21.533 48 48 48 26.468 0 48-21.533 48-48v-160c0-26.467-21.532-48-48-48z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "m256 160c-44.112 0-80-35.888-80-80s35.888-80 80-80 80 35.888 80 80-35.888 80-80 80zm0-128c-26.467 0-48 21.533-48 48s21.533 48 48 48 48-21.533 48-48-21.533-48-48-48z");
  path2.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path2);



  candyProfileUserActivitiesInfoDiv.append(svg);

  // var candyProfileUserActivitiesViewSpan = $('<span>',{
  //   class: "candyProfileUserActivitiesViewSpan",
  //   text: "2",
  // });
  // candyProfileUserActivitiesViewDiv.append(candyProfileUserActivitiesViewSpan);

  var tooltipText = $('<span>',{
    class: "tooltiptextInfo",
    text: "general information",
  });
  candyProfileUserActivitiesInfoDiv.append(tooltipText);

  return candyProfileUserActivitiesInfoDiv;
}

function createCandyProfileUserActivitiesNotesDiv(descriptions) {
  var candyProfileUserActivitiesViewDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewDiv",
  });

  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M448 348.106V80c0-26.51-21.49-48-48-48H48C21.49 32 0 53.49 0 80v351.988c0 26.51 21.49 48 48 48h268.118a48 48 0 0 0 33.941-14.059l83.882-83.882A48 48 0 0 0 448 348.106zm-120.569 95.196a15.89 15.89 0 0 1-7.431 4.195v-95.509h95.509a15.88 15.88 0 0 1-4.195 7.431l-83.883 83.883zM416 80v239.988H312c-13.255 0-24 10.745-24 24v104H48c-8.837 0-16-7.163-16-16V80c0-8.837 7.163-16 16-16h352c8.837 0 16 7.163 16 16z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  candyProfileUserActivitiesViewDiv.append(svg);

  var commentsNumber = 0;
  for (var i = 0; i < descriptions.length; i++) {
    var description = descriptions[i];
    if (description && description.length) {
      commentsNumber++;
    }
  }

 if (commentsNumber > 0) {
   var candyProfileUserActivitiesNoteSpan = $('<span>',{
     class: "candyProfileUserActivitiesViewSpan",
     text: commentsNumber,
   });
   candyProfileUserActivitiesViewDiv.append(candyProfileUserActivitiesNoteSpan);
 }

  return candyProfileUserActivitiesViewDiv;
}

function createCandyProfileUserActivitiesEmailsDiv() {
  var candyProfileUserActivitiesViewDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewDiv tooltipInfo",
  });

  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 464 64 H 48 C 21.5 64 0 85.5 0 112 v 288 c 0 26.5 21.5 48 48 48 h 416 c 26.5 0 48 -21.5 48 -48 V 112 c 0 -26.5 -21.5 -48 -48 -48 Z M 48 96 h 416 c 8.8 0 16 7.2 16 16 v 41.4 c -21.9 18.5 -53.2 44 -150.6 121.3 c -16.9 13.4 -50.2 45.7 -73.4 45.3 c -23.2 0.4 -56.6 -31.9 -73.4 -45.3 C 85.2 197.4 53.9 171.9 32 153.4 V 112 c 0 -8.8 7.2 -16 16 -16 Z m 416 320 H 48 c -8.8 0 -16 -7.2 -16 -16 V 195 c 22.8 18.7 58.8 47.6 130.7 104.7 c 20.5 16.4 56.7 52.5 93.3 52.3 c 36.4 0.3 72.3 -35.5 93.3 -52.3 c 71.9 -57.1 107.9 -86 130.7 -104.7 v 205 c 0 8.8 -7.2 16 -16 16 Z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  candyProfileUserActivitiesViewDiv.append(svg);

  var candyProfileUserActivitiesNoteSpan = $('<span>',{
    class: "candyProfileUserActivitiesViewSpan",
    id: "candyProfileUserActivitiesViewSpanEmail",
    text: 0,
  }).css('display', "none");;
  candyProfileUserActivitiesViewDiv.append(candyProfileUserActivitiesNoteSpan);

  var tooltipText = $('<span>',{
    class: "tooltiptextInfo",
    text: "send email",
  });
  candyProfileUserActivitiesViewDiv.append(tooltipText);

  return candyProfileUserActivitiesViewDiv;
}

function createCandyProfileUserActivitiesDownloadsDiv() {
  var candyProfileUserActivitiesViewDiv = $('<div>',{
    class: "candyProfileUserActivitiesViewDiv tooltipInfo",
  });

  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M 529.988281 214.855469 C 529.988281 214.101562 529.988281 213.351562 529.988281 212.601562 C 530.03125 118.699219 453.945312 42.539062 360.042969 42.496094 C 302.925781 42.46875 249.613281 71.121094 218.117188 118.769531 C 155.171875 97.757812 87.109375 131.75 66.097656 194.699219 C 62.015625 206.921875 59.929688 219.71875 59.914062 232.605469 C 59.914062 233.457031 59.914062 234.316406 59.914062 235.175781 C 17.144531 246.289062 -8.519531 289.964844 2.589844 332.734375 C 11.742188 367.964844 43.519531 392.578125 79.917969 392.632812 L 259.285156 392.632812 C 264.808594 392.632812 269.285156 388.152344 269.285156 382.628906 C 269.285156 377.105469 264.808594 372.628906 259.285156 372.628906 L 79.917969 372.628906 C 46.777344 372.429688 20.070312 345.40625 20.265625 312.265625 C 20.441406 282.550781 42.335938 257.441406 71.746094 253.21875 C 77.035156 252.507812 80.835938 247.765625 80.378906 242.449219 C 80.109375 239.226562 79.917969 235.917969 79.917969 232.605469 C 79.988281 177.296875 124.882812 132.519531 180.191406 132.589844 C 193.308594 132.605469 206.292969 135.199219 218.410156 140.222656 C 223 142.128906 228.296875 140.375 230.839844 136.101562 C 273.027344 64.789062 365.035156 41.179688 436.347656 83.367188 C 482.023438 110.390625 510.023438 159.53125 509.984375 212.601562 C 509.984375 215.914062 509.894531 219.125 509.625 222.34375 C 509.160156 227.726562 513.050781 232.503906 518.414062 233.136719 C 556.789062 237.882812 584.046875 272.839844 579.300781 311.214844 C 574.96875 346.226562 545.261719 372.542969 509.984375 372.628906 C 506.976562 372.632812 503.96875 372.457031 500.984375 372.097656 C 499.546875 371.921875 498.089844 372.105469 496.742188 372.628906 L 339.597656 372.628906 C 334.074219 372.628906 329.597656 377.105469 329.597656 382.628906 C 329.597656 388.152344 334.074219 392.632812 339.597656 392.632812 L 499.984375 392.632812 C 500.746094 392.628906 501.507812 392.523438 502.242188 392.320312 C 504.773438 392.53125 507.363281 392.632812 509.984375 392.632812 C 559.699219 392.632812 600 352.332031 600 302.617188 C 600 260.609375 570.945312 224.1875 529.988281 214.855469 Z M 529.988281 214.855469 ");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  path2 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path2.setAttributeNS(null, "d", "M 377.742188 455.570312 L 309.953125 523.363281 L 309.953125 242.609375 C 309.953125 237.085938 305.476562 232.605469 299.953125 232.605469 C 294.429688 232.605469 289.949219 237.085938 289.949219 242.609375 L 289.949219 523.363281 L 222.160156 455.570312 C 218.1875 451.734375 211.855469 451.84375 208.015625 455.816406 C 204.273438 459.691406 204.273438 465.835938 208.015625 469.714844 L 292.878906 554.578125 C 296.785156 558.480469 303.117188 558.480469 307.023438 554.578125 L 391.886719 469.714844 C 395.722656 465.742188 395.613281 459.410156 391.640625 455.570312 C 387.765625 451.828125 381.621094 451.828125 377.742188 455.570312 Z M 377.742188 455.570312 ");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path2);

  candyProfileUserActivitiesViewDiv.append(svg);

  // var candyProfileUserActivitiesNoteSpan = $('<span>',{
  //   class: "candyProfileUserActivitiesViewSpan",
  //   id: "candyProfileUserActivitiesViewSpanEmail",
  //   text: 0,
  // }).css('display', "none");;
  // candyProfileUserActivitiesViewDiv.append(candyProfileUserActivitiesNoteSpan);

  var tooltipText = $('<span>',{
    class: "tooltiptextInfo",
    text: "download profile",
  });
  candyProfileUserActivitiesViewDiv.append(tooltipText);

  return candyProfileUserActivitiesViewDiv;
}



function createCandyProfileDownloadsCreatePdfDiv(response) {
  var candyProfileDownloadsCreatePdfDiv = $('<div>',{});


  var andyProfileDownloadsCreatePdfButton = createCandyProfileDownloadsCreatePdfButton(response);
  candyProfileDownloadsCreatePdfDiv.append(andyProfileDownloadsCreatePdfButton);


  return candyProfileDownloadsCreatePdfDiv;
}

function createCandyProfileDownloadsCreatePdfButton(response) {

  var andyProfileDownloadsCreatePdfButton = $('<button>',{
    type: "button",
    class: "candyProfileContactsListItemButton",
    text: "- download pdf resume",
    click: function () {
      requestString = getAddUserLogRequestString('pdf_click')
      $.get(requestString, function(data) {});
      createPDF(response);
    },
   });
   return andyProfileDownloadsCreatePdfButton;
}


function getWorkExperienceAndEducation(response, workExperienceSet, educationSet) {
    if (data.work_experience && data.work_experience.length > 0) {
        for (index = 0; index < data.work_experience.length; index++) {
          if (data.work_experience[index].type == "Work") {
            workExperienceSet.push(data.work_experience[index]);
          } else {
            educationSet.push(data.work_experience[index]);
          }
        }
    }
}

function createCandyProfileDownloadsCopyToClipboardDiv(response) {
  var candyProfileDownloadsCopyToClipboardDiv = $('<div>',{});


  var candyProfileDownloadsCopyToClipboardButton = createCandyProfileDownloadsCopyToClipboardButton(response);
  candyProfileDownloadsCopyToClipboardDiv.append(candyProfileDownloadsCopyToClipboardButton);

  if (isSignInAndHaveDays()) {
    var tooltipText = $('<span>',{
      class: "tooltiptext",
      text: "click to copy",
    });
    candyProfileDownloadsCopyToClipboardButton.append(tooltipText);
  } else {
    var tooltipText = $('<span>',{
      class: "tooltiptext",
      text: "need to update your plan",
    });
    candyProfileDownloadsCopyToClipboardButton.append(tooltipText);
  }

  return candyProfileDownloadsCopyToClipboardDiv;
}

function createCandyProfileDownloadsCopyToClipboardButton(response) {

  var candyProfileDownloadsCopyToClipboardButton = $('<button>',{
    type: "button",
    class: "candyProfileContactsListItemButton tooltip",
    text: "- copy to clipboard",
    click: function () {
      if (isSignInAndHaveDays()) {
        $(".tooltiptext").text("copied");
        const el = document.createElement('textarea');
        el.value = getClipboardTextFromResponse(response);
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      } else {
        $(".tooltiptext").text("please update your plan");
      }

    },
    mouseleave: function () {
      if (isSignInAndHaveDays()) {
        $(".tooltiptext").text("click to copy");
      } else {
        $(".tooltiptext").text("need to update your plan");
      }
    },
   }).css('position', "relative");
   return candyProfileDownloadsCopyToClipboardButton;
}

function getClipboardTextFromResponse(data) {
  var result = "";
  result += createPdfGetName(data) + "\n";
  result += createPdfGetPosition(data) + "\n";
  result += createPdfGetLocation(data) + "\n";


  result += "\n"
  var mails = createPdfGetMails(data);
  for ( mail of mails) {
    if (!isValidEmail(mail)) {
      continue;
    }
    result += mail + "\n";
  }

  result += "\n"
  var links = createPdfGetLinks(data);
  for (index = 0; index < links.length; index++) {
    result += links[index] + "\n";
  }

  result += "\n";
  if (data.about.bio && data.about.bio.length > 0) {
    result += "About\n";
    result += data.about.bio;
  }

  if (data.work_experience && data.work_experience.length > 0) {
    result += "\n";
    for (index = 0; index < data.work_experience.length; index++) {
      var work = data.work_experience[index];
      result += work.company + "\n";
      result += work.period + "\n";
      result += work.position + "\n";
      result += "\n";
    }
  }

  return result;
}


function createSingleViewSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileUserActivitiesSingleViewSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z");
  path1.setAttributeNS(null, "fill", "currentColor");

  svg.appendChild(path1);

  return svg;
}
