function createPopupStarredBlock(parentDiv, candidate) {
  var popupStarredBlock = $('<div>',{
    class: "popupStarredBlock",
    id: "popupStarredBlock" + candidate.login
  });
  parentDiv.append(popupStarredBlock);

  var popupStarredBlockSpan = $('<span>',{
    class: "popupStarredBlockSpan fa fa-star",
    id: "popupStarredBlockSpan" + candidate.login,
    click: function () {
      if ($(".popupStarDeveloperLoadAnimationDiv").length) {
        return;
      }
      popupStarredBlock.append(createPopupStarToDeveloperLoaderAnimationDiv());
      if($(this).css("color") == "rgb(221, 221, 221)") {
        addStarToCandidate(candidate.github_id, true, popupStarredBlockCallbackFunction, 'popup_profile');
        $(this).css("color", "orange");
        candidate.is_starred = 1;
      } else {
        addStarToCandidate(candidate.github_id, false, popupStarredBlockCallbackFunction, 'popup_profile');
        $(this).css("color", "rgb(221, 221, 221)");
        candidate.is_starred = 0;
      }
    }
  });
  popupStarredBlock.append(popupStarredBlockSpan);

  if (candidate.is_starred && candidate.is_starred == 1) {
    $('#popupStarredBlockSpan' + candidate.login).css("color", "orange");
  }
}

function createPopupStarToDeveloperLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "popupStarDeveloperLoadAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}

function popupStarredBlockCallbackFunction() {
    $(".popupStarDeveloperLoadAnimationDiv").remove();
}
