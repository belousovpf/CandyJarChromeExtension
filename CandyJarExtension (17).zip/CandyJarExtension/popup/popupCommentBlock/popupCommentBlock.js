function createPopupCommentBlock(parentDiv, candidate) {
  var popupCommentBlock = $('<div>',{
    class: "popupCommentBlock",
    id: "popupCommentBlock",
  });
  parentDiv.append(popupCommentBlock);

  var description = "";
  if (candidate.description && candidate.description.length) {
    description = candidate.description;
  }

  var popupCommentTextArea = $('<textarea>',{
    rows: "2",
    class: "popupCommentTextArea",
    id: "popupCommentTextArea",
    placeholder: 'my comment here...',
    text: description,
    focus: function () {
      $(this).attr('rows', 5);
    },
    blur: function () {
      var text = $(this).val();
      var data = {
        login_id: candidate.github_id,
        description: text
      };
      var body = 'login=' + encodeURIComponent(candidate.github_id) + '&description=' + encodeURIComponent(text) + '&website_name=cabinet';
      candidate.description = text;
      sendUserComment(body);
      $(this).attr('rows', 2);
    },
   });
  popupCommentBlock.append(popupCommentTextArea);
}
