function createCandyProfileGithubPerfomanceDiv(githubActivity, tagsCount, languages) {

  if (githubActivity === undefined) {
    return;
  }

  var candyProfileGithubPerfomanceDiv = $('<div>',{
    class: "candyProfileGithubPerfomanceDiv",
  });

  var candyProfileGithubPerfomanceText = $('<h6>',{
    class: "candyProfileGithubPerfomanceText",
    text: "Github Perfomance",
  });
  candyProfileGithubPerfomanceDiv.append(candyProfileGithubPerfomanceText);

  var candyProfileGithubRankingDiv = $('<div>',{
    class: "candyProfileGithubRankingDiv",
  });
  candyProfileGithubPerfomanceDiv.append(candyProfileGithubRankingDiv);

  var candyProfileGithubRankingText = $('<div>',{
    class: "candyProfileGithubRankingText",
    text: "GithubRank"
  });
  candyProfileGithubRankingDiv.append(candyProfileGithubRankingText);

  var candyProfileGithubRankingStarsDiv = $('<div>',{
    class: "candyProfileGithubRankingStarsDiv",
  });
  candyProfileGithubRankingDiv.append(candyProfileGithubRankingStarsDiv);
  createCandyProfileGithubRankingStars(candyProfileGithubRankingStarsDiv, githubActivity)

  createCandyProfileGithubPerfomanceChartDiv(languages, candyProfileGithubRankingDiv);
  vizualizeGithubRankingDiv(tagsCount, candyProfileGithubRankingDiv)

  return candyProfileGithubPerfomanceDiv;
}

function vizualizeGithubRankingDiv(tagsCount, candyProfileGithubRankingDiv) {
  var result = "";
  if (!tagsCount || tagsCount.length == 0) {
    return result;
  }

  var technologies = [];
  var topics = [];
  var index = 0;
  for (index = 0; index < tagsCount.length; index++ ) {

    var tag = tagsCount[index];
    if (tag.github_activity == 0) {
      continue;
    }
    if (tag.type == "technology" && technologies.length < 7) {
      technologies.push(tag);
    }
    if (tag.type == "topic" && topics.length < 7) {
      topics.push(tag);
    }
  }

  if (technologies.length > 0) {
    var candyProfileGithubRankingTechnologiesDiv = $('<div>',{
      class: "candyProfileGithubRankingTechnologiesDiv",
    });
    candyProfileGithubRankingDiv.append(candyProfileGithubRankingTechnologiesDiv);

    var candyProfileGithubRankingTechnologiesText = $('<div>',{
      class: "candyProfileGithubRankingTechnologiesText",
      text: "Technologies"
    });
    candyProfileGithubRankingTechnologiesDiv.append(candyProfileGithubRankingTechnologiesText);
  }

  for (index = 0; index < technologies.length; index++ ) {
    var technology = technologies[index];
    candyProfileGithubRankingTechnologiesDiv.append(createCandyProfileGithubRankingTechnologiesDiv(technology.name, technology.github_activity));
  }

  if (topics.length > 0) {
    var candyProfileGithubRankingTopicsDiv = $('<div>',{
      class: "candyProfileGithubRankingTopicsDiv",
      id: "candyProfileGithubRankingTopicsDiv",
    });
    candyProfileGithubRankingDiv.append(candyProfileGithubRankingTopicsDiv);

    var candyProfileGithubRankingTopicsText = $('<div>',{
      class: "candyProfileGithubRankingTechnologiesText",
      text: "Topics"
    });
    candyProfileGithubRankingTopicsDiv.append(candyProfileGithubRankingTopicsText);
  }
  for (index = 0; index < topics.length; index++ ) {
    var topic = topics[index];
    candyProfileGithubRankingTopicsDiv.append(createCandyProfileGithubRankingTechnologiesDiv(topic.name, topic.github_activity));
  }
  if (topics.length > 0) {
    var candyProfileGithubRankingViewMoreButton = $('<button>',{
      class: "candyProfileGithubRankingViewMoreButton",
      id: "candyProfileGithubRankingViewMoreButton",
      text: "View More",
    });
    candyProfileGithubRankingViewMoreButton.click(candyProfileGithubRankingViewMoreButtonClick);
    candyProfileGithubRankingDiv.append(candyProfileGithubRankingViewMoreButton);
  }
}

function candyProfileGithubRankingViewMoreButtonClick() {
  var moreText = document.getElementById("candyProfileGithubRankingTopicsDiv");
  var btnText = document.getElementById("candyProfileGithubRankingViewMoreButton");

  if (btnText.innerHTML == "View Less") {
    btnText.innerHTML = "View More";
    moreText.style.display = "none";
  } else {
    btnText.innerHTML = "View Less";
    moreText.style.display = "inline";
  }
}

function createCandyProfileGithubRankingTechnologiesDiv(name, percent) {
  var candyProfileGithubRankingTechnologiesDiv = $('<div>',{
    class: "candyProfileGithubRankingTechnologiesDiv",
  });

  var candyProfileGithubRankingTechnologiesNameAndPercent = $('<div>',{
    class: "candyProfileGithubRankingTechnologiesNameAndPercent",
  });
  candyProfileGithubRankingTechnologiesDiv.append(candyProfileGithubRankingTechnologiesNameAndPercent);

  var candyProfileGithubRankingTechnologiesNameText = $('<div>',{
    text: name,
  });
  candyProfileGithubRankingTechnologiesNameAndPercent.append(candyProfileGithubRankingTechnologiesNameText);

  var candyProfileGithubRankingTechnologiesPercentText = $('<div>',{
    text: percent+"%",
  });
  candyProfileGithubRankingTechnologiesNameAndPercent.append(candyProfileGithubRankingTechnologiesPercentText);

  var candyProfileGithubRankingTechnologiesProgressDiv = $('<div>',{
    class: "candyProfileGithubRankingTechnologiesProgressDiv",
  });
  candyProfileGithubRankingTechnologiesDiv.append(candyProfileGithubRankingTechnologiesProgressDiv);

  var candyProfileGithubRankingTechnologiesProgressBar = $('<div>',{
    class: "candyProfileGithubRankingTechnologiesProgressBar",
  }).css('width', percent+"%");;
  candyProfileGithubRankingTechnologiesProgressDiv.append(candyProfileGithubRankingTechnologiesProgressBar);

  return candyProfileGithubRankingTechnologiesDiv;
}

function createCandyProfileGithubRankingStars(candyProfileGithubRankingStarsDiv, githubActivity) {
  if (githubActivity <= 1) {
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
  } else if (githubActivity <= 20) {
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
  } else if (githubActivity <= 40) {
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
  } else if (githubActivity <= 60) {
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
  } else if (githubActivity <= 80) {
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createEmptyStarSvg());
  } else {
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
    candyProfileGithubRankingStarsDiv.append(createFilledStarSvg());
  }
}

function createCandyProfileGithubPerfomanceChartDiv(languages, candyProfileGithubRankingDiv) {
  if (languages === undefined || languages.length == 0) {
    return;
  }

  var commitsByYear = getCommitsByYear(languages);
  if (!commitsByYear || commitsByYear.length == 0) {
      return;
  }

  var candyjarGraphicDiv = $('<div/>',{
    id: "candyjarGraphicDiv",
    class: "candyjarGraphicDiv",
  });

  var candyjarCanvas = $('<canvas/>',{
    id: "myChart",
    class: "candyjarCanvasMyChart"
  });

  candyProfileGithubRankingDiv.append(candyjarGraphicDiv);
  candyjarGraphicDiv.append(candyjarCanvas);

  var candyjarCanvasCtx = candyjarCanvas[0].getContext('2d');

  var myChart = new Chart(candyjarCanvasCtx, {
    type: 'line',
    data: {
        labels: ['2016', '2017', '2018', '2019', '2020'],
        datasets: commitsByYear
    },
    options: {
      legend: {
        labels: {
          usePointStyle: true,
          boxWidth: 5,
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
  });

}

function createEmptyStarSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileGithubPerfomanceStarSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M528.1 171.5L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6zM388.6 312.3l23.7 138.4L288 385.4l-124.3 65.3 23.7-138.4-100.6-98 139-20.2 62.2-126 62.2 126 139 20.2-100.6 98z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}

function createFilledStarSvg() {
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute('viewBox', '0 0 576 512');
  svg.setAttribute('class', 'candyProfileGithubPerfomanceStarSvg');


  path1 = document.createElementNS("http://www.w3.org/2000/svg","path");
  path1.setAttributeNS(null, "d", "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z");
  path1.setAttributeNS(null, "fill", "currentColor");
  svg.appendChild(path1);

  return svg;
}
