function createPopupFirstLetterBlock(parentDiv, candidate) {
  var popupFirstLetterBlock = $('<div>',{
    class: "popupFirstLetterBlock",
    id: "popupFirstLetterBlock",
  });
  parentDiv.append(popupFirstLetterBlock);

  var generateHelloLetterButton = $('<button>',{
    class: "generateHelloLetterButton",
    text: "generate Hello letter",
    click: function () {
      if ($(".letterLoaderAnimationDiv").length) {
        return;
      }
      $(this).append(createLetterLoaderAnimationDiv());
      $(".popupFirstLetterDiv").empty();
      var requestString = getGenerateLetterRequestString(candidate.login.toLowerCase());
      requestString = encodeURI(requestString);
      $.ajax({
           type: 'GET',
           url: requestString,
           success: function(response) {
             $(".letterLoaderAnimationDiv").remove();
             $(".popupFirstLetterDiv").empty();
             letterTextDiv = createPopupFirstLetterTextDiv(response.letter);
             $(".popupFirstLetterDiv").append(letterTextDiv);

             var letterTooltipText = $('<span>',{
               class: "tooltiptext",
               text: "click to copy",
             });
             letterTextDiv.append(letterTooltipText);
           },
           error: function() {
             $(".letterLoaderAnimationDiv").remove();
             console.log('fail');
           }
      });

    }
  });
  popupFirstLetterBlock.append(generateHelloLetterButton);

  var popupFirstLetterDiv = $('<div>',{
    class: "popupFirstLetterDiv",
    id: "popupFirstLetterDiv",
  });
  popupFirstLetterBlock.append(popupFirstLetterDiv);
}

function createPopupFirstLetterTextDiv(letter) {
  var popupFirstLetterTextDiv = $('<button>',{
    type: "button",
    class: "popupFirstLetterTextDiv tooltip",
    text: letter,
    click: function () {
      $(".tooltiptext").text("copied");
      const el = document.createElement('textarea');
      el.value = letter;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      // var requestString = getAddUserLogRequestString('popup_profile', 'email_click')
      // chrome.runtime.sendMessage({type: "execute_get_request_socials", requestString: requestString}, function(response) {});
    },
    mouseleave: function () {
        $(".tooltiptext").text("click to copy");
    },
   }).css('position', "relative");
   return popupFirstLetterTextDiv;
}

function createLetterLoaderAnimationDiv() {
  var ringDiv = $('<div>',{
    class: "letterLoaderAnimationDiv"
  });
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  ringDiv.append($('<div>',{}));
  return ringDiv;
}
