//////////////////
// SIGN IN FORM //
function vizualizeSignInForm() {
  var signInElementsDiv = createSignInElementsDiv("signInElementsDiv");
  signInElementsDiv.append(createSignInText());
  signInElementsDiv.append(createSignInHref("signInHref"));
  return signInElementsDiv;
}

function createSignInElementsDiv(divId) {
  var signInElementsDiv = $('<div>',{
    id: divId,
    class: "signInElementsDiv"
  });
  return signInElementsDiv;
}

function createSignInHref(divId) {
  var signInHref = $('<a>',{
    id: divId,
    text: 'Sign In',
    href: 'https://candyjar.io/en/auth',
    class: "signInHref",
    target: "_blank",
    rel: "noreferrer"
  });
  return signInHref;
}

function createSignInText() {
  var signInText = $('<p>',{
    text: 'Sign in with your CandyJar account to continue'
  });
  return signInText;
}
// SIGN IN FORM //
//////////////////
