//function createCandyProfileAboutDiv(avatarHtml, developerName, location, position, company, isHireable) {
function createCandyProfileAboutDiv(parentDiv, candidate) {

  var avatarHtml    = candidate.about.avatar_url;
  var developerName = candidate.about.name;
  var location      = candidate.about.location;
  var position      = candidate.about.current_position;
  var company       = candidate.about.company;

  var candyProfileAbout = $('<div>',{
    class: "candyProfileAbout",
  });
  parentDiv.append(candyProfileAbout);

  candyProfileAbout.append(createPopupStarredBlock(candyProfileAbout, candidate));

  var candyProfileAboutMedia = $('<div>',{
    class: "candyProfileAboutMedia",
  });
  candyProfileAbout.append(candyProfileAboutMedia);

  var candyProfileAboutAvatar = $('<div>',{
    class: "candyProfileAboutAvatar",
  });
  candyProfileAboutMedia.append(candyProfileAboutAvatar);

  var candyProfileAboutAvatarImage = $('<img>',{
    class: "candyProfileAboutAvatarImage",
    src: avatarHtml,
  });
  candyProfileAboutAvatar.append(candyProfileAboutAvatarImage);

  if (isCandidateHireable(candidate)) {
    var candyProfileHireable = $('<div>',{
      class: "candyProfileLocationPosition hireable",
      text: "hireable",
    });
    candyProfileAboutAvatar.append(candyProfileHireable);
  }

  var candyProfileNameLocationPosition = $('<div>',{
    class: "candyProfileNameLocationPosition",
  });
  candyProfileAboutMedia.append(candyProfileNameLocationPosition);

  var candyProfileName = $('<h6>',{
    class: "candyProfileName",
    text: developerName,
  });
  candyProfileNameLocationPosition.append(candyProfileName);

  var candyProfileLocation = $('<p>',{
    class: "candyProfileLocationPosition",
    text: location,
  });
  candyProfileNameLocationPosition.append(candyProfileLocation);

  var candyProfilePosition = $('<p>',{
    class: "candyProfileLocationPosition",
    text: getPositionCompanyString(position, company),
  });
  candyProfileNameLocationPosition.append(candyProfilePosition);
}



function isCandidateHireable(candidate) {
  if (!candidate.top_tags || !candidate.top_tags.length) {
    return false;
  }

  topTags = candidate.top_tags;
  for (var i = 0; i < topTags.length; i++) {
      if (topTags[i] == "hireable") {
        return true;
      }
  }
  return false;
}
